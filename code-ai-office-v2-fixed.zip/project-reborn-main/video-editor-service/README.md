# Video Editor Service (VIDEO_EDITOR_API_URL)

Maliit na server na may ffmpeg. Ito ang "cloud" editor na tinatawagan ng app kapag walang ffmpeg sa main server.
Ang edit mismo ay galing sa `src/lib/app/video.ts`, kaya pareho ang resulta ng app at ng service.

## 1. I-deploy
Kailangan ng server na kayang mag-Docker (Render, Railway, Fly.io, o sariling VPS). Build mula sa ROOT ng repo:

    docker build -f video-editor-service/Dockerfile -t video-editor .
    docker run -p 8787:8787 \
      -e VIDEO_EDITOR_API_KEY="<at-least-24-random-characters>" \
      -e PUBLIC_BASE_URL="https://video.example.com" \
      video-editor

Ang `PUBLIC_BASE_URL` ay ang public https address ng service mo. Dito kinukuha ang link ng tapos na video.

## 2. Itakda sa Lovable (Secrets)
- `VIDEO_EDITOR_API_URL` = `https://video.example.com/edit`
- `VIDEO_EDITOR_API_KEY` = eksaktong kaparehong key na nasa service

## 3. I-test
    curl https://video.example.com/health        # {"ok":true}

Mga routes ng service:
- `POST /edit`: uploaded na video link (Live video job)
- `POST /render-game`: game clip mula sa banner (Gumawa ng video)
- `GET /files/<id>.mp4`: ang tapos na video, public

Pagkatapos, sa Video Studio, i-paste ang public video link. Dapat umandar na ito sa cloud editor.

## Mga limitasyon
- **Game videos** (ang "Gumawa ng video" mula sa game banner) ay dumadaan din sa service na ito, sa `/render-game`.
  Kapag may ffmpeg sa main server, doon pa rin ito nire-render.
- Isa lang ang edit na sabay-sabay sa service.
- Kapag lumampas ang 110 segundo ang edit, mamamatay ito at mag-fail ang job.
- Nililinis ang mga output pagkalipas ng 24 oras.
- Ang SSRF na proteksyon ay ang pagbabawal sa localhost at private na address. Hindi nito nasasagot ang redirect papunta sa private na address,
  kaya ilagay ang service sa server na walang access sa internal network.

## Testing lang: `ALLOW_HTTP_INPUT=1`
Pinapayagan nito ang http sa input at output para sa local test. Hindi ito dapat gamitin sa production, at tatanggi ang service na mag-start kapag `NODE_ENV=production`.
