# Real-time Facebook comment replies

Ang "real time" ay nangyayari sa pamamagitan ng **Facebook Webhook**: sa sandaling may mag-comment, si Facebook mismo
ang tatawag sa server mo → si AI ang gagawa ng sagot → mapo-post agad sa ilalim ng comment (ilang segundo lang).
Hindi na kailangan ng polling.

## A. Para sa Supabase app (ai-bot-office)
1. Kopyahin sa project (parehong folder structure):
   - `supabase/functions/_shared/facebook.ts`
   - `supabase/functions/fb-webhook/index.ts`
   - `supabase/migrations/20261121000000_comment_replies.sql`
   - idagdag ang laman ng `supabase/config.toml.snippet` sa dulo ng `supabase/config.toml`
2. Deploy:
   ```bash
   supabase db push
   supabase secrets set FB_APP_SECRET='<App Secret mula sa developers.facebook.com → App → Settings → Basic>'
   supabase secrets set FB_VERIFY_TOKEN='<kahit anong mahaba at random na string>'
   supabase functions deploy fb-webhook --no-verify-jwt
   ```
   (Gagamitin nito ang Facebook Page ID + Page token at AI key na nasa **API Settings** mo na.)
3. developers.facebook.com → App → **Webhooks** → **Page** → Callback URL:
   `https://<project-ref>.supabase.co/functions/v1/fb-webhook`, Verify token = ang FB_VERIFY_TOKEN → Verify and Save.
   Pagkatapos i-**Subscribe** ang field na **feed**.
4. I-subscribe ang Page mo sa app (isang beses):
   `curl -X POST "https://graph.facebook.com/v21.0/<PAGE_ID>/subscribed_apps" -d "subscribed_fields=feed" -d "access_token=<PAGE_TOKEN>"`
5. Permissions ng Page token: `pages_manage_posts`, `pages_manage_engagement`, `pages_read_engagement`.
   Para makuha ang comments ng KAHIT SINONG user (hindi lang admin/tester ng app), kailangang **Live mode** ang app at
   aprubado ang permissions (Advanced Access / App Review).
6. Subukan: mag-comment sa post gamit ang ibang account → tingnan ang **Activity Console** (source: `comment-bot`).

## B. Para sa Python script mo
- `python/social_tools.py` = totoong `post_to_social_media` at `reply_to_comment`.
- `python/fb_webhook_server.py` = real-time na listener (FastAPI). Ang `run_ai_social_media_office()` mo ay para sa manual na utos;
  ang webhook server ang sumasagot nang awtomatiko.

## Safety na kasama
- Signature check (X-Hub-Signature-256) — peke ang request kapag mali; fail-closed kung walang secret.
- Dedupe sa `comment_id` (nagre-retry si Facebook), hindi sinasagot ang sariling Page, at hindi sinasagot ang nested replies (walang loop).
- Limit na 60 sagot/oras.
- Hindi nag-iimbento ang AI ng presyo/shipping fee: kapag walang datos, nagpapadala ng "ipapa-check namin" at lumalabas ang babala sa Activity Console para ikaw ang sumagot.
