# SETUP — para gumana ang API Settings at ang 24/7 na mga bot

Ang "Failed to fetch" ay ibig sabihin na hindi maabot ng browser ang Supabase Edge Function.
Halos palaging dahil **hindi pa naka-deploy** ang function. Gawin ang 1–5 nang isang beses lang.

## 1. Netlify environment variables (Site settings → Environment variables)
- `VITE_SUPABASE_URL` = `https://<project-ref>.supabase.co`   (walang `/` sa dulo)
- `VITE_SUPABASE_ANON_KEY` = anon / public key
Pagkatapos: **Deploys → Trigger deploy → Clear cache and deploy site**.

## 2. I-apply ang database migrations
```bash
npm i -g supabase
supabase login
supabase link --project-ref <project-ref>
supabase db push
```

## 3. I-deploy LAHAT ng functions (ito ang ayos sa "Failed to fetch")
```bash
supabase functions deploy integrations-admin
supabase functions deploy generate-post
supabase functions deploy auto-bot-worker
supabase functions deploy publish-now
supabase functions deploy fb-webhook --no-verify-jwt   # real-time na sagot sa Facebook comments (tingnan ang SETUP-REALTIME.md)
supabase functions deploy track-click --no-verify-jwt
supabase functions deploy x-mentions-bot      # auto-reply sa X (Twitter)
supabase functions deploy watchdog-bot        # Argus: kinukulit ang team kapag may na-miss
supabase functions deploy watchdog-admin      # para sa Watchdog screen
```

## 3b. PASSWORD (kailangan — pang-lock ng lahat ng server command)
```bash
supabase secrets set APP_PASSCODE='ILAGAY-ANG-PASSWORD-MO'
supabase functions deploy admin-db
supabase functions deploy generate-post
supabase functions deploy auto-bot-worker
supabase db push        # ina-apply ang 20261120000000_lock_down_writes.sql
```
- Nasa SERVER lang ang password (secret). **Wala ito sa code o sa website files**, kaya hindi makikita ng kahit sino na mag-inspect ng site.
- Ang public anon key ay **READ-ONLY** na. Lahat ng pagbabago (games, queue, auto-pilot, invite rules, API keys, post-now) ay dumadaan sa `admin-db`/mga function na humihingi ng password.
- Kapag walang APP_PASSCODE na naka-set, **tumatanggi ang lahat** (hindi bukas).
- 5 maling subok = 10 minutong lockout. Para palitan ang password: ulitin ang `supabase secrets set` (kailangan ulit mag-login ng lahat).
- Gumamit ng mahaba at hindi hula-hulang password (huwag petsa ng kapanganakan).

## 4. 24/7 trigger (SQL Editor, isang beses, ilagay ang sarili mong values)
```sql
select vault.create_secret('https://<project-ref>.supabase.co', 'project_url');
select vault.create_secret('<SERVICE_ROLE_KEY>', 'service_role_key');
```
Tatakbo na ang `auto-bot-worker` kada minuto kahit sarado ang browser mo.

## 5. Sa app
1. **API Settings → AI Engine** → idikit ang OpenRouter key → Save → Test connection.
2. Ilagay at i-test ang Facebook / X / Discord / Telegram.
3. **Game Profiles** → at least isang *Active* na game.
4. **Scheduler → Auto-Pilot ON**.

Mula doon: kada minuto may check ang worker. Nagsusulat ng posts si Aria (A/B), nagpo-post si Blaze,
at may **daily coverage**: kung may platform na walang post sa nakaraang 24 oras, awtomatiko siyang gagawa ng post para doon.
Lahat ay lumalabas live sa Virtual Office at Activity Console.

## Seguridad
- Huwag ilagay ang API key sa chat, GitHub o sa code. Sa API Settings lang, nasa server ito at hindi na mababasa ulit ng browser.
- Kung naipakita na ang key kahit saan, i-revoke at gumawa ng bago sa openrouter.ai/keys.

## Real-time Facebook comment replies
Tingnan ang `SETUP-REALTIME.md` (webhook, secrets `FB_APP_SECRET` at `FB_VERIFY_TOKEN`, at subscribe ng Page sa `feed`).

## X (Twitter) auto-reply at Watchdog
Tingnan ang `SETUP-X-WATCHDOG.md` (X keys, Telegram/Discord para sa paalala, at mga setting).

## Shared Brain
Tingnan ang `SETUP-SHARED-BRAIN.md` (deploy ng `idea-lab-reflector`, rules, at safety).

## Live chat kay Boss (opsyonal)
- Pindutin ang **📞 Tawagan si Boss** (o i-click si Boss sa 3D office) para makipag-chat sa kanya nang live at magbigay ng bagong utos sa team.
- Walang Supabase (local simulation): gumagana ang chat gamit ang AI key na nasa **API Settings** (naka-save sa browser lang). Kung walang key, offline mode muna si Boss. Ang mga utos ay naka-save sa browser na ito lang.
- Kasama ang Supabase: `supabase functions deploy boss-chat`. Ginagamit nito ang AI key sa API Settings (nasa server) at ang parehong password. Ang mga utos ay nagiging Core Guardrail sa Shared Brain na binabasa ng lahat ng bot.
