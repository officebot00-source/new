# Android blink + 3D fix (notes)

Sanhi ng blink-blink / hirap sa Android:
1. 13 real PointLight sa 3D office (12 room lights + globe light) -> bawat pixel ng bawat material ay 13 light loops. Nag-stall ang GPU ng phone (buong screen kumikislap / nawawala ang WebGL context). Sa phone, pinalitan ng malambot na additive floor glow (halos walang gastos). Desktop ay buo pa rin.
2. MeshPhysicalMaterial (clearcoat) sa mga bot/salamin -> MeshStandardMaterial sa phone.
3. Camera near plane 0.5 -> 4: tinanggal ang z-fighting (kumikislap na sahig/carpet/salamin) sa phones na 16-bit ang depth buffer.
4. Tab-fade animation ay may `transform` sa ancestor ng WebGL canvas -> opacity na lang.
5. `backdrop-blur` sa zoom button na nasa ibabaw ng canvas -> tinanggal.
6. `scroll-behavior: smooth` -> auto (nag-flicker ang canvas sa tab change).
7. Sun color na biglang nagpapalit sa night=0.5 -> maayos na lerp.
8. 17 overlay (name tags/room labels) na sinusulatan ng style kada frame -> sumusulat lang kapag nagbago.
9. animate-pulse sa mga tag sa ibabaw ng canvas -> static glow.
10. Auto-quality ladder: baba ng resolution -> patay shadows -> baba ulit (hindi na binibilang ang unang 60 frames).
11. 3D scene ay binubuo pagkatapos ng unang paint, may "Binubuo ang 3D office..." na loading veil (wala nang frozen na screen).
12. Phone: shadow map 1024 at 2-frame update, antialias off kapag high-DPR, powerPreference default.
UI polish: bottom-nav pill, 2-column stats sa phone, scrollable chips sa office header, mas malinis na Card.

## Phone button fixes (round 2)
- Office header: the 8 chips used to scroll sideways, so most buttons were hidden off-screen. They now wrap into a 2-column grid on phones (44px tall).
- `CardHeader`: title and action badge wrap instead of squeezing each other.
- The floating **Lock** button covered content at the bottom-left: it moved to the header (tablet/desktop) and the **More** sheet (phone). The More sheet scrolls on small screens.
- Header "Auto-Pilot ON/OFF" shortens to "ON/OFF" under 380px.
- Touch targets: Boss panel buttons, zoom panel close, inspector close/pause, platform chips are now at least 44px on phones.
- Video Studio: platform chips and review/job buttons are full-width and wrap on phones; long select label shortened.
