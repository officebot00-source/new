# Shared Brain — ang iisang utak ng mga bot

Dito nag-iipon at nag-aapply ng natutunan ang buong office.

```
Aria / Blaze / Echo  ──(1) basahin muna ang Shared Brain bago magsulat──►  post / reply
        ▲                                                               │
        │                                                      (2) sukatin: clicks, CTR, likes → score 0-100
(5) lahat ng bot                                                        ▼
    agad nakikinabang   ◄──(4) bagong / reinforced rule◄──  Cipher (Reflector, bawat 30 min)
        (realtime)               (3) ano ang ginawa ng mga nanalo?
```

## Ang bagong **Shared Brain** tab (website)
- **Hero + live indicator** (realtime), at mga button na *Reflect now* (pinapatakbo agad si Cipher), *Add rule*, at switch para sa auto-share.
- **Brain map**: buhay na mapa ng 5 bot na konektado sa gitna; kapag may bagong natutunan, may pulse papasok sa utak at kumakalat sa lahat.
- **Live broadcast**: real-time na listahan ng bagong natutunan / pinalakas / inalis na rule.
- **Knowledge board**: hanapin, i-filter (category, platform), i-sort; may *Approve / Reject* para sa naghihintay ng review, *Archive / Restore / Delete*, at bar ng confidence.
- **Learning curve**: average score sa huling 7 araw — tumataas ba ang resulta habang natututo ang team?
- **3D Virtual Office**: ang dating *Idea Lab* room ay **Shared Brain** na. Kapag may totoong natutunan sa database, iyon ang "inilalagay" ng mga bot sa hologram at pinag-uusapan sa meeting (may 📚). Kapag wala pa, ang dating kathang-isip na idea ang ipinapakita para hindi mag-empty ang office.

## Ano ang idinagdag
| File | Gamit |
|---|---|
| `migrations/20261122000000_idea_lab.sql` | 4 na table (`employee_bots`, `bot_action_logs`, `idea_lab_brain`, `brain_sync_events`), vector search, realtime, indexes, 5 bot sa registry, at cron na tumatakbo bawat 30 min |
| `functions/_shared/brain.ts` | `loadBrain()` — binabasa ang rules bago magsulat; scoring; proteksyon laban sa masamang rule |
| `functions/idea-lab-reflector/` | Si Cipher: nag-ha-harvest ng results, nag-sco-score, nag-re-reinforce/nagpapahina ng rules, at gumagawa ng bagong rules |
| Binago: `auto-bot-worker`, `generate-post`, `fb-webhook` | Binabasa na nila ang Shared Brain sa prompt at sine-save kung aling rules ang ginamit |
| `src/components/SharedBrain.tsx`, `BrainMap.tsx`, `src/lib/brain.ts` | Ang bagong tab (bagong item sa nav: **Shared Brain**) |
| Binago: `admin-db` | Pwedeng mag-insert/mag-edit ng rules (admin lang, may passcode) |

## Deploy
```bash
supabase db push
supabase functions deploy idea-lab-reflector
supabase functions deploy auto-bot-worker
supabase functions deploy generate-post
supabase functions deploy fb-webhook --no-verify-jwt   # ito lang ang walang JWT; ang iba ay sumusunod sa config.toml
```
(Ginagamit ng cron ang parehong `project_url` at `service_role_key` vault secrets ng `auto-bot-worker`.)

Subukan agad nang hindi naghihintay ng cron: i-POST ang `idea-lab-reflector` gamit ang service key (o ang app passcode).

## Paano ito gumagana
1. **Apply** — bago magsulat si Aria ng post (at si Echo ng reply), kukunin nito ang *guardrails* + ang pinakamahusay na *proven tips* para sa platform na iyon (semantic search kung OpenAI/OpenRouter ang key; confidence ranking kung Gemini).
2. **Measure** — 6 na oras pagkatapos ng post (1 oras sa reply) bibigyan ito ng score: post = CTR (5% = 100), reply = 55 + 15 kada like (25 kung kailangan ng tao).
3. **Feedback** — score ≥ 60: tumataas ang confidence ng ginamit na rules (+0.03). Score ≤ 10: bumababa (−0.02). Kapag < 0.20 at nagamit na ≥ 5 beses → `deprecated` (may event sa `brain_sync_events`).
4. **Learn** — kapag may sapat na logs (default 4, `bot_settings.idea_lab_min_logs`) at may totoong pagkakaiba sa score, tatanungin ng AI kung anong pattern ang nagpanalo; hanggang 3 bagong rule bawat takbo. Kapag halos pareho ang kaso ng rule na meron na (similarity > 0.92), ire-reinforce na lang.

## Safety (mahalaga)
- **Core guardrails** (`is_core_guardrail = true`) = admin lang. Hindi sila mababago, mare-reinforce o made-deprecate ng anumang AI code. Idagdag sila sa pamamagitan ng SQL editor o `admin-db`:
  `insert into idea_lab_brain (category, platform, title, insight_rule, is_core_guardrail, confidence_score) values ('ban_guardrail','all','Max 1 invite bawat user','Huwag mag-imbita ng parehong user nang higit sa isang beses.', true, 1);`
- Ang bagong rule na `ban_guardrail` ay laging `pending_review` — ikaw ang mag-a-approve (`update idea_lab_brain set status='approved' where id = '...'`). Ang ibang kategorya ay auto-approved; para i-review lahat: `update bot_settings set idea_lab_auto_approve = false;`.
- Bina-block ang rule na may URL, "ignore previous", API key/password, o payo na umiwas sa ban / mag-fake ng engagement.
- Read-only ang website sa mga table na ito; lahat ng write ay server-side.

## Mga limitasyon (para walang gulat)
- **Invites (Nova)**: nakikita sa `bot_action_logs` pero walang score dahil walang data kung tinanggap ang invite. Template pa rin ang invite message, kaya hindi pa naa-apply ang `invite_script` rules — kapag may AI-generated invites at accept data, madaling idagdag.
- Ang `impressions` ay estimate (`est_audience`), kaya ang CTR ay relative na sukatan, hindi eksaktong reach.

## Real-time learning at pagbabahagi (v2)

```
event sa bot ──► captureRealtimeLearning() ──► idea_lab_brain (+ brain_sync_events) ──► ping sa channel "brain-sync"
(A/B winner, Argus recovery,   sanitizeInsight → duplicate check → auto-approve rule       │
 feedback ni Boss)             (ban_guardrail = laging review)                              ▼
                                                                    Shared Brain screen: flash + reload agad
Susunod na prompt ng kahit anong bot ──► loadBrain() (walang cache) ──► FRESH LESSONS (≤24h) + guardrails + proven tips
```
- **Sino ang nagre-record agad**: `auto-bot-worker` (A/B winner → lesson ni Cipher), `watchdog-bot` (Argus: na-recover na error → lesson), `boss-chat` (feedback/correction ni Boss → lesson; ang *utos* ay nananatiling confirm-first na core guardrail), at `idea-lab-reflector` (gumagamit na rin ng parehong helper).
- **Sino ang kumukunsumo**: Aria/Blaze (`auto-bot-worker`, `daily-poster`, `generate-post`), Echo (`fb-webhook`, `x-mentions-bot`), Reel (caption), `caption-writer`, at Boss (`boss-chat`, para masagot kung ano ang natutunan ng team). Ang `watchdog-bot` at Nova (invites) ay walang AI prompt kaya walang ihahalo; producer lang ang Argus.
- **Ranking kapag walang embedding (Gemini)**: confidence + boost para sa bagong broadcast (hanggang +0.25, nawawala sa loob ng 24h; reinforced hanggang +0.10) + maliit na bonus sa platform-specific; may 2 reserved slot ang FRESH LESSONS.
- **Realtime sa screen**: Realtime *Broadcast* channel `brain-sync` (hindi Postgres-changes, dahil bawal ang read grants sa office tables). Ping lang ang dumadaan (kind + rule id, walang rule text); ang screen ay nagre-reload sa admin-db. May fallback poll (8s kung walang realtime, ~32s kung meron).
- Walang bagong env var, column o migration. Ginagamit ang `SUPABASE_URL` at `SUPABASE_SERVICE_ROLE_KEY` na nandoon na.
