# Video Editor Bot + Real-Time Auto-Poster — Original Build Prompt

> Reference copy of the prompt used to build the Video Editor Bot. Implementation notes: `docs/video-editor-bot.md`.

You are working inside the `project-reborn-main` repository. Implement a complete **Video Editor Bot** and **Real-Time Auto-Poster** pipeline integrated with the existing bot architecture, background workers/triggers, publishing system, and UI.

## 1. Core Goal
Build an automated pipeline where incoming or ready videos/clips can be:
1. **Edited Automatically (Video Editor Bot)**:
   - Accepts input video URLs/paths/media assets and editing instructions (trim/cut start-end, aspect ratio `9:16` / `16:9`, burning/attaching captions or text overlays, audio mixing/volume normalization, export a final MP4).
   - Pluggable editor adapter architecture: an `ffmpeg`-based processor (when `ffmpeg` is available) plus a configurable external/cloud editor or dry-run/mock fallback when binaries or API keys are missing.
2. **Posted in Real Time (Real-Time Auto-Poster)**:
   - Triggers immediately on real-time events (webhooks, boss/command triggers, UI "Edit & Post Now", or worker queue polling) without waiting for delayed batch windows unless scheduled.
   - Generates or attaches the final caption, title, tags and media payload, then publishes through the existing publishing layer with real-time status tracking (`queued` -> `editing` -> `edited` -> `posting` -> `posted` | `failed` | `paused`), retry support, and safe dry-run/error handling.

## 2. Existing Files & Systems to Align With
- **Bot & Agent Registry**: `src/server/bot/registry.ts`, `src/lib/app/agents.ts`, `src/lib/app/types.ts`
- **Triggers, Workers & Cron**: `src/server/bot/auto-bot-worker.ts`, `src/routes/api/public/cron.tick.ts`, `src/routes/api/public/bot.$fn.ts`, `src/server/bot/fb-webhook.ts`, `src/server/bot/boss-chat.ts`, `src/lib/app/bossCommand.ts`
- **Publishing & Social**: `src/server/bot/_shared/publish.ts`, `src/server/bot/publish-now.ts`, `src/lib/app/publish.ts`, `src/server/bot/_shared/facebook.ts`, `tweet.ts`, `x.ts`, `python/social_tools.py`
- **AI, Brain, Watchdog, Persistence**: `_shared/ai.ts`, `_shared/brain.ts`, `src/lib/app/brain.ts`, `_shared/watchdog.ts`, `watchdog-bot.ts`, `admin-db.ts`, `src/lib/app/db.ts`, `src/integrations/supabase/*`, `drizzle/*`
- **UI & Monitoring**: `ContentStudio.tsx`, `Scheduler.tsx`, `ActivityConsole.tsx`, `BossCommandPanel.tsx`, `ApiSettings.tsx`, `AiKeyStatusPanel.tsx`, `VirtualOffice.tsx`, `Office3D.tsx`, `src/lib/app/office.ts`

## 3. Implementation Rules
- **Non-destructive & backward compatible**: do not break existing routes, auth/cron checks, DB migrations/queries, or existing tests in `src/test/*`.
- **Resilient execution**: handle missing `ffmpeg`, missing credentials/tokens, invalid media, or network/API failures without crashing the server or worker. Log errors/events to watchdog/activity logging with clear diagnostics.
- **No blocking request hangs**: timeouts, status updates, and background/worker or async execution.
- **Clean TypeScript**: strict types across shared contracts, server/bot modules and UI.

## 4. Deliverables & Execution Order
1. **Audit & Plan** — summarize how bots, triggers, job/state storage and publishing work today; list files to create/update.
2. **Backend** — types/schemas, Video Editor Bot (ffmpeg + adapter fallback), real-time trigger/worker wiring, Auto-Poster integration.
3. **UI** — controls to submit a video for editing + real-time posting, inspect live job stages, retry failed jobs, toggle real-time auto-post.
4. **Tests & Verification** — tests in `src/test/` for job states, real-time posting flow, and missing-dependency/error handling; run typecheck, test and build and report exact results.

Execute Step 1 first, then proceed through Steps 2–4. Only ask a question if a real blocker prevents progress; otherwise use clear, documented defaults.
