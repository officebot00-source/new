-- ============================================================================
-- Project Reborn — AYOS para sa lahat ng database function (RPC)
-- Paste sa: Supabase dashboard -> SQL Editor -> New query -> Run.
-- Safe i-run nang paulit-ulit ("create or replace"), hindi nito binubura ang data.
--
-- Mga function: increment_click, bump_rule_usage, adjust_rule, match_brain_rules
--
-- Ano ang inayos:
--  1. Siguradong may "extensions" schema at "vector" extension bago gawin ang match_brain_rules.
--  2. bump_rule_usage: kapag NULL ang usage_count, NULL pa rin ang resulta (hindi na tumataas) -> coalesce.
--  3. adjust_rule:
--       - kapag NULL ang confidence_score, ginagawang 0.01 (greatest() ay nilalaktawan ang NULL) -> default 0.50.
--       - kapag ang bot id ay wala sa employee_bots, pumapalya ang buong function (FK error) -> sine-check muna.
--       - NULL na delta / id ay hindi na nagiging error.
--  4. match_brain_rules: ligtas na limit (hindi na pumapalya sa NULL / 0 / negative).
--  5. Inuulit ang grants (service_role lang ang may execute) at nire-reload ang PostgREST schema cache,
--     kaya nakikita agad ng supabase.rpc() ang mga function.
-- ============================================================================

create schema if not exists extensions;
create extension if not exists vector with schema extensions;

-- 1) A/B link click counter (track-click route)
create or replace function public.increment_click(p_group uuid, p_variant text) returns text
language sql security definer set search_path = public as $$
  update scheduled_posts set clicks = clicks + 1
  where id = (select id from scheduled_posts where variant_group = p_group and variant = p_variant order by created_at desc limit 1)
  returning game_id::text;
$$;

-- 2) "nagamit N×" counter ng Shared Brain
create or replace function public.bump_rule_usage(p_ids uuid[]) returns void
language sql security definer set search_path = public as $$
  update idea_lab_brain set usage_count = coalesce(usage_count, 0) + 1 where id = any(coalesce(p_ids, '{}'::uuid[]));
$$;

-- 3) reinforce / weaken / deprecate a learned rule
create or replace function public.adjust_rule(p_id uuid, p_delta numeric, p_bot uuid default null) returns text
language plpgsql security definer set search_path = public as $$
declare r idea_lab_brain%rowtype; ev text; v_bot uuid;
begin
  if p_id is null or p_delta is null then return 'skipped'; end if;
  select e.id into v_bot from employee_bots e where e.id = p_bot;   -- unknown bot id must not break the foreign key
  update idea_lab_brain
     set confidence_score = least(0.99, greatest(0.01, coalesce(confidence_score, 0.50) + p_delta)), updated_at = now()
   where id = p_id and coalesce(is_core_guardrail, false) = false and status = 'approved'
   returning * into r;
  if not found then return 'skipped'; end if;
  if r.confidence_score < 0.20 and coalesce(r.usage_count, 0) >= 5 then
    update idea_lab_brain set status = 'deprecated', updated_at = now() where id = r.id;
    ev := 'rule_deprecated';
  elsif p_delta > 0 then
    ev := 'rule_reinforced';
  end if;
  if ev is not null then
    insert into brain_sync_events (brain_item_id, learned_by_bot_id, event_type) values (r.id, v_bot, ev);
  end if;
  return coalesce(ev, 'weakened');
end $$;

-- 4) semantic search (needs the vector extension; 1536 dims = text-embedding-3-small)
create or replace function public.match_brain_rules(q extensions.vector(1536), p_platforms text[], p_limit int default 8)
returns table (id uuid, category text, platform text, title text, insight_rule text, confidence_score numeric, is_core_guardrail boolean, similarity float)
language sql stable security definer set search_path = public, extensions as $$
  select b.id, b.category, b.platform, b.title, b.insight_rule, b.confidence_score, b.is_core_guardrail,
         (1 - (b.embedding <=> q))::float
    from idea_lab_brain b
   where b.status = 'approved' and b.embedding is not null and b.platform = any(coalesce(p_platforms, '{}'::text[]))
   order by b.embedding <=> q
   limit greatest(coalesce(p_limit, 8), 1);
$$;

-- grants: only the server (service_role) may call these
revoke execute on function public.increment_click(uuid, text), public.bump_rule_usage(uuid[]),
  public.adjust_rule(uuid, numeric, uuid), public.match_brain_rules(extensions.vector, text[], int)
  from public, anon, authenticated;
grant execute on function public.increment_click(uuid, text), public.bump_rule_usage(uuid[]),
  public.adjust_rule(uuid, numeric, uuid), public.match_brain_rules(extensions.vector, text[], int)
  to service_role;

-- make the new definitions visible to supabase.rpc() right away
notify pgrst, 'reload schema';
