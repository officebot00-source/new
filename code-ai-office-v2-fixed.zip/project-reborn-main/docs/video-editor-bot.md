# Video Editor Bot + Real-Time Auto-Poster

Edits a video, then posts it — in real time. The video employee is **Reel** (video editor: makes game clips, edits and *enhances* videos; logs use source `video-editor`). **Blaze** only posts (source `auto-poster`).

**Flow:** `queued → editing → edited → posting → posted` (or `failed` / `paused`).

**Where it lives**
- `src/lib/app/video.ts` — shared types, state machine, validation, ffmpeg command builder (pure)
- `src/server/bot/_shared/video-pipeline.ts` — the job pipeline, retries, stuck-job recovery, worker `tick`
- `src/server/bot/_shared/video-editor.ts` — adapters: `ffmpeg`, `cloud` (external API), `mock` (dry run only)
- `src/server/bot/_shared/video-publish.ts` — posts the video (Telegram / Discord / Facebook upload; X = text + link)
- `src/server/bot/_shared/video-store.ts` — jobs + settings in the existing `bot_state` table (**no migration**)
- `src/server/bot/video-editor-bot.ts` — endpoint `/api/public/bot/video-editor-bot`
- `src/components/app/VideoStudio.tsx` — UI (Content Studio tab)
- Scheduler: `REALTIME_JOBS` in `registry.ts` runs the bot on every 1-minute tick (`CRON_JOBS` cadence is unchanged)

**Triggers:** UI "Edit & Post Now" (starts immediately), webhook / boss call to the endpoint (`x-app-passcode`), and the 1-minute tick as safety net.

**Endpoint** (POST, header `x-app-passcode`): `{ "action": "enqueue", "input": "https://…/clip.mp4", "edit": { "aspect": "9:16", "start_sec": 0, "end_sec": 30, "overlay_text": "NEW", "normalize_audio": true }, "post": { "title": "…", "caption": "", "tags": ["#game"], "platforms": ["telegram","facebook"] } }`
Other actions: `list`, `get`, `retry`, `pause`, `resume`, `post_now`, `status`, `settings_get`, `settings_set`, `tick`.

**Optional server env:** `FFMPEG_PATH`, `VIDEO_FONT_FILE`, `VIDEO_EDIT_TIMEOUT_MS` (default 120000), `VIDEO_MEDIA_DIR` (allow local files from one folder), `VIDEO_EDITOR_API_URL` + `VIDEO_EDITOR_API_KEY` (cloud editor; must return `{ "output_url": "https://…" }`).

**Safety:** only public http(s) URLs (private/local hosts refused); no ffmpeg + no cloud editor → job fails with a clear message (or runs as a dry run); a post stuck in `posting` is never re-sent automatically; retry never re-sends to platforms that already got the post.

---

## Game videos with your approval (Reel makes it → you watch → you approve → Blaze posts)

**Flow:** `queued → editing → awaiting_approval → (you approve) → edited → posting → posted`. If you reject: `rejected` — nothing is ever posted.

- **Where:** Content Studio → Video → **"Para sa approval mo"** (watch the video, *Approve & i-post*, *Reject*, *Gawa ulit*) and **"Reel: gumawa ng video mula sa game"**.
- **What it makes:** a 12-second vertical (9:16) clip from a saved game: the game's banner with a slow zoom, the game title, genre + a tagline, and a "Play now" button; silent audio track. If the game has no banner, a plain dark background is used. The caption is the game's first description sentence + a hook, hashtags, and the game's promo link (always kept at the end, never cut off).
- **Picking the game:** you choose one, or "Bahala si Reel" — it rotates through all *active* games (the one used longest ago first). *Gawa ulit* uses different wording.
- **Auto mode:** switch on **Auto-gumawa araw-araw** (1–5 per day, Philippine time). Blaze never keeps more than 3 videos waiting for you, and it never posts by itself.
- **Ping:** when a video is ready, the team Telegram/Discord chat gets a message (the same chat used by other bots).
- **Safety:** a job with `needs_approval` cannot reach `posting` until `approved` is true — checked in the pipeline, in `runJob`, in the tick, and again in the post step. The state machine has no move from `awaiting_approval` to `posting`.
- **Expired file:** the finished video is a temporary file on the server. If the server restarted before you approved, the video is made again (same text, same game) — when you press Play it is re-made so you can still watch it, and when you approve it is re-made and then posted.
- **Needs:** `ffmpeg` on the server (same as the editor), and at least one connected platform (API Settings) or `default_platforms`.
- **Endpoint actions added** (`/api/public/bot/video-editor-bot`, header `x-app-passcode`): `generate_game` `{ game_id?, variant?, platforms? }`, `approve` `{ id }`, `reject` `{ id, reason? }`, `preview` `{ id }` (returns the mp4). `enqueue` also accepts `needs_approval: true` for your own videos. `settings_set` accepts `auto_generate` and `auto_per_day`.
- **No database migration:** jobs and settings still live in `bot_state`.
- Tests: `src/test/video-approval.test.ts`.


---

## Enhance your own video (assigned to Reel)

**Where:** Content Studio → Video → **"I-enhance ang video mo"**.

1. Paste the link of a video you already made (direct public `https` file, e.g. `.mp4`; private/login links are refused).
2. Pick what Reel should improve:
   | Preset | What it does (ffmpeg) |
   |---|---|
   | `auto` — Auto Enhance | denoise (`hqdn3d`), brighter colour (`eq`), sharpen (`unsharp`), low-rumble filter + loudness normalising |
   | `sharper` | stronger sharpen |
   | `vivid` | more saturation + contrast |
   | `low_light` | brightens and denoises a dark video |
   | `clean_audio` | audio only: removes rumble/hiss band, normalises loudness; picture untouched |
3. Optional: size (Original / 9:16 / 16:9 / 1:1), title, and platforms.
4. Press **Ipa-enhance kay Reel**. The job is assigned to Reel (`assignee: "reel"`, `task: "enhance"`), edited, and stops at **awaiting approval** — it is NEVER posted by itself.
5. In **Para sa approval mo** you can **Panoorin** and **I-download** the enhanced video.
   - **No platform chosen** = download-only: *Tapos na, ayos na* closes the job as `done` (nothing is posted anywhere).
   - **Platforms chosen**: *Approve & i-post* → Blaze posts it. *Reject* never posts.

**Endpoint:** `POST /api/public/bot/video-editor-bot` (header `x-app-passcode`):
`{ "action": "enqueue", "task": "enhance", "input": "https://…/my-video.mp4", "edit": { "enhance": "auto", "aspect": "original" }, "post": { "title": "…", "platforms": [] } }`

**State machine:** `awaiting_approval → done` was added (terminal). `done` can never lead to `posting`. Tests: `src/test/video-enhance.test.ts` (includes a real-ffmpeg run of every preset when ffmpeg is installed).

## Reel in the office
- Reel is shown in the office (Dashboard) under the 3D floor: status (**Nag-e-edit / Hinihintay ka / Handa / May pumalya**) comes from the real video jobs, with a **Video Editor** button that opens the Studio tab.
- Boss Code Solo knows Reel is on the team, and the daily report counts Reel's finished video tasks.
- Reel is a status card, not a 3D character: the 3D scene (`Office3D.tsx`) has the four original bots hard-coded in many places.
