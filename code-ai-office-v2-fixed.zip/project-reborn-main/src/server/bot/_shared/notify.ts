// Sends a message to the TEAM chat: Telegram and/or Discord, whichever is saved in API Settings.
import { sendDiscord, sendTelegram, type Creds } from './publish.ts';

export async function notifyTeam(creds: Creds, text: string): Promise<{ sent: string[]; errors: string[] }> {
  const sent: string[] = [];
  const errors: string[] = [];
  if (creds.telegram?.bot_token?.trim() && creds.telegram?.chat_id?.trim()) {
    try { await sendTelegram(creds.telegram, text); sent.push('telegram'); } catch (e) { errors.push((e as Error).message); }
  }
  if (creds.discord?.webhook_url?.trim()) {
    try { await sendDiscord(creds.discord, text); sent.push('discord'); } catch (e) { errors.push((e as Error).message); }
  }
  return { sent, errors };
}
