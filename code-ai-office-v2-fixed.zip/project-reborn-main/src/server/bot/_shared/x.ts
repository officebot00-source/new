// X (Twitter) helpers for REPLIES. Posting lives in publish.ts (sendTwitter).
// X has no free real-time webhook, so the x-mentions-bot function polls the mentions timeline every couple of minutes.
// Needs the 4 OAuth 1.0a keys saved in API Settings → X (Twitter), and an X API plan that allows reading mentions.
import { oauth1Header, readError, sendTwitter } from './publish.ts';

export const X_API = 'https://api.twitter.com/2';

type Cfg = Record<string, string> | undefined;

export const hasXCreds = (c: Cfg) => ['api_key', 'api_secret', 'access_token', 'access_secret'].every((f) => (c?.[f] ?? '').trim() !== '');

async function xGet(cfg: Cfg, path: string, query: Record<string, string> = {}): Promise<Record<string, any>> {
  if (!hasXCreds(cfg)) throw new Error('X: missing keys — add them in API Settings');
  const base = `${X_API}${path}`;
  const qs = new URLSearchParams(query).toString();
  const res = await fetch(qs ? `${base}?${qs}` : base, {
    headers: { Authorization: await oauth1Header('GET', base, cfg as Record<string, string>, query) },
    signal: AbortSignal.timeout(20_000),
  });
  if (!res.ok) throw new Error(`X ${res.status}: ${await readError(res)}`);
  return await res.json();
}

/** Our own account (id + @handle). */
export async function getMe(cfg: Cfg): Promise<{ id: string; username: string }> {
  const j = await xGet(cfg, '/users/me');
  if (!j?.data?.id) throw new Error('X: could not read the account');
  return { id: String(j.data.id), username: String(j.data.username ?? '') };
}

export interface Mention {
  id: string; text: string; author_id: string; username: string; name: string; created_at: string;
  conversation_id: string; repliedTo?: string; isRetweet: boolean;
}

/** Numeric tweet-id compare (ids are too big for Number). */
export const idCmp = (a: string, b: string) => (a.length !== b.length ? a.length - b.length : a < b ? -1 : a > b ? 1 : 0);

/** Mentions of our account, newest first. `sinceId` = only newer than that tweet. */
export async function fetchMentions(cfg: Cfg, userId: string, sinceId?: string, max = 20): Promise<Mention[]> {
  if (!/^\d+$/.test(userId)) throw new Error('X: invalid user id');
  const q: Record<string, string> = {
    max_results: String(Math.min(100, Math.max(5, max))),
    'tweet.fields': 'created_at,author_id,conversation_id,referenced_tweets',
    expansions: 'author_id',
    'user.fields': 'username,name',
  };
  if (sinceId && /^\d+$/.test(sinceId)) q.since_id = sinceId;
  const j = await xGet(cfg, `/users/${userId}/mentions`, q);
  const users = new Map<string, { username: string; name: string }>();
  for (const u of j?.includes?.users ?? []) users.set(String(u.id), { username: String(u.username ?? ''), name: String(u.name ?? '') });
  return ((j?.data ?? []) as Record<string, any>[]).map((t) => {
    const refs = (t.referenced_tweets ?? []) as { type: string; id: string }[];
    const u = users.get(String(t.author_id));
    return {
      id: String(t.id), text: String(t.text ?? ''), author_id: String(t.author_id ?? ''), username: u?.username ?? '', name: u?.name ?? '',
      created_at: String(t.created_at ?? ''), conversation_id: String(t.conversation_id ?? ''),
      repliedTo: refs.find((r) => r.type === 'replied_to')?.id, isRetweet: refs.some((r) => r.type === 'retweeted'),
    };
  });
}

/** Text of one tweet (context for the AI). Never throws. */
export async function getTweetText(cfg: Cfg, tweetId?: string): Promise<string> {
  try {
    if (!tweetId || !/^\d+$/.test(tweetId)) return '';
    const j = await xGet(cfg, `/tweets/${tweetId}`, { 'tweet.fields': 'text' });
    return String(j?.data?.text ?? '');
  } catch { return ''; }
}

/** Public reply under a tweet. Returns the new tweet's id. */
export async function replyToTweet(cfg: Cfg, tweetId: string, message: string): Promise<{ id?: string }> {
  const r = await sendTwitter(cfg, message, tweetId);
  return { id: r.id };
}

/** Leading @handles are noise for the AI (X adds them to replies). */
export const stripHandles = (text: string) => text.replace(/^(\s*@\w+)+\s*/g, '').trim();
