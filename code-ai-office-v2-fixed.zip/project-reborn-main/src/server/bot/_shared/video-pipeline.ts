// Video Editor Bot + Real-Time Auto-Poster — the job pipeline (queued → editing → edited → posting → posted | failed | paused).
// All I/O is injected (`PipelineDeps`), so the same code runs against Supabase in production and an in-memory store in tests.
import {
  DEFAULT_VIDEO_SETTINGS, VIDEO_EDITOR_ASSIGNEE, backoffMs, classifyError, classifyMediaInput, isGated, transition, validateEditSpec, validatePostSpec,
  type VideoJob, type VideoJobSource, type VideoPostResult, type VideoSettings,
} from '@/lib/app/video';
import { planGameVideo, shouldAutoGenerate, type GameLite } from '@/lib/app/gameVideo';

export type LogFn = (level: 'info' | 'success' | 'warning' | 'error', source: string, message: string) => Promise<void>;
export interface Stored { job: VideoJob; rev: string }
export interface JobStore {
  insert(job: VideoJob): Promise<void>;
  get(id: string): Promise<Stored | null>;
  list(limit: number): Promise<Stored[]>;
  /** Compare-and-swap: writes only when nobody changed the job since `rev`. Returns the new rev, or null when it lost the race. */
  cas(id: string, rev: string, job: VideoJob): Promise<string | null>;
}
export interface EditOutcome { adapter: 'ffmpeg' | 'cloud' | 'mock'; outputPath?: string | undefined; outputUrl?: string | undefined; warnings: string[]; edited: boolean }
export interface PostOutcome { results: VideoPostResult[]; errors: string[] }

export interface PipelineDeps {
  store: JobStore;
  settings(): Promise<VideoSettings>;
  edit(job: VideoJob, settings: VideoSettings): Promise<EditOutcome>;
  post(job: VideoJob, platforms: string[]): Promise<PostOutcome>;
  fileExists(path: string): Promise<boolean>;
  cleanup(path?: string): Promise<void>;
  generateCaption?(job: VideoJob): Promise<string | null>;
  /** Called once a video is finished and waiting for the boss's yes/no (e.g. to send a Telegram/Discord ping). Never blocks the pipeline. */
  onReadyForReview?(job: VideoJob): Promise<void>;
  /** Makes one new game video (the bot picks the game). Called by the tick when the daily quota allows it. */
  autoGenerate?(): Promise<void>;
  log: LogFn;
  mediaDir: string;
  editTimeoutMs: number;
  postTimeoutMs: number;
  now(): Date;
  newId(): string;
}

export const STALE_MS = 10 * 60_000;
export const MAX_ATTEMPTS = 3;

export function withTimeout<T>(p: Promise<T>, ms: number, label: string): Promise<T> {
  let timer: ReturnType<typeof setTimeout>;
  const timeout = new Promise<never>((_, rej) => { timer = setTimeout(() => rej(new Error(`${label} timed out after ${Math.round(ms / 1000)}s`)), ms); });
  return Promise.race([p, timeout]).finally(() => clearTimeout(timer));
}

const msg = (e: unknown) => (e instanceof Error ? e.message : String(e));
const short = (j: VideoJob) => `"${j.post.title || j.post.caption.slice(0, 40) || j.id.slice(0, 8)}"`;

/* ---------- enqueue ---------- */
export async function enqueueJob(deps: PipelineDeps, body: Record<string, unknown>, source: VideoJobSource): Promise<{ ok: true; job: VideoJob } | { ok: false; error: string }> {
  const settings = await deps.settings();
  const media = classifyMediaInput(body['input'], deps.mediaDir);
  if (!media.ok) return { ok: false, error: media.error };
  // "Enhance my video": the boss pastes a link to a video he already made and Reel improves it. He always watches the result first.
  const enhance = body['task'] === 'enhance';
  const editRaw = enhance ? { aspect: 'original', normalize_audio: true, ...((body['edit'] && typeof body['edit'] === 'object' ? body['edit'] : {}) as Record<string, unknown>) } : body['edit'];
  const spec = validateEditSpec(editRaw);
  if (!spec.ok) return { ok: false, error: spec.error };
  if (enhance && !spec.spec.enhance) spec.spec.enhance = 'auto';
  // with no platform chosen, an enhanced video is download-only: nothing will ever be posted
  const post = enhance
    ? validatePostSpec(body['post'], [], { allowNoPlatforms: true })
    : validatePostSpec(body['post'], settings.default_platforms);
  if (!post.ok) return { ok: false, error: post.error };
  if (enhance && !post.post.title) post.post.title = 'Enhanced video';
  const at = deps.now().toISOString();
  const job: VideoJob = {
    id: deps.newId(), status: 'queued', source, input: media.input.value, spec: spec.spec, post: post.post,
    realtime: enhance ? false : body['realtime'] !== false, dry_run: typeof body['dry_run'] === 'boolean' ? body['dry_run'] : settings.dry_run,
    attempts: 0, max_attempts: MAX_ATTEMPTS, created_at: at, updated_at: at, stages: [{ at, status: 'queued', note: enhance ? `Assigned to Reel to enhance (${source})` : `Queued from ${source}` }], warnings: [],
    task: enhance ? 'enhance' : 'edit', assignee: VIDEO_EDITOR_ASSIGNEE,
    ...(enhance || body['needs_approval'] === true ? { needs_approval: true, approved: false } : {}),
  };
  await deps.store.insert(job);
  await deps.log('info', 'video-editor', enhance
    ? `Reel is enhancing your video ${short(job)} (${spec.spec.enhance}) — you will watch it before anything is posted.`
    : `Video job ${short(job)} queued (${source})${job.dry_run ? ' — dry run' : ''}${job.needs_approval ? ' — will wait for your approval' : ''}.`);
  return { ok: true, job };
}

/** A video made from a saved game. It ALWAYS waits for the boss's approval before anything is posted. */
export async function enqueueGameJob(deps: PipelineDeps, game: GameLite, o: { variant?: number; platforms?: string[]; source?: VideoJobSource } = {}): Promise<{ ok: true; job: VideoJob } | { ok: false; error: string }> {
  const settings = await deps.settings();
  const variant = Math.max(0, Math.trunc(o.variant ?? 0));
  const plan = planGameVideo(game, variant);
  const platforms = o.platforms?.length ? o.platforms : settings.default_platforms;
  const post = validatePostSpec({ title: plan.post_title, caption: plan.caption, tags: plan.tags, platforms, game_title: game.title, link: game.promo_link }, []);
  if (!post.ok) return { ok: false, error: post.error === 'Pick at least one platform (facebook, twitter, discord or telegram).' ? 'Walang platform na mapo-post-an: pumili ng platform o i-connect ang account sa API Settings.' : post.error };
  const spec = validateEditSpec({ kind: 'image', aspect: '9:16', normalize_audio: false, duration_sec: plan.duration_sec, title_text: plan.title_text, overlay_text: plan.overlay_text });
  if (!spec.ok) return { ok: false, error: spec.error };
  const at = deps.now().toISOString();
  const job: VideoJob = {
    id: deps.newId(), status: 'queued', source: o.source ?? 'worker', input: `game:${game.id}`, spec: spec.spec, post: post.post,
    realtime: false, dry_run: settings.dry_run, attempts: 0, max_attempts: MAX_ATTEMPTS, created_at: at, updated_at: at,
    stages: [{ at, status: 'queued', note: `Video for "${game.title}" queued` }], warnings: [],
    needs_approval: true, approved: false, game_id: game.id, variant, task: 'game', assignee: VIDEO_EDITOR_ASSIGNEE,
  };
  await deps.store.insert(job);
  await deps.log('info', 'video-editor', `Reel is making a video for "${game.title}" — it will wait for your approval before posting.`);
  return { ok: true, job };
}

/* ---------- failing ---------- */
async function fail(deps: PipelineDeps, cur: Stored, error: string, where: string): Promise<Stored | null> {
  const { transient } = classifyError(error);
  const willRetry = transient && cur.job.attempts < cur.job.max_attempts;
  const patch: Partial<VideoJob> = { error: error.slice(0, 500), auto_retry: willRetry };
  if (willRetry) patch.retry_after = new Date(deps.now().getTime() + backoffMs(cur.job.attempts)).toISOString();
  else delete cur.job.retry_after;
  let next: VideoJob;
  try { next = transition(cur.job, 'failed', `${where} failed: ${error}`, deps.now(), patch); } catch { return null; }
  const rev = await deps.store.cas(next.id, cur.rev, next);
  await deps.log('error', where === 'posting' ? 'auto-poster' : 'video-editor', `Video job ${short(next)} failed while ${where}: ${error}${willRetry ? ' — will retry automatically.' : ''}`);
  return rev ? { job: next, rev } : null;
}

/* ---------- stages ---------- */
async function editStage(deps: PipelineDeps, start: Stored, settings: VideoSettings): Promise<Stored | null> {
  let cur: Stored = start;
  const claimed = transition(cur.job, 'editing', 'Editing started', deps.now(), { attempts: cur.job.attempts + 1, error: null, auto_retry: false });
  const rev = await deps.store.cas(claimed.id, cur.rev, claimed);
  if (!rev) return null; // another run (or the user) took it
  cur = { job: claimed, rev };
  await deps.log('info', 'video-editor', `Editing ${short(claimed)} (${claimed.spec.aspect}${claimed.spec.start_sec !== undefined ? `, from ${claimed.spec.start_sec}s` : ''})…`);
  try {
    let caption = claimed.post.caption;
    const warnings: string[] = [];
    if (!caption && deps.generateCaption) {
      try { caption = (await withTimeout(deps.generateCaption(claimed), 20_000, 'Caption AI')) ?? ''; } catch (e) { warnings.push(`AI caption skipped: ${msg(e)}`); }
    }
    const out = await withTimeout(deps.edit(claimed, settings), deps.editTimeoutMs + 5_000, 'Editing');
    const review = isGated(cur.job);
    const done = transition(cur.job, review ? 'awaiting_approval' : 'edited', review ? 'Ready — waiting for your approval' : out.edited ? `Edited with ${out.adapter}` : 'Dry run (nothing edited)', deps.now(), {
      editor: out.adapter, output_path: out.outputPath, output_url: out.outputUrl,
      warnings: [...cur.job.warnings, ...warnings, ...out.warnings].slice(-10), post: { ...cur.job.post, caption },
    });
    const rev2 = await deps.store.cas(done.id, cur.rev, done);
    if (!rev2) return null;
    await deps.log('success', 'video-editor', `${review ? 'Finished' : 'Edited'} ${short(done)} with ${out.adapter}.${out.warnings.length ? ` Note: ${out.warnings.join(' ')}` : ''}${review ? ' Waiting for your approval — nothing is posted yet.' : ''}`);
    if (review && deps.onReadyForReview) await deps.onReadyForReview(done).catch((e) => deps.log('warning', 'video-editor', `Could not send the "ready for review" ping: ${msg(e)}`));
    return { job: done, rev: rev2 };
  } catch (e) {
    return fail(deps, cur, msg(e), 'editing');
  }
}

async function postStage(deps: PipelineDeps, start: Stored, settings: VideoSettings): Promise<Stored | null> {
  // Last line of defence: a video that needs the boss's yes is never sent without it, whoever calls this.
  if (isGated(start.job)) { await deps.log('warning', 'auto-poster', `Refused to post ${short(start.job)}: it has not been approved.`); return null; }
  const claimed = transition(start.job, 'posting', 'Posting started', deps.now(), { error: null, auto_retry: false });
  const rev = await deps.store.cas(claimed.id, start.rev, claimed);
  if (!rev) return null;
  const cur: Stored = { job: claimed, rev };
  const already = new Set((claimed.results ?? []).filter((r) => !r.note?.startsWith('failed')).map((r) => r.platform));
  const platforms = claimed.post.platforms.filter((p) => !already.has(p));
  const dry = claimed.dry_run || settings.dry_run;
  try {
    let outcome: PostOutcome;
    if (dry) {
      outcome = { results: platforms.map((platform) => ({ platform, note: 'Dry run — nothing was sent' })), errors: [] };
    } else {
      await deps.log('info', 'auto-poster', `Blaze is posting ${short(claimed)} to ${platforms.join(', ')}…`);
      outcome = await withTimeout(deps.post(claimed, platforms), deps.postTimeoutMs, 'Posting');
    }
    const sent = outcome.results.filter((r) => !r.note?.startsWith('failed'));
    if (!sent.length && !dry) throw new Error(outcome.errors.join('; ') || 'No platform accepted the post');
    const done = transition(cur.job, 'posted', dry ? 'Dry run complete' : `Posted to ${sent.map((r) => r.platform).join(', ')}`, deps.now(), {
      results: [...(claimed.results ?? []), ...outcome.results], error: outcome.errors.join('; ') || null,
    });
    const rev2 = await deps.store.cas(done.id, cur.rev, done);
    await deps.log(dry ? 'info' : 'success', 'auto-poster', `${dry ? 'DRY RUN' : 'LIVE'}: ${short(done)} → ${sent.map((r) => r.platform).join(', ') || platforms.join(', ')}${sent[0]?.url ? ` — ${sent[0].url}` : ''}`);
    if (outcome.errors.length) await deps.log('warning', 'auto-poster', `Some platforms failed for ${short(done)}: ${outcome.errors.join('; ')}`);
    await deps.cleanup(done.output_path);
    return rev2 ? { job: done, rev: rev2 } : null;
  } catch (e) {
    return fail(deps, cur, msg(e), 'posting');
  }
}

/** Runs one job as far as it can go right now: edit, then (when real-time is on) post. Safe to call twice at once. */
export async function runJob(deps: PipelineDeps, id: string, opts: { forcePost?: boolean } = {}): Promise<VideoJob | null> {
  let cur = await deps.store.get(id);
  if (!cur) return null;
  const settings = await deps.settings();
  if (cur.job.status === 'queued') {
    const next = await editStage(deps, cur, settings);
    if (!next) return (await deps.store.get(id))?.job ?? null;
    cur = next;
  }
  if (cur.job.status === 'edited' && isGated(cur.job)) {
    await deps.log('warning', 'auto-poster', `Refused to post ${short(cur.job)}: it has not been approved.`);
  } else if (cur.job.status === 'edited' && (opts.forcePost || cur.job.approved === true || (cur.job.realtime && settings.realtime_enabled))) {
    const next = await postStage(deps, cur, settings);
    if (next) cur = next;
    else return (await deps.store.get(id))?.job ?? null;
  } else if (cur.job.status === 'edited') {
    await deps.log('info', 'auto-poster', `Real-time posting is off — ${short(cur.job)} is edited and waiting for a manual post.`);
  }
  return cur.job;
}

/* ---------- user / webhook actions ---------- */
export async function retryJob(deps: PipelineDeps, id: string): Promise<{ ok: boolean; error?: string; job?: VideoJob }> {
  const cur = await deps.store.get(id);
  if (!cur) return { ok: false, error: 'Job not found' };
  if (cur.job.status !== 'failed') return { ok: false, error: `Only failed jobs can be retried (this one is ${cur.job.status}).` };
  const reusable = Boolean(cur.job.output_url) || (cur.job.output_path ? await deps.fileExists(cur.job.output_path) : false);
  const to = reusable ? 'edited' : 'queued';
  const next = transition(cur.job, to, `Retry requested (${reusable ? 'reusing the edited video' : 'editing again'})`, deps.now(), { error: null, auto_retry: false, attempts: Math.min(cur.job.attempts, cur.job.max_attempts - 1) });
  if (!(await deps.store.cas(id, cur.rev, next))) return { ok: false, error: 'The job changed at the same time — try again.' };
  await deps.log('info', 'video-editor', `Retrying ${short(next)}.`);
  return { ok: true, job: next };
}

/** The boss said yes: the video is posted now. If its temporary file is gone, it is made again first (same text, same game) and then posted. */
export async function approveJob(deps: PipelineDeps, id: string): Promise<{ ok: boolean; error?: string; job?: VideoJob }> {
  const cur = await deps.store.get(id);
  if (!cur) return { ok: false, error: 'Job not found' };
  if (cur.job.status !== 'awaiting_approval') return { ok: false, error: `Only videos waiting for approval can be approved (this one is ${cur.job.status}).` };
  const at = deps.now().toISOString();
  // An enhanced video with no platform chosen is download-only: approving it just closes the job. Nothing is ever posted.
  if (cur.job.task === 'enhance' && cur.job.post.platforms.length === 0) {
    const closed = transition(cur.job, 'done', 'Accepted by you — not posted (download only)', deps.now(), { approved: true, approved_at: at, error: null, auto_retry: false });
    if (!(await deps.store.cas(id, cur.rev, closed))) return { ok: false, error: 'The job changed at the same time — try again.' };
    await deps.log('success', 'video-editor', `You accepted the enhanced video ${short(closed)}. It was not posted anywhere.`);
    return { ok: true, job: closed };
  }
  const reusable = cur.job.dry_run || Boolean(cur.job.output_url) || (cur.job.output_path ? await deps.fileExists(cur.job.output_path) : false);
  const next = transition(cur.job, reusable ? 'edited' : 'queued', reusable ? 'Approved by you — posting now' : 'Approved by you — the video file expired, making it again before posting', deps.now(), {
    approved: true, approved_at: at, error: null, auto_retry: false, ...(reusable ? {} : { attempts: 0 }),
  });
  if (!(await deps.store.cas(id, cur.rev, next))) return { ok: false, error: 'The job changed at the same time — try again.' };
  await deps.log('success', 'video-editor', `You approved ${short(next)}.${reusable ? '' : ' Making the video again first.'}`);
  return { ok: true, job: next };
}

/** The boss said no: nothing is ever posted for this job, and its temporary file is deleted. */
export async function rejectJob(deps: PipelineDeps, id: string, reason = ''): Promise<{ ok: boolean; error?: string }> {
  const cur = await deps.store.get(id);
  if (!cur) return { ok: false, error: 'Job not found' };
  if (cur.job.status !== 'awaiting_approval') return { ok: false, error: `Only videos waiting for approval can be rejected (this one is ${cur.job.status}).` };
  const note = reason.trim().slice(0, 200);
  const next = transition(cur.job, 'rejected', note ? `Rejected by you: ${note}` : 'Rejected by you', deps.now(), { approved: false, rejected_reason: note, output_path: undefined });
  if (!(await deps.store.cas(id, cur.rev, next))) return { ok: false, error: 'The job changed at the same time — try again.' };
  await deps.cleanup(cur.job.output_path);
  await deps.log('info', 'video-editor', `You rejected ${short(next)}${note ? `: ${note}` : ''}. It will not be posted.`);
  return { ok: true };
}

export async function pauseJob(deps: PipelineDeps, id: string): Promise<{ ok: boolean; error?: string }> {
  const cur = await deps.store.get(id);
  if (!cur) return { ok: false, error: 'Job not found' };
  if (!['queued', 'editing', 'edited'].includes(cur.job.status)) return { ok: false, error: `Cannot pause a ${cur.job.status} job.` };
  const next = transition(cur.job, 'paused', 'Paused by user', deps.now(), { paused_from: cur.job.status });
  if (!(await deps.store.cas(id, cur.rev, next))) return { ok: false, error: 'The job changed at the same time — try again.' };
  await deps.log('info', 'video-editor', `Paused ${short(next)}.`);
  return { ok: true };
}

export async function resumeJob(deps: PipelineDeps, id: string): Promise<{ ok: boolean; error?: string }> {
  const cur = await deps.store.get(id);
  if (!cur) return { ok: false, error: 'Job not found' };
  if (cur.job.status !== 'paused') return { ok: false, error: 'Only paused jobs can be resumed.' };
  const to = cur.job.paused_from === 'edited' ? 'edited' : 'queued';
  const next = transition(cur.job, to, 'Resumed by user', deps.now());
  if (!(await deps.store.cas(id, cur.rev, next))) return { ok: false, error: 'The job changed at the same time — try again.' };
  await deps.log('info', 'video-editor', `Resumed ${short(next)}.`);
  return { ok: true };
}

/* ---------- the worker tick (cron every minute) ---------- */
export interface TickSummary { requeued: number; failedStale: number; autoRetried: number; edited: number; posted: number; skipped: number; generated: number }

export async function tick(deps: PipelineDeps, o: { maxJobs?: number; budgetMs?: number } = {}): Promise<TickSummary> {
  const started = deps.now().getTime();
  const sum: TickSummary = { requeued: 0, failedStale: 0, autoRetried: 0, edited: 0, posted: 0, skipped: 0, generated: 0 };
  const settings = { ...DEFAULT_VIDEO_SETTINGS, ...(await deps.settings()) };
  const all = await deps.store.list(100);
  const now = deps.now().getTime();

  for (const s of all) {
    const age = now - Date.parse(s.job.updated_at);
    if (s.job.status === 'editing' && age > STALE_MS) {
      if (s.job.attempts >= s.job.max_attempts) { await fail(deps, s, 'Editing got stuck and ran out of attempts', 'editing'); sum.failedStale++; continue; }
      const next = transition(s.job, 'queued', 'Editing got stuck — back in the queue', deps.now());
      if (await deps.store.cas(s.job.id, s.rev, next)) sum.requeued++;
    } else if (s.job.status === 'posting' && age > STALE_MS) {
      // Never re-send automatically: the post may have gone out before the crash.
      const next = transition(s.job, 'failed', 'Posting got stuck', deps.now(), { error: 'Posting got stuck — check the platforms before retrying so it is not posted twice.', auto_retry: false });
      if (await deps.store.cas(s.job.id, s.rev, next)) { sum.failedStale++; await deps.log('warning', 'auto-poster', `Video job ${short(next)} was stuck while posting — check the platforms before retrying.`); }
    } else if (s.job.status === 'failed' && s.job.auto_retry && s.job.attempts < s.job.max_attempts && Date.parse(s.job.retry_after ?? '') <= now) {
      const r = await retryJob(deps, s.job.id);
      if (r.ok) sum.autoRetried++;
    }
  }

  const fresh = await deps.store.list(100);
  const byAge = (a: Stored, b: Stored) => Date.parse(a.job.created_at) - Date.parse(b.job.created_at);
  const todo = [
    ...fresh.filter((s) => s.job.status === 'queued').sort(byAge),
    ...(settings.realtime_enabled ? fresh.filter((s) => s.job.status === 'edited' && s.job.realtime && !isGated(s.job)).sort(byAge) : []),
    // Approved jobs whose post did not finish (e.g. the app restarted) are picked up here; unapproved ones never are.
    ...fresh.filter((s) => s.job.status === 'edited' && s.job.approved === true && !(settings.realtime_enabled && s.job.realtime)).sort(byAge),
  ].slice(0, o.maxJobs ?? 2);
  for (const s of todo) {
    if (deps.now().getTime() - started > (o.budgetMs ?? 50_000)) { sum.skipped++; continue; }
    const out = await runJob(deps, s.job.id);
    if (out?.status === 'posted') sum.posted++;
    else if (out?.status === 'edited' || out?.status === 'awaiting_approval') sum.edited++;
  }

  // The bot works on its own: when it is allowed to and the quota / review pile allows it, it makes the next game video.
  if (deps.autoGenerate && shouldAutoGenerate(settings, (await deps.store.list(100)).map((s) => s.job), deps.now())) {
    try { await deps.autoGenerate(); sum.generated++; } catch (e) { await deps.log('error', 'video-editor', `Could not make a game video: ${msg(e)}`); }
  }
  return sum;
}

/* ---------- in-memory store (tests, local dry runs) ---------- */
export function memoryStore(): JobStore & { rows: Map<string, Stored> } {
  const rows = new Map<string, Stored>();
  let n = 0;
  return {
    rows,
    async insert(job) { rows.set(job.id, { job, rev: `r${++n}` }); },
    async get(id) { const r = rows.get(id); return r ? { job: structuredClone(r.job), rev: r.rev } : null; },
    async list(limit) { return [...rows.values()].slice(-limit).map((r) => ({ job: structuredClone(r.job), rev: r.rev })); },
    async cas(id, rev, job) { const r = rows.get(id); if (!r || r.rev !== rev) return null; const next = `r${++n}`; rows.set(id, { job: structuredClone(job), rev: next }); return next; },
  };
}
