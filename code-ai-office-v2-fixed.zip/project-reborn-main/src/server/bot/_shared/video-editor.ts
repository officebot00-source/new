// Video Editor Bot — pluggable editor adapters.
//   ffmpeg : real editing when the `ffmpeg` binary exists on this server
//   cloud  : any external editing API (VIDEO_EDITOR_API_URL [+ VIDEO_EDITOR_API_KEY]) that returns { output_url }
//   mock   : dry-run fallback, edits nothing (only allowed for dry-run jobs)
// Node APIs are loaded lazily, so a runtime without them (edge / worker) simply reports "ffmpeg not available" instead of crashing.
import { buildFfmpegArgs, buildGameClipArgs, classifyMediaInput, type VideoEditorChoice, type VideoEditSpec } from '@/lib/app/video';
import { ctaFor, type GameLite } from '@/lib/app/gameVideo';

const env = (k: string) => process.env[k] ?? '';

export interface EditRequest { jobId: string; input: string; spec: VideoEditSpec; timeoutMs: number }
export interface EditResult { adapter: 'ffmpeg' | 'cloud' | 'mock'; outputPath?: string; outputUrl?: string; warnings: string[]; edited: boolean }
export interface EditorAdapter {
  name: 'ffmpeg' | 'cloud' | 'mock';
  available(): Promise<{ ok: boolean; reason?: string }>;
  edit(req: EditRequest): Promise<EditResult>;
}

export const mediaDir = () => env('VIDEO_MEDIA_DIR').trim();
export const editTimeoutMs = () => Math.min(600_000, Math.max(10_000, Number(env('VIDEO_EDIT_TIMEOUT_MS')) || 120_000));

/* ---------- tiny process runner with a hard timeout ---------- */
interface RunResult { code: number | null; stderr: string; timedOut: boolean }
async function run(cmd: string, args: string[], timeoutMs: number): Promise<RunResult> {
  const { spawn } = await import('node:child_process');
  return new Promise((resolve, reject) => {
    let stderr = '';
    let timedOut = false;
    let child: ReturnType<typeof spawn>;
    try { child = spawn(cmd, args, { stdio: ['ignore', 'ignore', 'pipe'] }); } catch (e) { reject(e); return; }
    const timer = setTimeout(() => { timedOut = true; child.kill('SIGKILL'); }, timeoutMs);
    child.stderr?.on('data', (d: Buffer) => { stderr = (stderr + d.toString()).slice(-4000); });
    child.on('error', (e) => { clearTimeout(timer); reject(e); });
    child.on('close', (code) => { clearTimeout(timer); resolve({ code, stderr, timedOut }); });
  });
}

/* ---------- ffmpeg ---------- */
let ffmpegProbe: Promise<{ ok: boolean; reason?: string }> | null = null;
const ffmpegBin = () => env('FFMPEG_PATH').trim() || 'ffmpeg';

export const ffmpegAdapter: EditorAdapter = {
  name: 'ffmpeg',
  available() {
    ffmpegProbe ??= run(ffmpegBin(), ['-version'], 5000)
      .then((r) => (r.code === 0 ? { ok: true } : { ok: false, reason: 'ffmpeg exists but did not start correctly' }))
      .catch(() => ({ ok: false, reason: 'ffmpeg is not installed on this server (set FFMPEG_PATH or install it)' }));
    return ffmpegProbe;
  },
  async edit(req) {
    const [{ tmpdir }, fs, path] = await Promise.all([import('node:os'), import('node:fs/promises'), import('node:path')]);
    const media = classifyMediaInput(req.input, mediaDir());
    if (!media.ok) throw new Error(media.error);
    const dir = path.join(tmpdir(), 'video-editor');
    await fs.mkdir(dir, { recursive: true });
    const output = path.join(dir, `${req.jobId}.mp4`);
    const warnings: string[] = [];
    let fontFile = env('VIDEO_FONT_FILE').trim();
    if (!fontFile) {
      for (const f of ['/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf', '/usr/share/fonts/dejavu/DejaVuSans-Bold.ttf', '/Library/Fonts/Arial.ttf']) {
        try { await fs.access(f); fontFile = f; break; } catch { /* try the next */ }
      }
    }
    const attempt = (withText: boolean) => run(ffmpegBin(), buildFfmpegArgs({ input: media.input.value, output, spec: req.spec, withText, fontFile, isUrl: media.input.kind === 'url' }).args, req.timeoutMs);
    let r = await attempt(true);
    if (r.timedOut) throw new Error(`ffmpeg timed out after ${Math.round(req.timeoutMs / 1000)}s`);
    if (r.code !== 0 && req.spec.overlay_text) {
      // The text filter (drawtext / fonts) is the most common thing missing in a build — retry without it and say so.
      r = await attempt(false);
      if (r.timedOut) throw new Error(`ffmpeg timed out after ${Math.round(req.timeoutMs / 1000)}s`);
      if (r.code === 0) warnings.push('Text overlay could not be burned in (no drawtext/font support in this ffmpeg) — video was edited without it.');
    }
    if (r.code !== 0) throw new Error(`ffmpeg failed: ${r.stderr.trim().split('\n').slice(-3).join(' | ').slice(0, 400) || `exit code ${r.code}`}`);
    const st = await fs.stat(output).catch(() => null);
    if (!st || st.size < 1024) throw new Error('ffmpeg produced no usable output file');
    return { adapter: 'ffmpeg', outputPath: output, warnings, edited: true };
  },
};

/* ---------- game clip: a short vertical video made from a saved game's banner ---------- */
const MAX_BANNER_BYTES = 15 * 1024 * 1024;
const IMAGE_EXT: Record<string, string> = { 'image/jpeg': 'jpg', 'image/jpg': 'jpg', 'image/png': 'png', 'image/webp': 'webp', 'image/gif': 'gif' };

/** Saves the game's banner to a temp file. The app stores banners as data URLs; a public https image URL also works. Returns null when there is no usable image. */
async function saveBanner(banner: string | undefined, base: string, warnings: string[]): Promise<string | null> {
  const src = (banner ?? '').trim();
  if (!src) return null;
  const fs = await import('node:fs/promises');
  try {
    const data = /^data:(image\/[a-z0-9.+-]+);base64,(.*)$/is.exec(src);
    if (data) {
      const ext = IMAGE_EXT[data[1]!.toLowerCase()];
      if (!ext) { warnings.push(`Banner type ${data[1]} is not supported — used a plain background instead.`); return null; }
      const buf = Buffer.from(data[2]!, 'base64');
      if (!buf.length || buf.length > MAX_BANNER_BYTES) { warnings.push('Banner image is empty or too big — used a plain background instead.'); return null; }
      const file = `${base}.${ext}`;
      await fs.writeFile(file, buf);
      return file;
    }
    const media = classifyMediaInput(src, '');
    if (media.ok && media.input.kind === 'url') {
      const res = await fetch(media.input.value, { signal: AbortSignal.timeout(20_000), redirect: 'follow' });
      const ext = IMAGE_EXT[(res.headers.get('content-type') ?? '').split(';')[0]!.trim().toLowerCase()];
      if (!res.ok || !ext) { warnings.push('Banner link did not return a usable image — used a plain background instead.'); return null; }
      const buf = Buffer.from(await res.arrayBuffer());
      if (!buf.length || buf.length > MAX_BANNER_BYTES) { warnings.push('Banner image is too big — used a plain background instead.'); return null; }
      const file = `${base}.${ext}`;
      await fs.writeFile(file, buf);
      return file;
    }
    warnings.push('Banner is not a usable image — used a plain background instead.');
  } catch (e) {
    warnings.push(`Banner could not be loaded (${(e as Error).message.slice(0, 80)}) — used a plain background instead.`);
  }
  return null;
}

/** The cloud editor's game route: the same URL as VIDEO_EDITOR_API_URL with /render-game instead of /edit. */
export function gameRenderUrl(): string {
  const base = env('VIDEO_EDITOR_API_URL').trim().replace(/\/+$/, '');
  return base.endsWith('/edit') ? `${base.slice(0, -'/edit'.length)}/render-game` : `${base}/render-game`;
}

async function renderGameClipCloud(req: { jobId: string; game: GameLite; spec: VideoEditSpec; variant?: number; timeoutMs: number }): Promise<EditResult> {
  const headers: Record<string, string> = { 'Content-Type': 'application/json' };
  if (env('VIDEO_EDITOR_API_KEY')) headers['Authorization'] = `Bearer ${env('VIDEO_EDITOR_API_KEY')}`;
  const res = await fetch(gameRenderUrl(), {
    method: 'POST', headers,
    body: JSON.stringify({ game: { title: req.game.title, banner_image: req.game.banner_image ?? null }, variant: req.variant ?? 0, spec: req.spec }),
    signal: AbortSignal.timeout(req.timeoutMs),
  });
  if (!res.ok) throw new Error(`Cloud game render ${res.status}: ${(await res.text().catch(() => '')).slice(0, 200)}`);
  const j = (await res.json().catch(() => ({}))) as { output_url?: unknown; warnings?: unknown };
  const out = typeof j.output_url === 'string' ? classifyMediaInput(j.output_url, '') : null;
  if (!out?.ok || out.input.kind !== 'url') throw new Error('Cloud game render did not return a valid output_url');
  const warnings = Array.isArray(j.warnings) ? j.warnings.filter((w): w is string => typeof w === 'string') : [];
  return { adapter: 'cloud', outputUrl: out.input.value, warnings, edited: true };
}

export async function renderGameClip(req: { jobId: string; game: GameLite; spec: VideoEditSpec; variant?: number; timeoutMs: number }): Promise<EditResult> {
  const ff = await ffmpegAdapter.available();
  if (!ff.ok) {
    if ((await cloudAdapter.available()).ok) return renderGameClipCloud(req);
    throw new Error(`No way to render a game video: ffmpeg is not installed on this server (${ff.reason ?? 'unavailable'}) and VIDEO_EDITOR_API_URL is not set.`);
  }
  const [{ tmpdir }, fs, path] = await Promise.all([import('node:os'), import('node:fs/promises'), import('node:path')]);
  const dir = path.join(tmpdir(), 'video-editor');
  await fs.mkdir(dir, { recursive: true });
  const output = path.join(dir, `${req.jobId}.mp4`);
  const warnings: string[] = [];
  const image = await saveBanner(req.game.banner_image, path.join(dir, `${req.jobId}-banner`), warnings);
  let fontFile = env('VIDEO_FONT_FILE').trim();
  if (!fontFile) {
    for (const f of ['/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf', '/usr/share/fonts/dejavu/DejaVuSans-Bold.ttf', '/Library/Fonts/Arial.ttf']) {
      try { await fs.access(f); fontFile = f; break; } catch { /* try the next */ }
    }
  }
  try {
    const attempt = (withText: boolean) => run(ffmpegBin(), buildGameClipArgs({
      ...(image ? { imagePath: image } : {}), output, durationSec: req.spec.duration_sec ?? 12, title: req.spec.title_text ?? req.game.title,
      ...(req.spec.overlay_text ? { tagline: req.spec.overlay_text } : {}), cta: ctaFor(req.variant ?? 0), fontFile, withText,
    }).args, req.timeoutMs);
    let r = await attempt(true);
    if (r.timedOut) throw new Error(`ffmpeg timed out after ${Math.round(req.timeoutMs / 1000)}s`);
    if (r.code !== 0) {
      r = await attempt(false);
      if (r.timedOut) throw new Error(`ffmpeg timed out after ${Math.round(req.timeoutMs / 1000)}s`);
      if (r.code === 0) warnings.push('Text could not be burned in (no drawtext/font support in this ffmpeg) — the video has no title text.');
    }
    if (r.code !== 0) throw new Error(`ffmpeg failed: ${r.stderr.trim().split('\n').slice(-3).join(' | ').slice(0, 400) || `exit code ${r.code}`}`);
    const st = await fs.stat(output).catch(() => null);
    if (!st || st.size < 1024) throw new Error('ffmpeg produced no usable output file');
    return { adapter: 'ffmpeg', outputPath: output, warnings, edited: true };
  } finally {
    if (image) await fs.unlink(image).catch(() => undefined);
  }
}

/* ---------- cloud / external API ---------- */
export const cloudAdapter: EditorAdapter = {
  name: 'cloud',
  async available() {
    const url = env('VIDEO_EDITOR_API_URL').trim();
    if (!url) return { ok: false, reason: 'VIDEO_EDITOR_API_URL is not set' };
    try {
      const u = new URL(url);
      return u.protocol === 'https:' ? { ok: true } : { ok: false, reason: 'VIDEO_EDITOR_API_URL must be https' };
    } catch { return { ok: false, reason: 'VIDEO_EDITOR_API_URL is not a valid URL' }; }
  },
  async edit(req) {
    const media = classifyMediaInput(req.input, '');
    if (!media.ok || media.input.kind !== 'url') throw new Error('Cloud editor needs a public video URL');
    const headers: Record<string, string> = { 'Content-Type': 'application/json' };
    if (env('VIDEO_EDITOR_API_KEY')) headers['Authorization'] = `Bearer ${env('VIDEO_EDITOR_API_KEY')}`;
    const res = await fetch(env('VIDEO_EDITOR_API_URL').trim(), {
      method: 'POST', headers, body: JSON.stringify({ input_url: media.input.value, edit: req.spec }), signal: AbortSignal.timeout(req.timeoutMs),
    });
    if (!res.ok) throw new Error(`Cloud editor ${res.status}: ${(await res.text().catch(() => '')).slice(0, 200)}`);
    const j = (await res.json().catch(() => ({}))) as { output_url?: unknown };
    const out = typeof j.output_url === 'string' ? classifyMediaInput(j.output_url, '') : null;
    if (!out?.ok || out.input.kind !== 'url') throw new Error('Cloud editor did not return a valid output_url');
    return { adapter: 'cloud', outputUrl: out.input.value, warnings: [], edited: true };
  },
};

/* ---------- mock / dry run ---------- */
export const mockAdapter: EditorAdapter = {
  name: 'mock',
  async available() { return { ok: true }; },
  async edit(req) {
    const media = classifyMediaInput(req.input, mediaDir());
    if (!media.ok) throw new Error(media.error);
    return { adapter: 'mock', outputUrl: media.input.kind === 'url' ? media.input.value : undefined, warnings: ['Dry run: nothing was edited (mock editor).'], edited: false };
  },
};

const ADAPTERS: Record<'ffmpeg' | 'cloud' | 'mock', EditorAdapter> = { ffmpeg: ffmpegAdapter, cloud: cloudAdapter, mock: mockAdapter };

/** Picks the adapter. `auto` = ffmpeg → cloud → (dry-run only) mock. Throws a clear message when nothing can edit. */
export async function pickAdapter(choice: VideoEditorChoice, dryRun: boolean): Promise<EditorAdapter> {
  const order: ('ffmpeg' | 'cloud' | 'mock')[] = choice === 'auto' ? ['ffmpeg', 'cloud'] : [choice];
  const why: string[] = [];
  for (const name of order) {
    const a = ADAPTERS[name];
    const s = await a.available();
    if (s.ok) {
      if (name === 'mock' && !dryRun) throw new Error('Mock editor only works in dry-run mode — turn on Dry run, or install ffmpeg / set a cloud editor.');
      return a;
    }
    why.push(`${name}: ${s.reason ?? 'unavailable'}`);
  }
  if (dryRun) return mockAdapter;
  throw new Error(`No video editor available (${why.join('; ')}). Install ffmpeg, configure VIDEO_EDITOR_API_URL, or enable Dry run.`);
}

/** Checks, BEFORE a job is created, that a game video can be rendered: local ffmpeg, or the cloud editor service.
 *  Returns the reason, or null when ready. Dry run needs no editor (the caller skips this check then). */
export async function gameRenderProblem(): Promise<string | null> {
  if ((await ffmpegAdapter.available()).ok) return null;
  const cloud = await cloudAdapter.available();
  if (cloud.ok) return null;
  const onNetlify = Boolean(env('NETLIFY')) || env('VITE_DEPLOY_TARGET') === 'netlify';
  // A cloud editor that IS set but wrong (e.g. http instead of https) needs a different fix than one that is simply missing.
  if (!/not set/i.test(cloud.reason ?? '')) {
    return `Hindi makagawa ng game video: may mali sa VIDEO_EDITOR_API_URL (${cloud.reason}). Ayusin ito (dapat https://<video-service>/edit), tapos Clear cache and deploy. O i-on ang Dry run para subukan ang flow nang walang totoong video.`;
  }
  return `Hindi makagawa ng game video: ${onNetlify ? 'walang ffmpeg ang Netlify' : 'walang ffmpeg ang server na ito'}, at wala pang video service na naka-set (VIDEO_EDITOR_API_URL). ` +
    `Ayusin sa 3 hakbang: (1) i-deploy ang video-editor-service sa Render / Railway / Fly (may render.yaml na, tingnan ang docs/video-service-deploy.md); ` +
    `(2) sa ${onNetlify ? 'Netlify → Site configuration → Environment variables' : 'Environment variables'} ilagay ang VIDEO_EDITOR_API_URL = https://<video-service>/edit at VIDEO_EDITOR_API_KEY (parehong key sa service); ` +
    `(3) Clear cache and deploy. Pang-test lang ng flow: i-on ang Dry run (walang totoong video).`;
}
export async function editorProblem(choice: VideoEditorChoice, dryRun: boolean): Promise<string | null> {
  if (dryRun) return null;
  try { await pickAdapter(choice, false); return null; } catch (e) { return (e as Error).message; }
}

export async function removeTempFile(path?: string): Promise<void> {
  if (!path) return;
  try { await (await import('node:fs/promises')).unlink(path); } catch { /* already gone */ }
}

/** Test hook: forget the cached ffmpeg probe. */
export const resetFfmpegProbe = () => { ffmpegProbe = null; };
