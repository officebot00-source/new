// Real-Time Auto-Poster: sends the edited video to each platform with its caption.
//   Telegram / Discord / Facebook : the video file itself (or its public URL when there is no local file)
//   X (Twitter)                   : text + link only (X's chunked media upload is not implemented) — reported in the result note
import { buildCaption, type VideoJob, type VideoPostResult } from '@/lib/app/video';
import { readError, resolveFacebookPageToken, sendTo, type Creds } from './publish.ts';
import type { PostOutcome } from './video-pipeline.ts';

const MB = 1024 * 1024;
const LIMITS: Record<string, number> = { telegram: 49 * MB, discord: 24 * MB, facebook: 200 * MB };

const need = (c: Record<string, string> | undefined, fields: string[], name: string) => {
  const missing = fields.filter((f) => !c?.[f]?.trim());
  if (missing.length) throw new Error(`${name}: missing ${missing.join(', ')} — add it in API Settings`);
  return c as Record<string, string>;
};

async function loadFile(path?: string): Promise<{ blob: Blob; size: number } | null> {
  if (!path) return null;
  try {
    const fs = await import('node:fs/promises');
    const buf = await fs.readFile(path);
    return { blob: new Blob([new Uint8Array(buf)], { type: 'video/mp4' }), size: buf.byteLength };
  } catch { return null; }
}

function discordUrl(raw: string): URL {
  let u: URL;
  try { u = new URL(raw.trim()); } catch { throw new Error('Discord: the webhook URL is not a valid URL'); }
  if (u.protocol !== 'https:' || !['discord.com', 'discordapp.com', 'ptb.discord.com', 'canary.discord.com'].includes(u.hostname) || !u.pathname.startsWith('/api/webhooks/')) {
    throw new Error('Discord: the webhook URL must look like https://discord.com/api/webhooks/…');
  }
  u.searchParams.set('wait', 'true');
  return u;
}

async function sendOne(platform: string, job: VideoJob, creds: Creds, file: { blob: Blob; size: number } | null): Promise<VideoPostResult> {
  const url = job.output_url;
  const caption = buildCaption(job.post, platform, file ? undefined : url);
  const fits = file ? file.size <= (LIMITS[platform] ?? 0) : false;
  const textOnly = async (why: string): Promise<VideoPostResult> => {
    const r = await sendTo(platform, creds, buildCaption(job.post, platform, url));
    return { platform, ...r, note: why };
  };

  if (platform === 'telegram') {
    const c = need(creds['telegram'], ['bot_token', 'chat_id'], 'Telegram');
    if (!fits && !url) return textOnly(file ? 'Video too large for Telegram — posted the caption only' : 'No video file available — posted the caption only');
    const form = new FormData();
    form.set('chat_id', c['chat_id']!.trim());
    form.set('caption', caption.slice(0, 1024));
    form.set('supports_streaming', 'true');
    if (fits && file) form.set('video', file.blob, 'video.mp4'); else form.set('video', url!);
    const res = await fetch(`https://api.telegram.org/bot${c['bot_token']!.trim()}/sendVideo`, { method: 'POST', body: form });
    if (!res.ok) throw new Error(`Telegram ${res.status}: ${await readError(res)}`);
    const j = await res.json().catch(() => ({}));
    const id = j?.result?.message_id;
    const uname = j?.result?.chat?.username;
    return { platform, id: id ? String(id) : undefined, url: uname && id ? `https://t.me/${uname}/${id}` : undefined };
  }

  if (platform === 'discord') {
    const c = need(creds['discord'], ['webhook_url'], 'Discord');
    const endpoint = discordUrl(c['webhook_url']!);
    if (!fits || !file) return textOnly(file ? 'Video too large for Discord — posted the caption and link' : 'No video file available — posted the caption and link');
    const form = new FormData();
    form.set('payload_json', JSON.stringify({ content: caption.slice(0, 1900) }));
    form.set('files[0]', file.blob, 'video.mp4');
    const res = await fetch(endpoint, { method: 'POST', body: form });
    if (!res.ok) throw new Error(`Discord ${res.status}: ${await readError(res)}`);
    const j = await res.json().catch(() => ({}));
    return { platform, id: j?.id };
  }

  if (platform === 'facebook') {
    const c = need(creds['facebook'], ['page_id', 'access_token'], 'Facebook');
    const page = encodeURIComponent(c['page_id']!.trim());
    const form = new FormData();
    form.set('access_token', await resolveFacebookPageToken(c['page_id']!, c['access_token']!));
    form.set('description', caption);
    if (job.post.title) form.set('title', job.post.title.slice(0, 100));
    let endpoint = `https://graph.facebook.com/v21.0/${page}/videos`;
    if (url) form.set('file_url', url);
    else if (fits && file) { endpoint = `https://graph-video.facebook.com/v21.0/${page}/videos`; form.set('source', file.blob, 'video.mp4'); }
    else return textOnly(file ? 'Video too large for Facebook upload — posted the caption only' : 'No video file available — posted the caption only');
    const res = await fetch(endpoint, { method: 'POST', body: form });
    if (!res.ok) throw new Error(`Facebook ${res.status}: ${await readError(res)}`);
    const j = await res.json().catch(() => ({}));
    return { platform, id: j?.id, url: j?.id ? `https://www.facebook.com/watch/?v=${j.id}` : undefined };
  }

  if (platform === 'twitter') {
    return textOnly(url ? 'X: posted text + video link (native video upload is not enabled)' : 'X: native video upload is not enabled — posted the caption only');
  }
  throw new Error(`Unknown platform "${platform}"`);
}

export async function postVideo(job: VideoJob, platforms: string[], creds: Creds): Promise<PostOutcome> {
  const file = await loadFile(job.output_path);
  if (!file && !job.output_url) return { results: [], errors: ['The edited video file is no longer on the server — retry to edit it again.'] };
  const results: VideoPostResult[] = [];
  const errors: string[] = [];
  for (const platform of platforms) {
    try { results.push(await sendOne(platform, job, creds, file)); }
    catch (e) { errors.push(`${platform}: ${(e as Error).message}`); results.push({ platform, note: `failed: ${(e as Error).message}`.slice(0, 200) }); }
  }
  return { results, errors };
}
