// Real publishing to Facebook Pages, Discord, Telegram and X (Twitter).
// Credentials live ONLY in the service-only table `integration_secrets` (the browser can never read them back);
// the old environment secrets (DISCORD_WEBHOOK_URL, TELEGRAM_BOT_TOKEN, TELEGRAM_CHAT_ID) still work as a fallback.
import type { SupabaseClient } from '@supabase/supabase-js';
import { checkAiKey } from './ai.ts';
import { fitTweet } from './tweet.ts';

export const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type, Authorization, X-Client-Info, Apikey, X-App-Passcode',
};

const env = (k: string) => process.env[k] ?? '';

/** Server password (the APP_PASSCODE secret). FAIL-CLOSED: if it is not set, every protected call is refused. */
export function authorized(req: Request): boolean {
  const pass = env('APP_PASSCODE');
  if (!pass) return false;
  return safeEqual(req.headers.get('x-app-passcode') ?? '', pass);
}

/** Constant-time string compare (no early exit, so timing does not leak how many characters matched). */
export function safeEqual(a: string, b: string): boolean {
  const len = Math.max(a.length, b.length);
  let diff = a.length ^ b.length;
  for (let i = 0; i < len; i++) diff |= (a.charCodeAt(i) || 0) ^ (b.charCodeAt(i) || 0);
  return diff === 0;
}

/** True when the caller is the database itself (pg_cron sends the service-role key as the bearer). */
export function isServiceCall(req: Request): boolean {
  const key = env('SUPABASE_SERVICE_ROLE_KEY');
  const bearer = (req.headers.get('authorization') ?? '').replace(/^Bearer\s+/i, '');
  return key !== '' && safeEqual(bearer, key);
}

export const json = (body: unknown, status = 200) =>
  new Response(JSON.stringify(body), { status, headers: { ...corsHeaders, 'Content-Type': 'application/json' } });

export type Creds = Record<string, Record<string, string>>;

export const FIELDS: Record<string, string[]> = {
  openai: ['model', 'api_key'],
  facebook: ['page_id', 'access_token'],
  discord: ['webhook_url'],
  telegram: ['bot_token', 'chat_id'],
  twitter: ['api_key', 'api_secret', 'access_token', 'access_secret'],
};

export async function loadCreds(sb: SupabaseClient): Promise<Creds> {
  const { data } = await sb.from('integration_secrets').select('provider, secrets');
  const creds: Creds = {};
  for (const row of data ?? []) creds[row.provider as string] = (row.secrets ?? {}) as Record<string, string>;
  creds.discord ??= {};
  creds.telegram ??= {};
  if (!creds.discord.webhook_url && env('DISCORD_WEBHOOK_URL')) creds.discord.webhook_url = env('DISCORD_WEBHOOK_URL');
  if (!creds.telegram.bot_token && env('TELEGRAM_BOT_TOKEN')) creds.telegram.bot_token = env('TELEGRAM_BOT_TOKEN');
  if (!creds.telegram.chat_id && env('TELEGRAM_CHAT_ID')) creds.telegram.chat_id = env('TELEGRAM_CHAT_ID');
  return creds;
}

export interface SendResult { id?: string; url?: string }

const need = (c: Record<string, string> | undefined, fields: string[], name: string) => {
  const missing = fields.filter((f) => !c?.[f]?.trim());
  if (missing.length) throw new Error(`${name}: missing ${missing.join(', ')} — add it in API Settings`);
  return c as Record<string, string>;
};

export async function readError(res: Response): Promise<string> {
  const text = await res.text().catch(() => '');
  try {
    const j = JSON.parse(text);
    return j?.error?.message ?? j?.description ?? j?.message ?? j?.detail ?? j?.title ?? text.slice(0, 200);
  } catch {
    return text.slice(0, 200);
  }
}

/** Only real Discord webhook hosts are allowed, so a saved URL can never point this server at something else. */
function checkDiscordUrl(raw: string): string {
  let u: URL;
  try { u = new URL(raw); } catch { throw new Error('Discord: the webhook URL is not a valid URL'); }
  const okHost = ['discord.com', 'discordapp.com', 'ptb.discord.com', 'canary.discord.com'].includes(u.hostname);
  if (u.protocol !== 'https:' || !okHost || !u.pathname.startsWith('/api/webhooks/')) {
    throw new Error('Discord: the webhook URL must look like https://discord.com/api/webhooks/…');
  }
  return u.toString();
}

export async function sendDiscord(c: Record<string, string> | undefined, text: string): Promise<SendResult> {
  const cfg = need(c, ['webhook_url'], 'Discord');
  const url = new URL(checkDiscordUrl(cfg.webhook_url.trim()));
  url.searchParams.set('wait', 'true');
  const res = await fetch(url, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ content: text.slice(0, 1990) }) });
  if (!res.ok) throw new Error(`Discord ${res.status}: ${await readError(res)}`);
  const j = await res.json().catch(() => ({}));
  return { id: j?.id };
}

export async function sendTelegram(c: Record<string, string> | undefined, text: string, chatOverride?: string): Promise<SendResult> {
  const cfg = need(c, ['bot_token'], 'Telegram');
  const chat = (chatOverride || cfg.chat_id || '').trim();
  if (!chat) throw new Error('Telegram: missing chat_id — add it in API Settings');
  const res = await fetch(`https://api.telegram.org/bot${cfg.bot_token.trim()}/sendMessage`, {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ chat_id: chat, text: text.slice(0, 4000) }),
  });
  if (!res.ok) throw new Error(`Telegram ${res.status}: ${await readError(res)}`);
  const j = await res.json().catch(() => ({}));
  const id = j?.result?.message_id;
  const uname = j?.result?.chat?.username;
  return { id: id ? String(id) : undefined, url: uname && id ? `https://t.me/${uname}/${id}` : undefined };
}

/** Plain-language fix for the Facebook errors people actually hit. Meta's own message is always kept at the end. */
export function explainFacebookError(status: number, raw: string): string {
  const base = `Facebook ${status}: ${raw}`;
  const code = /\(#(\d+)\)/.exec(raw)?.[1];
  if (code === '200' || /pages_manage_posts|pages_read_engagement/.test(raw)) {
    return `${base}\n→ Hindi pwedeng mag-post ang token na ito sa Page. Ayusin: (1) Gamitin ang PAGE access token, hindi ang User token (Graph API Explorer → piliin ang Page sa "User or Page" bago mag-Generate). ` +
      `(2) Dapat kasama sa permissions ang pages_manage_posts at pages_read_engagement (dagdag pa ang pages_show_list para makuha ang Page token). ` +
      `(3) Ang nag-generate ay dapat admin ng Page na may Full control / Create content. (4) Ang Page ID ay dapat ng mismong Page, hindi ng personal profile o group. ` +
      `(5) Kung Development mode ang app, dapat ikaw ay admin/developer/tester ng app. Pagkatapos, i-save ulit ang bagong token sa API Settings.`;
  }
  if (code === '190' || status === 401) return `${base}\n→ Expired o na-revoke ang token. Gumawa ng bago (mas mainam ang long-lived Page token) at i-save sa API Settings.`;
  if (code === '100') return `${base}\n→ Mukhang mali ang Page ID, o hindi nakikita ng token ang Page na iyon.`;
  return base;
}

/**
 * If the saved token is a USER token (the usual cause of #200), swap it for the Page's own token.
 * Works when that user is an admin of the Page and the token has pages_show_list / pages_manage_posts.
 * A token that is already a Page token is returned unchanged. Never throws: on any failure the original token is used.
 */
export async function resolveFacebookPageToken(pageId: string, token: string): Promise<string> {
  const page = encodeURIComponent(pageId.trim()), tok = token.trim();
  try {
    const r = await fetch(`https://graph.facebook.com/v21.0/${page}?fields=access_token&access_token=${encodeURIComponent(tok)}`, { signal: AbortSignal.timeout(10_000) });
    if (r.ok) {
      const t = (await r.json().catch(() => ({})))?.access_token;
      if (typeof t === 'string' && t) return t;
    }
  } catch { /* fall through */ }
  try {
    const r = await fetch(`https://graph.facebook.com/v21.0/me/accounts?fields=id,access_token&limit=100&access_token=${encodeURIComponent(tok)}`, { signal: AbortSignal.timeout(10_000) });
    if (r.ok) {
      const list = ((await r.json().catch(() => ({})))?.data ?? []) as { id?: string; access_token?: string }[];
      const hit = list.find((a) => String(a.id) === pageId.trim());
      if (hit?.access_token) return hit.access_token;
    }
  } catch { /* fall through */ }
  return tok;
}

/**
 * Explains WHY a Facebook post got #200 by asking Graph what the saved token and Page ID really are.
 * Never throws; returns a short multi-line report that is appended to the error message.
 */
export async function diagnoseFacebookToken(pageId: string, token: string): Promise<string> {
  const g = async (path: string, tok = token.trim()) => {
    try {
      const r = await fetch(`https://graph.facebook.com/v21.0/${path}${path.includes('?') ? '&' : '?'}access_token=${encodeURIComponent(tok)}`, { signal: AbortSignal.timeout(10_000) });
      return { ok: r.ok, j: await r.json().catch(() => ({})) as Record<string, any> };
    } catch { return { ok: false, j: {} as Record<string, any> }; }
  };
  const lines: string[] = [];
  const id = pageId.trim();
  const me = await g('me?fields=id,name');
  const target = await g(`${encodeURIComponent(id)}?fields=id,name,category,link`);
  if (!target.ok) lines.push(`• Ang Page ID "${id}" ay hindi nababasa ng token: ${target.j?.error?.message ?? 'unknown error'}. Mali ang ID, o hindi admin ng Page na iyon ang may-ari ng token.`);
  else if (!target.j?.category) lines.push(`• Ang ID "${id}" (${target.j?.name ?? '?'}) ay mukhang HINDI Facebook Page (walang category) — baka profile o group. Kunin ang Page ID sa Page → About → Page transparency.`);
  else lines.push(`• Page: "${target.j?.name}" (${id}) ✓`);
  if (me.ok) {
    const isPage = String(me.j?.id) === id;
    lines.push(isPage ? `• Token: Page token ✓` : `• Token: USER token (${me.j?.name ?? me.j?.id}) — at hindi ito na-convert sa Page token. Ibig sabihin hindi ka admin ng Page na ito, o kulang ang pages_show_list.`);
    if (!isPage) {
      const perms = await g('me/permissions');
      const granted = ((perms.j?.data ?? []) as { permission: string; status: string }[]).filter((x) => x.status === 'granted').map((x) => x.permission);
      if (granted.length) {
        const need = ['pages_show_list', 'pages_read_engagement', 'pages_manage_posts'].filter((x) => !granted.includes(x));
        lines.push(need.length ? `• KULANG na permissions: ${need.join(', ')}. (Meron: ${granted.join(', ')})` : `• Kumpleto ang permissions (${granted.join(', ')}) pero hindi pa rin nakikita ang Page — baka hindi ka admin ng Page, o hindi napili ang Page sa permission dialog (i-Generate ulit at i-check ang Page).`);
      }
      const accts = await g('me/accounts?fields=id,name&limit=100');
      const list = ((accts.j?.data ?? []) as { id: string; name: string }[]);
      lines.push(accts.ok ? `• Mga Page na ma-manage ng token: ${list.length ? list.map((a) => `${a.name} (${a.id})`).join(', ') : 'WALA'}` : '• Hindi mabasa ang /me/accounts (kulang ang pages_show_list).');
    }
  } else lines.push(`• Hindi mabasa ang /me: ${me.j?.error?.message ?? 'invalid token'}.`);
  return `\n\nDIAGNOSIS:\n${lines.join('\n')}`;
}

export async function sendFacebook(c: Record<string, string> | undefined, text: string): Promise<SendResult> {
  const cfg = need(c, ['page_id', 'access_token'], 'Facebook');
  const pageToken = await resolveFacebookPageToken(cfg.page_id, cfg.access_token);
  const body = new URLSearchParams({ message: text, access_token: pageToken });
  const res = await fetch(`https://graph.facebook.com/v21.0/${encodeURIComponent(cfg.page_id.trim())}/feed`, { method: 'POST', body });
  if (!res.ok) {
    const raw = await readError(res);
    const extra = /\(#200\)|pages_manage_posts/.test(raw) ? await diagnoseFacebookToken(cfg.page_id, cfg.access_token) : '';
    throw new Error(explainFacebookError(res.status, raw) + extra);
  }
  const j = await res.json().catch(() => ({}));
  return { id: j?.id, url: j?.id ? `https://www.facebook.com/${j.id}` : undefined };
}

/* ---- X (Twitter): OAuth 1.0a user context, HMAC-SHA1 ---- */
const rfc3986 = (s: string) => encodeURIComponent(s).replace(/[!'()*]/g, (ch) => `%${ch.charCodeAt(0).toString(16).toUpperCase()}`);

export async function oauth1Header(method: string, url: string, c: Record<string, string>, query: Record<string, string> = {}): Promise<string> {
  const oauth: Record<string, string> = {
    oauth_consumer_key: c.api_key.trim(),
    oauth_nonce: crypto.randomUUID().replace(/-/g, ''),
    oauth_signature_method: 'HMAC-SHA1',
    oauth_timestamp: String(Math.floor(Date.now() / 1000)),
    oauth_token: c.access_token.trim(),
    oauth_version: '1.0',
  };
  const all = { ...query, ...oauth };
  const paramString = Object.keys(all).sort().map((k) => `${rfc3986(k)}=${rfc3986(all[k])}`).join('&');
  const base = [method.toUpperCase(), rfc3986(url), rfc3986(paramString)].join('&');
  const key = `${rfc3986(c.api_secret.trim())}&${rfc3986(c.access_secret.trim())}`;
  const k = await crypto.subtle.importKey('raw', new TextEncoder().encode(key), { name: 'HMAC', hash: 'SHA-1' }, false, ['sign']);
  const sig = new Uint8Array(await crypto.subtle.sign('HMAC', k, new TextEncoder().encode(base)));
  oauth.oauth_signature = btoa(String.fromCharCode(...sig));
  return 'OAuth ' + Object.keys(oauth).sort().map((n) => `${rfc3986(n)}="${rfc3986(oauth[n])}"`).join(', ');
}

/** Posts to X. `replyTo` makes it a reply under that tweet. Over-long text is shortened smartly (link + hashtags are kept). */
export async function sendTwitter(c: Record<string, string> | undefined, text: string, replyTo?: string): Promise<SendResult> {
  const cfg = need(c, ['api_key', 'api_secret', 'access_token', 'access_secret'], 'X (Twitter)');
  const url = 'https://api.twitter.com/2/tweets';
  const payload: Record<string, unknown> = { text: fitTweet(text) };
  if (replyTo) {
    if (!/^\d+$/.test(replyTo)) throw new Error('X: invalid tweet id');
    payload.reply = { in_reply_to_tweet_id: replyTo };
  }
  const res = await fetch(url, {
    method: 'POST',
    headers: { Authorization: await oauth1Header('POST', url, cfg), 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
    signal: AbortSignal.timeout(20_000),
  });
  if (!res.ok) throw new Error(`X ${res.status}: ${await readError(res)}`);
  const j = await res.json().catch(() => ({}));
  const id = j?.data?.id;
  return { id, url: id ? `https://x.com/i/web/status/${id}` : undefined };
}

export async function sendTo(platform: string, creds: Creds, text: string): Promise<SendResult> {
  switch (platform) {
    case 'discord': return sendDiscord(creds.discord, text);
    case 'telegram': return sendTelegram(creds.telegram, text);
    case 'facebook': return sendFacebook(creds.facebook, text);
    case 'twitter': return sendTwitter(creds.twitter, text);
    default: throw new Error(`Unknown platform "${platform}"`);
  }
}

/** Checks the saved credentials against the real service without posting anything. */
export async function checkConnection(provider: string, creds: Creds): Promise<string> {
  const c = creds[provider];
  if (provider === 'discord') {
    const cfg = need(c, ['webhook_url'], 'Discord');
    const res = await fetch(checkDiscordUrl(cfg.webhook_url.trim()));
    if (!res.ok) throw new Error(`Discord ${res.status}: ${await readError(res)}`);
    const j = await res.json().catch(() => ({}));
    return `Webhook OK${j?.name ? ` — "${j.name}"` : ''}`;
  }
  if (provider === 'telegram') {
    const cfg = need(c, ['bot_token'], 'Telegram');
    const me = await fetch(`https://api.telegram.org/bot${cfg.bot_token.trim()}/getMe`);
    if (!me.ok) throw new Error(`Telegram ${me.status}: ${await readError(me)}`);
    const mj = await me.json();
    let detail = `Bot @${mj?.result?.username ?? '?'} OK`;
    if (cfg.chat_id?.trim()) {
      const ch = await fetch(`https://api.telegram.org/bot${cfg.bot_token.trim()}/getChat?chat_id=${encodeURIComponent(cfg.chat_id.trim())}`);
      if (!ch.ok) throw new Error(`Telegram chat: ${await readError(ch)} (is the bot an admin of that chat/channel?)`);
      const cj = await ch.json();
      detail += `, chat "${cj?.result?.title ?? cj?.result?.username ?? cfg.chat_id}" reachable`;
    } else detail += ' (no chat_id saved yet)';
    return detail;
  }
  if (provider === 'facebook') {
    const cfg = need(c, ['page_id', 'access_token'], 'Facebook');
    const page = encodeURIComponent(cfg.page_id.trim());
    const tok = encodeURIComponent(await resolveFacebookPageToken(cfg.page_id, cfg.access_token));
    const res = await fetch(`https://graph.facebook.com/v21.0/${page}?fields=name&access_token=${tok}`);
    if (!res.ok) throw new Error(explainFacebookError(res.status, await readError(res)));
    const j = await res.json();
    // Reading the Page name works with almost any token, so this alone used to say "OK" and then posting failed with #200.
    // A Page token identifies itself as the Page: if /me is someone else, this is a User token and posting will fail.
    const me = await fetch(`https://graph.facebook.com/v21.0/me?fields=id,name&access_token=${tok}`);
    if (me.ok) {
      const mj = await me.json().catch(() => ({}));
      if (mj?.id && String(mj.id) !== String(j?.id ?? cfg.page_id.trim())) {
        throw new Error(`Facebook: User token ito (${mj?.name ?? mj.id}), hindi Page token. Hindi ito makakapag-post sa Page "${j?.name ?? cfg.page_id}" (#200). ` +
          `Sa Graph API Explorer, piliin ang Page sa "User or Page" at i-Generate ulit, o kunin ang token ng Page mula sa GET /me/accounts.`);
      }
    }
    // Reading the Page's feed needs pages_read_engagement, one of the permissions named in the #200 error.
    const feed = await fetch(`https://graph.facebook.com/v21.0/${page}/feed?limit=1&access_token=${tok}`);
    if (!feed.ok) throw new Error(`Nababasa ang Page pero kulang ang permissions ng token. ${explainFacebookError(feed.status, await readError(feed))}${await diagnoseFacebookToken(cfg.page_id, cfg.access_token)}`);
    return `Page "${j?.name ?? cfg.page_id}" OK`;
  }
  if (provider === 'twitter') {
    const cfg = need(c, ['api_key', 'api_secret', 'access_token', 'access_secret'], 'X (Twitter)');
    const url = 'https://api.twitter.com/2/users/me';
    const res = await fetch(url, { headers: { Authorization: await oauth1Header('GET', url, cfg) } });
    if (!res.ok) throw new Error(`X ${res.status}: ${await readError(res)}`);
    const j = await res.json();
    return `Account @${j?.data?.username ?? '?'} OK`;
  }
  if (provider === 'openai') {
    const cfg = need(c, ['api_key'], 'AI key');
    return await checkAiKey(cfg.api_key);
  }
  throw new Error(`Unknown provider "${provider}"`);
}

/* ---- publishing a queued post ---- */
export interface PostRow {
  id: string; game_title: string; platforms: string[]; content: string; hashtags: string; variant?: string | null;
}

export interface PublishOutcome {
  id: string;
  status: 'published' | 'failed';
  sent: { platform: string; id?: string; url?: string }[];
  errors: string[];
}

/**
 * Publishes one post for real and records the outcome. The caller must already have claimed the row
 * (status 'publishing'), so a post can never be sent twice by two runs at once.
 */
export async function publishClaimed(
  sb: SupabaseClient, post: PostRow, creds: Creds, estAudience = 0,
  log: (level: 'info' | 'success' | 'warning' | 'error', source: string, message: string) => Promise<void>,
): Promise<PublishOutcome> {
  const text = `${post.content}\n\n${post.hashtags ?? ''}`.trim();
  const sent: PublishOutcome['sent'] = [];
  const errors: string[] = [];
  for (const platform of post.platforms ?? []) {
    try {
      const r = await sendTo(platform, creds, text);
      sent.push({ platform, ...r });
    } catch (e) {
      errors.push(`${platform}: ${(e as Error).message}`);
    }
  }
  const label = `"${post.game_title}"${post.variant ? ` Variant ${String(post.variant).toUpperCase()}` : ''}`;
  if (sent.length) {
    await sb.from('scheduled_posts').update({
      status: 'published', published_at: new Date().toISOString(), impressions: estAudience,
      error: errors.join('; ') || null, results: sent,
    }).eq('id', post.id);
    await log('success', 'auto-poster', `LIVE: published ${label} to ${sent.map((s) => s.platform).join(', ')}${sent[0].url ? ` — ${sent[0].url}` : ''}`);
    if (errors.length) await log('warning', 'auto-poster', `Some platforms failed for ${label}: ${errors.join('; ')}`);
    return { id: post.id, status: 'published', sent, errors };
  }
  await sb.from('scheduled_posts').update({ status: 'failed', error: errors.join('; ') || 'No platform selected for this post' }).eq('id', post.id);
  await log('error', 'auto-poster', `Failed to publish ${label}: ${errors.join('; ') || 'no platform selected'}`);
  return { id: post.id, status: 'failed', sent, errors };
}

/** Atomically takes a post (queued, or failed when retrying). Returns null if someone else already has it. */
export async function claimPost(sb: SupabaseClient, id: string, retry = false): Promise<PostRow | null> {
  const { data } = await sb.from('scheduled_posts')
    .update({ status: 'publishing', claimed_at: new Date().toISOString(), error: null })
    .eq('id', id).in('status', retry ? ['queued', 'failed'] : ['queued'])
    .select('id, game_title, platforms, content, hashtags, variant').maybeSingle();
  return (data as PostRow | null) ?? null;
}

export function makeLogger(sb: SupabaseClient) {
  return async (level: 'info' | 'success' | 'warning' | 'error', source: string, message: string) => {
    const { error } = await sb.from('bot_logs').insert({ level, source, message });
    if (error) console.error('log failed', error.message);
  };
}
