// One AI helper for every bot. Works with OpenRouter (sk-or-…), OpenAI (sk-…) or Gemini.
// The key comes from API Settings (integration_secrets → provider "openai", stored server-side only);
// the OPENROUTER_API_KEY / OPENAI_API_KEY / GEMINI_API_KEY function secrets are used as a fallback.
import type { SupabaseClient } from '@supabase/supabase-js';

const env = (k: string) => process.env[k] ?? '';

export type AiKind = 'openrouter' | 'openai' | 'gemini';
export interface AiConfig { kind: AiKind; key: string; model: string }

export const kindOf = (key: string): AiKind => (key.startsWith('sk-or-') ? 'openrouter' : key.startsWith('AIza') ? 'gemini' : 'openai');

export async function loadAiConfig(sb: SupabaseClient): Promise<AiConfig | null> {
  const { data } = await sb.from('integration_secrets').select('secrets').eq('provider', 'openai').maybeSingle();
  const s = (data?.secrets ?? {}) as Record<string, string>;
  const key = (s.api_key ?? '').trim() || env('OPENROUTER_API_KEY') || env('GEMINI_API_KEY') || env('OPENAI_API_KEY');
  if (!key) return null;
  const kind = kindOf(key);
  return { kind, key, model: pickModel(kind, s.model ?? '') };
}

const DEFAULT_MODEL: Record<AiKind, string> = { openrouter: 'openai/gpt-4o-mini', openai: 'gpt-4o-mini', gemini: 'gemini-2.0-flash' };

/** The saved model, adjusted to the provider of the key — so swapping e.g. an OpenAI key for a Gemini key never
 *  sends a model name the new provider does not know. */
export function pickModel(kind: AiKind, saved: string): string {
  let model = saved.trim();
  if (!model) return DEFAULT_MODEL[kind];
  if (kind === 'openrouter') {
    if (model.includes('/')) return model;
    return model.startsWith('gemini') ? `google/${model}` : `openai/${model}`;
  }
  if (kind === 'gemini') {
    if (model.startsWith('google/')) model = model.slice(7);
    return model.startsWith('gemini') ? model : DEFAULT_MODEL.gemini;
  }
  if (model.startsWith('openai/')) model = model.slice(7);
  return model.includes('/') || model.startsWith('gemini') ? DEFAULT_MODEL.openai : model;
}

export const PROVIDER_NAME: Record<AiKind, 'OpenAI' | 'OpenRouter' | 'Gemini'> = { openai: 'OpenAI', openrouter: 'OpenRouter', gemini: 'Gemini' };

export interface AiKeyStatus {
  configured: boolean;
  provider?: 'OpenAI' | 'OpenRouter' | 'Gemini';
  model?: string;
  keyHint?: string;
  /** true = the provider accepted the key, false = rejected, null = could not tell */
  keyValid: boolean | null;
  /** 'ok' = a real AI request went through, 'empty' = no credits / quota left, 'unknown' = could not tell */
  credits: 'ok' | 'empty' | 'unknown';
  /** OpenRouter only: dollars left on the key or account, when the provider reports it */
  creditLeft?: number | null;
  message: string;
  checkedAt: string;
}

export const keyHint = (key: string): string => {
  const k = key.trim();
  return k.length <= 10 ? '••••' : `${k.slice(0, k.startsWith('sk-or-') ? 6 : 3)}…${k.slice(-4)}`;
};

/** Turns an AI provider error ("OpenAI 429: …") into a key / credits verdict. */
export function classifyAiError(message: string): Pick<AiKeyStatus, 'keyValid' | 'credits' | 'message'> {
  const code = Number(/^(?:OpenAI|OpenRouter|Gemini) (\d{3})\b/.exec(message)?.[1] ?? 0);
  const detail = message.replace(/^(?:OpenAI|OpenRouter|Gemini) \d{3}: /, '');
  const noCredit = /credit|quota|billing|insufficient|exceeded your current|payment/i.test(detail);
  if (code === 401 || (code === 403 && !noCredit) || (code === 400 && /api key not valid|invalid api key|incorrect api key/i.test(detail))) {
    return { keyValid: false, credits: 'unknown', message: `The provider rejected this key: ${detail}` };
  }
  if (code === 402 || ((code === 429 || code === 403) && noCredit)) {
    return { keyValid: true, credits: 'empty', message: `The key works but has no credits left: ${detail}` };
  }
  if (code === 429) return { keyValid: true, credits: 'unknown', message: `The provider is rate-limiting this key right now, try again in a minute: ${detail}` };
  if (code === 400 || code === 404) return { keyValid: true, credits: 'unknown', message: `The key works, but the model setting was not accepted: ${detail}` };
  return { keyValid: null, credits: 'unknown', message: `Could not check the key: ${detail}` };
}

/** Full check for the API Settings status panel: is the key accepted, and does a tiny real AI request go through? */
export async function aiKeyStatus(cfg: AiConfig | null): Promise<AiKeyStatus> {
  const checkedAt = new Date().toISOString();
  if (!cfg) return { configured: false, keyValid: null, credits: 'unknown', message: 'No AI key saved yet.', checkedAt };
  const base = { configured: true, provider: PROVIDER_NAME[cfg.kind], model: cfg.model, keyHint: keyHint(cfg.key), checkedAt };

  let creditLeft: number | null | undefined;
  if (cfg.kind === 'openrouter') {
    try {
      const res = await fetch('https://openrouter.ai/api/v1/auth/key', { headers: { Authorization: `Bearer ${cfg.key}` }, signal: AbortSignal.timeout(15_000) });
      if (res.status === 401 || res.status === 403) {
        return { ...base, keyValid: false, credits: 'unknown', message: `The provider rejected this key: ${await errText(res)}` };
      }
      if (res.ok) {
        const j = await res.json().catch(() => ({}));
        const lim = j?.data?.limit_remaining;
        if (typeof lim === 'number') creditLeft = lim;
      }
      const cr = await fetch('https://openrouter.ai/api/v1/credits', { headers: { Authorization: `Bearer ${cfg.key}` }, signal: AbortSignal.timeout(15_000) });
      if (cr.ok) {
        const cj = await cr.json().catch(() => ({}));
        const total = Number(cj?.data?.total_credits), used = Number(cj?.data?.total_usage);
        if (Number.isFinite(total) && Number.isFinite(used)) {
          const left = Math.max(0, total - used);
          creditLeft = typeof creditLeft === 'number' ? Math.min(creditLeft, left) : left;
        }
      }
    } catch { /* fall through to the real request below */ }
  }

  try {
    await aiText(cfg, 'Reply with the single word: ok', 5);
  } catch (e) {
    const m = (e as Error).message;
    if (m !== 'AI returned no text') return { ...base, ...classifyAiError(m), creditLeft };
  }
  return { ...base, keyValid: true, credits: 'ok', creditLeft, message: 'Key accepted and a test AI request went through.' };
}

/** HTTP status for an error thrown by the AI helpers: problems with the owner's AI key (no credits, rate limit,
 *  invalid or blocked key) are 402 so the office shows them as a key issue instead of a server crash. */
export const aiErrorStatus = (message: string): number =>
  /^(OpenAI|OpenRouter|Gemini) (401|402|403|429)\b/.test(message) ? 402 : 500;

async function errText(res: Response): Promise<string> {
  const t = await res.text().catch(() => '');
  try { const j = JSON.parse(t); return j?.error?.message ?? j?.message ?? t.slice(0, 200); } catch { return t.slice(0, 200); }
}

/** Plain text completion. */
export async function aiText(cfg: AiConfig, prompt: string, maxTokens = 600): Promise<string> {
  if (cfg.kind === 'gemini') {
    const res = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${cfg.model}:generateContent?key=${cfg.key}`, {
      method: 'POST', headers: { 'Content-Type': 'application/json' }, signal: AbortSignal.timeout(45_000),
      body: JSON.stringify({ contents: [{ parts: [{ text: prompt }] }], generationConfig: { temperature: 0.9, maxOutputTokens: maxTokens } }),
    });
    if (!res.ok) throw new Error(`Gemini ${res.status}: ${await errText(res)}`);
    const d = await res.json();
    return String(d?.candidates?.[0]?.content?.parts?.[0]?.text ?? '');
  }
  const url = cfg.kind === 'openrouter' ? 'https://openrouter.ai/api/v1/chat/completions' : 'https://api.openai.com/v1/chat/completions';
  const headers: Record<string, string> = { 'Content-Type': 'application/json', Authorization: `Bearer ${cfg.key}` };
  if (cfg.kind === 'openrouter') { headers['HTTP-Referer'] = env('SUPABASE_URL') || 'https://bot-office.app'; headers['X-Title'] = 'Code Ai Office'; }
  const res = await fetch(url, {
    method: 'POST', headers, signal: AbortSignal.timeout(45_000),
    body: JSON.stringify({ model: cfg.model, messages: [{ role: 'user', content: prompt }], temperature: 0.9, max_tokens: maxTokens }),
  });
  if (!res.ok) throw new Error(`${cfg.kind === 'openrouter' ? 'OpenRouter' : 'OpenAI'} ${res.status}: ${await errText(res)}`);
  const d = await res.json();
  const text = d?.choices?.[0]?.message?.content;
  if (!text) throw new Error('AI returned no text');
  return String(text);
}

/** Completion that must be JSON — tolerant of ```fences``` and chatter around the object. */
export async function aiJson<T = Record<string, unknown>>(cfg: AiConfig, prompt: string, maxTokens = 600): Promise<T> {
  const raw = await aiText(cfg, `${prompt}\n\nReturn ONLY the JSON object. No markdown, no explanation.`, maxTokens);
  const cleaned = raw.replace(/```json|```/gi, '').trim();
  const a = cleaned.indexOf('{');
  const b = cleaned.lastIndexOf('}');
  if (a < 0 || b <= a) throw new Error('AI did not return JSON');
  return JSON.parse(cleaned.slice(a, b + 1)) as T;
}

/** Cheap check used by "Test connection". */
export async function checkAiKey(key: string): Promise<string> {
  const kind = kindOf(key.trim());
  if (kind === 'openrouter') {
    const res = await fetch('https://openrouter.ai/api/v1/auth/key', { headers: { Authorization: `Bearer ${key.trim()}` }, signal: AbortSignal.timeout(20_000) });
    if (!res.ok) throw new Error(`OpenRouter ${res.status}: ${await errText(res)}`);
    const j = await res.json().catch(() => ({}));
    const lim = j?.data?.limit_remaining;
    return `OpenRouter key OK${typeof lim === 'number' ? ` — credit left: $${lim.toFixed(2)}` : ''}`;
  }
  if (kind === 'gemini') {
    const res = await fetch(`https://generativelanguage.googleapis.com/v1beta/models?key=${key.trim()}`, { signal: AbortSignal.timeout(20_000) });
    if (!res.ok) throw new Error(`Gemini ${res.status}: ${await errText(res)}`);
    return 'Gemini key OK';
  }
  const res = await fetch('https://api.openai.com/v1/models', { headers: { Authorization: `Bearer ${key.trim()}` }, signal: AbortSignal.timeout(20_000) });
  if (!res.ok) throw new Error(`OpenAI ${res.status}: ${await errText(res)}`);
  return 'OpenAI key OK';
}

/** Text embedding (1536 dims) for the Shared Brain semantic search. Returns null when the provider cannot do it — callers must cope. */
export async function aiEmbed(cfg: AiConfig, text: string): Promise<number[] | null> {
  if (cfg.kind === 'gemini') return null;
  try {
    const url = cfg.kind === 'openrouter' ? 'https://openrouter.ai/api/v1/embeddings' : 'https://api.openai.com/v1/embeddings';
    const model = cfg.kind === 'openrouter' ? 'openai/text-embedding-3-small' : 'text-embedding-3-small';
    const res = await fetch(url, {
      method: 'POST', signal: AbortSignal.timeout(20_000),
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${cfg.key}` },
      body: JSON.stringify({ model, input: text.slice(0, 6000) }),
    });
    if (!res.ok) return null;
    const v = (await res.json())?.data?.[0]?.embedding;
    return Array.isArray(v) && v.length === 1536 ? (v as number[]) : null;
  } catch { return null; }
}
