// Pure helpers for X (Twitter) text limits — no imports, so they can be used (and tested) anywhere.
// X counts every link as 23 characters, and emoji / CJK characters as 2.

export const TWEET_LIMIT = 280;
const URL_G = /https?:\/\/\S+/g;
const URL_WEIGHT = 23;

/** Weight of one character the way X counts it. */
function charWeight(cp: number): number {
  return (cp <= 4351) || (cp >= 8192 && cp <= 8205) || (cp >= 8208 && cp <= 8223) || (cp >= 8242 && cp <= 8247) ? 1 : 2;
}

const weightOf = (s: string) => { let n = 0; for (const ch of s) n += charWeight(ch.codePointAt(0)!); return n; };

/** Length of a post as X will count it. */
export function tweetLength(text: string): number {
  let n = 0, last = 0;
  for (const m of text.matchAll(URL_G)) {
    n += weightOf(text.slice(last, m.index));
    n += URL_WEIGHT;
    last = (m.index ?? 0) + m[0].length;
  }
  return n + weightOf(text.slice(last));
}

/** Cuts `text` to at most `room` weight, never inside a link, at a word boundary, and adds "…". */
function cutTo(text: string, room: number): string {
  if (tweetLength(text) <= room) return text;
  const parts = text.split(/(https?:\/\/\S+)/g); // odd indexes are links
  let used = 0, out = '';
  const budget = room - 1; // keep one for "…"
  for (let i = 0; i < parts.length; i++) {
    const p = parts[i];
    if (i % 2 === 1) { if (used + URL_WEIGHT > budget) break; out += p; used += URL_WEIGHT; continue; }
    let piece = '';
    let stop = false;
    for (const ch of p) {
      const w = charWeight(ch.codePointAt(0)!);
      if (used + w > budget) { stop = true; break; }
      piece += ch; used += w;
    }
    out += piece;
    if (stop) break;
  }
  out = out.trimEnd();
  const lastSpace = out.search(/\s\S*$/);
  if (lastSpace > out.length - 20 && lastSpace > 0) out = out.slice(0, lastSpace).trimEnd(); // do not leave half a word
  return `${out}…`;
}

const TAIL_LINE = /^(https?:\/\/\S+|(#\S+\s*)+)$/;

/**
 * Makes a post fit 280. The text of the post is shortened first; the tracking link and the hashtags at the end are kept
 * (hashtags are dropped from the back only when even that is not enough). Text that already fits is returned unchanged.
 */
export function fitTweet(text: string, limit = TWEET_LIMIT): string {
  const t = text.trim();
  if (tweetLength(t) <= limit) return t;
  const lines = t.split('\n');
  const tail: string[] = [];
  while (lines.length > 1) {
    const l = lines[lines.length - 1].trim();
    if (l === '' || TAIL_LINE.test(l)) tail.unshift(lines.pop()!.trim()); else break;
  }
  let tailText = tail.filter(Boolean).join('\n');
  // not enough room for a real sentence? drop hashtags from the end
  while (tailText && limit - tweetLength(tailText) - 2 < 60) {
    const m = tailText.match(/\s+#\S+\s*$/);
    if (!m) break;
    tailText = tailText.slice(0, m.index).trimEnd();
  }
  const head = lines.join('\n').trim();
  const room = limit - (tailText ? tweetLength(tailText) + 2 : 0);
  const out = tailText ? `${cutTo(head, room)}\n\n${tailText}` : cutTo(head, limit);
  return tweetLength(out) <= limit ? out : cutTo(out, limit);
}
