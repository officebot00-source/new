// Job + settings storage for the Video Editor Bot. Uses the existing server-only `bot_state` table (key/value),
// so no new migration is needed. One row per job (`video_job:<id>`) keeps concurrent runs from overwriting each other.
import type { SupabaseClient } from '@supabase/supabase-js';
import { DEFAULT_VIDEO_SETTINGS, MAX_AUTO_PER_DAY, VIDEO_JOB_PREFIX, VIDEO_SETTINGS_KEY, VIDEO_ASPECTS, VIDEO_PLATFORMS, type VideoJob, type VideoSettings } from '@/lib/app/video';
import type { JobStore, Stored } from './video-pipeline.ts';

const key = (id: string) => `${VIDEO_JOB_PREFIX}${id}`;

export function supabaseJobStore(sb: SupabaseClient): JobStore {
  return {
    async insert(job) {
      const { error } = await sb.from('bot_state').insert({ key: key(job.id), value: job as never, updated_at: job.updated_at });
      if (error) throw new Error(`Could not save the video job: ${error.message}`);
    },
    async get(id) {
      const { data, error } = await sb.from('bot_state').select('value, updated_at').eq('key', key(id)).maybeSingle();
      if (error) throw new Error(error.message);
      return data ? { job: data.value as VideoJob, rev: data.updated_at as string } : null;
    },
    async list(limit) {
      const { data, error } = await sb.from('bot_state').select('value, updated_at').like('key', `${VIDEO_JOB_PREFIX}%`).order('updated_at', { ascending: false }).limit(limit);
      if (error) throw new Error(error.message);
      return (data ?? []).map((r): Stored => ({ job: r.value as VideoJob, rev: r.updated_at as string }));
    },
    async cas(id, rev, job) {
      let ts = job.updated_at;
      if (ts === rev) ts = new Date(Date.parse(rev) + 1).toISOString();
      const { data, error } = await sb.from('bot_state').update({ value: { ...job, updated_at: ts } as never, updated_at: ts }).eq('key', key(id)).eq('updated_at', rev).select('updated_at').maybeSingle();
      if (error || !data) return null;
      return data.updated_at as string;
    },
  };
}

export async function loadVideoSettings(sb: SupabaseClient): Promise<VideoSettings> {
  const { data } = await sb.from('bot_state').select('value').eq('key', VIDEO_SETTINGS_KEY).maybeSingle();
  return sanitizeSettings(data?.value);
}

export function sanitizeSettings(raw: unknown, base: VideoSettings = DEFAULT_VIDEO_SETTINGS): VideoSettings {
  const r = (raw && typeof raw === 'object' ? raw : {}) as Record<string, unknown>;
  const editors = ['auto', 'ffmpeg', 'cloud', 'mock'];
  return {
    realtime_enabled: typeof r['realtime_enabled'] === 'boolean' ? r['realtime_enabled'] : base.realtime_enabled,
    dry_run: typeof r['dry_run'] === 'boolean' ? r['dry_run'] : base.dry_run,
    editor: typeof r['editor'] === 'string' && editors.includes(r['editor']) ? (r['editor'] as VideoSettings['editor']) : base.editor,
    default_platforms: Array.isArray(r['default_platforms'])
      ? (r['default_platforms'] as unknown[]).filter((p): p is string => typeof p === 'string' && (VIDEO_PLATFORMS as readonly string[]).includes(p))
      : base.default_platforms,
    auto_generate: typeof r['auto_generate'] === 'boolean' ? r['auto_generate'] : (base.auto_generate ?? false),
    auto_per_day: Number.isFinite(Number(r['auto_per_day'])) && r['auto_per_day'] !== undefined && r['auto_per_day'] !== '' && r['auto_per_day'] !== null
      ? Math.min(MAX_AUTO_PER_DAY, Math.max(1, Math.trunc(Number(r['auto_per_day']))))
      : (base.auto_per_day ?? 1),
  };
}

export async function saveVideoSettings(sb: SupabaseClient, patch: unknown): Promise<VideoSettings> {
  const next = sanitizeSettings(patch, await loadVideoSettings(sb));
  const { error } = await sb.from('bot_state').upsert({ key: VIDEO_SETTINGS_KEY, value: next as never, updated_at: new Date().toISOString() });
  if (error) throw new Error(error.message);
  return next;
}

/** What the browser may see: never the server's temp file path. */
export const publicJob = (j: VideoJob): Omit<VideoJob, 'output_path'> & { has_output: boolean } => {
  const { output_path, ...rest } = j;
  return { ...rest, has_output: Boolean(output_path || j.output_url) };
};

export const ASPECT_VALUES = VIDEO_ASPECTS.map((a) => a.value);
