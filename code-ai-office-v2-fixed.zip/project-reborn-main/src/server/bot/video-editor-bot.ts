// Video Editor Bot + Real-Time Auto-Poster. The video employee is REEL (makes game clips, edits and ENHANCES videos); BLAZE only posts them.
// Edits a video (ffmpeg / cloud / dry-run), then posts it for real.
// Callers: the app (APP_PASSCODE), the scheduler (service bearer, every minute) or any webhook that knows the password.
// Body: { action: 'enqueue' | 'list' | 'get' | 'retry' | 'pause' | 'resume' | 'post_now' | 'run' | 'tick' | 'settings_get' | 'settings_set' | 'status', ... }
//   enqueue: { input: <public video URL>, edit?: {start_sec,end_sec,aspect,overlay_text,normalize_audio,volume,enhance}, post: {title,caption,tags,platforms}, realtime?, dry_run?, run_now? }
//   enqueue with task:'enhance': the boss's own video link is assigned to Reel to enhance (edit.enhance = auto|sharper|vivid|low_light|clean_audio). It waits for the boss to watch it; platforms are optional (none = download only).
// A scheduled call with an empty body = "tick": recover stuck jobs, edit queued ones, post edited ones.
import type { SupabaseClient } from '@supabase/supabase-js';
import { supabaseAdmin } from '@/integrations/supabase/client.server';
import { VIDEO_PLATFORMS, type VideoJob, type VideoJobSource } from '@/lib/app/video';
import { pickGame, type GameLite } from '@/lib/app/gameVideo';
import { aiJson, loadAiConfig } from './_shared/ai.ts';
import { loadBrain } from './_shared/brain.ts';
import { FIELDS, authorized, corsHeaders, isServiceCall, json, loadCreds, makeLogger, type Creds } from './_shared/publish.ts';
import { notifyTeam } from './_shared/notify.ts';
import { editTimeoutMs, editorProblem, ffmpegAdapter, gameRenderProblem, cloudAdapter, mediaDir, pickAdapter, removeTempFile, renderGameClip } from './_shared/video-editor.ts';
import { approveJob, enqueueGameJob, enqueueJob, pauseJob, rejectJob, resumeJob, retryJob, runJob, tick, type PipelineDeps } from './_shared/video-pipeline.ts';
import { postVideo } from './_shared/video-publish.ts';
import { loadVideoSettings, publicJob, saveVideoSettings, supabaseJobStore } from './_shared/video-store.ts';

const sb = supabaseAdmin as unknown as SupabaseClient;

/** Platforms that have every credential saved in API Settings. */
export const connectedPlatforms = (creds: Creds): string[] => VIDEO_PLATFORMS.filter((p) => (FIELDS[p] ?? []).every((f) => creds[p]?.[f]?.trim()));

/** Picks a game (or uses the one asked for) and queues a video for it. The video will wait for the boss's approval. */
export async function generateGameVideo(deps: PipelineDeps, client: SupabaseClient, o: { gameId?: string; variant?: number; platforms?: string[]; source: VideoJobSource }) {
  // No job is made when nothing can render it: the boss gets the reason now, not a failed job later.
  const pre = await deps.settings();
  if (!pre.dry_run) {
    const bad = await gameRenderProblem();
    if (bad) return { ok: false as const, error: bad };
  }
  // Banners can be big data URLs, so the list is read WITHOUT them; the one chosen game's banner is read when the clip is rendered.
  const { data, error } = await client.from('games').select('id, title, genre, description, promo_link, active').order('created_at', { ascending: false }).limit(100);
  if (error) return { ok: false as const, error: `Could not read the games: ${error.message}` };
  const games = (data ?? []) as GameLite[];
  const jobs = (await deps.store.list(100)).map((s) => s.job);
  let game: GameLite | undefined;
  let variant = o.variant;
  if (o.gameId) {
    game = games.find((g) => g.id === o.gameId);
    if (!game) return { ok: false as const, error: 'Game not found.' };
    variant ??= jobs.filter((j) => j.game_id === game!.id).length;
  } else {
    const pick = pickGame(games, jobs);
    if (!pick) return { ok: false as const, error: 'Walang active na game. Magdagdag o i-activate muna ang isang game.' };
    game = pick.game; variant ??= pick.variant;
  }
  const settings = await deps.settings();
  const platforms = o.platforms?.length ? o.platforms : settings.default_platforms.length ? settings.default_platforms : connectedPlatforms(await loadCreds(client));
  return enqueueGameJob(deps, game, { variant, platforms, source: o.source });
}

export function makeDeps(client: SupabaseClient = sb): PipelineDeps {
  const log = makeLogger(client);
  const deps: PipelineDeps = {
    store: supabaseJobStore(client),
    settings: () => loadVideoSettings(client),
    async edit(job, settings) {
      if (job.game_id) {
        if (job.dry_run || settings.dry_run) return { adapter: 'mock', warnings: ['Dry run: no video was rendered.'], edited: false };
        const { data: game } = await client.from('games').select('id, title, genre, description, promo_link, banner_image').eq('id', job.game_id).maybeSingle();
        if (!game) throw new Error('Game not found — it may have been deleted.');
        return renderGameClip({ jobId: job.id, game: game as GameLite, spec: job.spec, variant: job.variant ?? 0, timeoutMs: editTimeoutMs() });
      }
      const adapter = await pickAdapter(settings.editor, job.dry_run || settings.dry_run);
      return adapter.edit({ jobId: job.id, input: job.input, spec: job.spec, timeoutMs: editTimeoutMs() });
    },
    async post(job, platforms) { return postVideo(job, platforms, await loadCreds(client)); },
    async fileExists(path) { try { await (await import('node:fs/promises')).access(path); return true; } catch { return false; } },
    cleanup: removeTempFile,
    async generateCaption(job: VideoJob) {
      const ai = await loadAiConfig(client);
      if (!ai) return null;
      const brain = await loadBrain(client, ai, { platforms: (job.post.platforms ?? []) as string[], role: 'reel', limit: 4, trackUsage: false }); // captions are not tied to a scored post
      const out = await aiJson<{ caption?: unknown }>(ai, `Write ONE short social media caption (under 280 characters, no URLs, no hashtags) for a game studio video.${brain.block}\nTitle: ${job.post.title || 'n/a'}\nGame: ${job.post.game_title || 'n/a'}\nReturn ONLY JSON: {"caption":"..."}`, 300);
      return typeof out.caption === 'string' ? out.caption.trim().slice(0, 600) : null;
    },
    async onReadyForReview(job) {
      const text = `🎬 Si Reel: may bagong video na hinihintay ang approval mo: "${job.post.title || 'video'}"${job.post.game_title ? ` (${job.post.game_title})` : ''}.\nBuksan ang app → Content Studio → Video, panoorin, at i-approve o i-reject. Walang ipo-post hangga't hindi mo ina-approve.`;
      await notifyTeam(await loadCreds(client), text);
    },
    log, mediaDir: mediaDir(), editTimeoutMs: editTimeoutMs(), postTimeoutMs: 60_000,
    now: () => new Date(), newId: () => crypto.randomUUID(),
  };
  deps.autoGenerate = async () => {
    const made = await generateGameVideo(deps, client, { source: 'worker' });
    if (!made.ok) { await log('warning', 'video-editor', `Auto game video skipped: ${made.error}`); return; }
    await runJob(deps, made.job.id); // edits it; it then stops at "waiting for approval"
  };
  return deps;
}

const isId = (v: unknown): v is string => typeof v === 'string' && /^[0-9a-f-]{36}$/i.test(v);

export default async function handler(req: Request): Promise<Response> {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders });
  if (req.method !== 'POST') return json({ error: 'POST only' }, 405);
  const service = isServiceCall(req);
  if (!service && !authorized(req)) return json({ error: 'Wrong or missing passcode' }, 401);

  let body: Record<string, unknown> = {};
  try { const t = await req.text(); body = t.trim() ? (JSON.parse(t) as Record<string, unknown>) : {}; } catch { return json({ error: 'Invalid JSON' }, 400); }
  // "generate game", "generate-game" and "generate_game" are the same action
  const action = typeof body['action'] === 'string' ? body['action'].trim().replace(/[\s-]+/g, '_') : service ? 'tick' : 'list';
  const deps = makeDeps();

  try {
    switch (action) {
      case 'tick':
      case 'run': {
        const summary = await tick(deps);
        return json({ ok: true, ...summary });
      }
      case 'status': {
        const [ff, cloud, settings, creds] = await Promise.all([ffmpegAdapter.available(), cloudAdapter.available(), deps.settings(), loadCreds(sb)]);
        return json({ ok: true, settings, editors: { ffmpeg: ff, cloud, mock: { ok: true } }, media_folder_enabled: Boolean(mediaDir()), connected_platforms: connectedPlatforms(creds) });
      }
      case 'generate_game': {
        const gameId = typeof body['game_id'] === 'string' && isId(body['game_id']) ? body['game_id'] : undefined;
        const platforms = Array.isArray(body['platforms']) ? (body['platforms'] as unknown[]).filter((p): p is string => typeof p === 'string') : undefined;
        const variant = Number.isFinite(Number(body['variant'])) && body['variant'] !== undefined && body['variant'] !== '' ? Number(body['variant']) : undefined;
        const made = await generateGameVideo(deps, sb, { ...(gameId ? { gameId } : {}), ...(variant !== undefined ? { variant } : {}), ...(platforms ? { platforms } : {}), source: service ? 'webhook' : body['source'] === 'boss' ? 'boss' : 'ui' });
        if (!made.ok) return json({ error: made.error }, 400);
        void runJob(deps, made.job.id).catch((e) => deps.log('error', 'video-editor', `Game video failed: ${(e as Error).message}`));
        return json({ ok: true, job: publicJob(made.job) }, 202);
      }
      case 'approve': {
        if (!isId(body['id'])) return json({ error: 'id required' }, 400);
        const r = await approveJob(deps, body['id']);
        if (!r.ok) return json({ error: r.error }, 409);
        void runJob(deps, body['id'], { forcePost: true }).catch((e) => deps.log('error', 'auto-poster', `Post after approval failed: ${(e as Error).message}`));
        return json({ ok: true }, 202);
      }
      case 'reject': {
        if (!isId(body['id'])) return json({ error: 'id required' }, 400);
        const r = await rejectJob(deps, body['id'], typeof body['reason'] === 'string' ? body['reason'] : '');
        return r.ok ? json({ ok: true }) : json({ error: r.error }, 409);
      }
      case 'preview': {
        // The boss watches the video before approving. Needs the password header, so the app fetches it and plays it from memory.
        if (!isId(body['id'])) return json({ error: 'id required' }, 400);
        const cur = await deps.store.get(body['id']);
        if (!cur) return json({ error: 'Job not found' }, 404);
        let path = cur.job.output_path;
        const fs = await import('node:fs/promises');
        const exists = async (f?: string) => { if (!f) return false; try { await fs.access(f); return true; } catch { return false; } };
        if (!(await exists(path)) && (cur.job.game_id || cur.job.task === 'enhance') && (cur.job.status === 'awaiting_approval' || cur.job.status === 'done') && !cur.job.dry_run) {
          // The temporary file is gone (server restarted): make the same clip again so it can still be watched or downloaded.
          const out = await deps.edit(cur.job, await deps.settings());
          path = out.outputPath;
          if (path) await deps.store.cas(cur.job.id, cur.rev, { ...cur.job, output_path: path, updated_at: new Date().toISOString() });
        }
        if (await exists(path)) {
          const buf = await fs.readFile(path!);
          if (buf.byteLength > 60 * 1024 * 1024) return json({ error: 'Video is too big to preview here.' }, 413);
          return new Response(new Uint8Array(buf), { status: 200, headers: { ...corsHeaders, 'Content-Type': 'video/mp4', 'Content-Length': String(buf.byteLength), 'Cache-Control': 'no-store' } });
        }
        if (cur.job.output_url) return json({ ok: true, url: cur.job.output_url });
        return json({ error: cur.job.dry_run ? 'Dry run — walang totoong video na mapapanood.' : 'Wala na ang video file sa server.' }, 404);
      }
      case 'settings_get': return json({ ok: true, settings: await deps.settings() });
      case 'settings_set': {
        const settings = await saveVideoSettings(sb, body['settings']);
        await deps.log('info', 'auto-poster', `Real-time video posting is now ${settings.realtime_enabled ? 'ON' : 'OFF'}${settings.dry_run ? ' (dry run)' : ''}.`);
        return json({ ok: true, settings });
      }
      case 'list': {
        const rows = await deps.store.list(Math.min(100, Math.max(1, Number(body['limit']) || 50)));
        return json({ ok: true, jobs: rows.map((r) => publicJob(r.job)).sort((a, b) => b.created_at.localeCompare(a.created_at)) });
      }
      case 'get': {
        if (!isId(body['id'])) return json({ error: 'id required' }, 400);
        const r = await deps.store.get(body['id']);
        return r ? json({ ok: true, job: publicJob(r.job) }) : json({ error: 'Job not found' }, 404);
      }
      case 'enqueue': {
        const source: VideoJobSource = service ? 'webhook' : body['source'] === 'boss' ? 'boss' : body['source'] === 'webhook' ? 'webhook' : 'ui';
        // Same rule as game videos: refuse up front when no editor can render this job (unless it is a dry run).
        const cfg = await deps.settings();
        const dry = typeof body['dry_run'] === 'boolean' ? body['dry_run'] : cfg.dry_run;
        const noEditor = dry ? null : await editorProblem(cfg.editor, false);
        if (noEditor) return json({ error: noEditor }, 400);
        const made = await enqueueJob(deps, body, source);
        if (!made.ok) return json({ error: made.error }, 400);
        // Real-time: start right away in the background; the 1-minute tick is the safety net if the runtime stops this early.
        const settings = await deps.settings();
        if (body['run_now'] !== false && ((made.job.realtime && settings.realtime_enabled) || made.job.task === 'enhance')) {
          void runJob(deps, made.job.id).catch((e) => deps.log('error', 'video-editor', `Real-time run failed: ${(e as Error).message}`));
        }
        return json({ ok: true, job: publicJob(made.job) }, 202);
      }
      case 'retry': case 'pause': case 'resume': case 'post_now': {
        if (!isId(body['id'])) return json({ error: 'id required' }, 400);
        if (action === 'post_now') {
          const cur = await deps.store.get(body['id']);
          if (!cur || cur.job.status !== 'edited') return json({ error: 'Only edited jobs can be posted now.' }, 409);
          void runJob(deps, body['id'], { forcePost: true }).catch((e) => deps.log('error', 'auto-poster', `Post now failed: ${(e as Error).message}`));
          return json({ ok: true }, 202);
        }
        const r = action === 'retry' ? await retryJob(deps, body['id']) : action === 'pause' ? await pauseJob(deps, body['id']) : await resumeJob(deps, body['id']);
        if (!r.ok) return json({ error: r.error }, 409);
        if (action !== 'pause') void runJob(deps, body['id']).catch((e) => deps.log('error', 'video-editor', `Run failed: ${(e as Error).message}`));
        return json({ ok: true });
      }
      default: return json({ error: `Unknown action "${action}"` }, 400);
    }
  } catch (e) {
    await deps.log('error', 'video-editor', `Video bot error (${action}): ${(e as Error).message}`).catch(() => undefined);
    return json({ ok: false, error: (e as Error).message }, 500);
  }
}
