// AI Caption & Hashtag writer: the admin types a topic and a target platform, the model writes a caption and hashtags.
// Uses the AI key saved in API Settings (OpenRouter / OpenAI / Gemini) — this works on Netlify and everywhere else.
// If no key is saved (or it fails) it falls back to Lovable's AI gateway when that is available.
// Protected by the app password like every other bot route.
import { GatewayError, PaymentRequiredError, RateLimitError, generateResponse } from '@lovable.dev/ai-gateway';
import { CAPTION_PLATFORMS, TOPIC_MAX, fitToPlatform, isCaptionPlatform, normalizeHashtags } from '@/lib/app/caption';
import type { SupabaseClient } from '@supabase/supabase-js';
import { supabaseAdmin } from '@/integrations/supabase/client.server';
import { aiJson, aiErrorStatus, classifyAiError, loadAiConfig, type AiConfig } from './_shared/ai.ts';
import { loadBrain } from './_shared/brain.ts';
import { authorized, corsHeaders, json } from './_shared/publish.ts';

const MODEL = 'openai/gpt-6-astra';
const TONES = ['hype', 'casual', 'competitive', 'fomo', 'informative'] as const;

function outputText(res: { output?: unknown }): string {
  const parts: string[] = [];
  for (const item of (Array.isArray(res.output) ? res.output : []) as { type?: string; content?: { type?: string; text?: string }[] }[]) {
    if (item.type !== 'message') continue;
    for (const c of item.content ?? []) if (c.type === 'output_text' && typeof c.text === 'string') parts.push(c.text);
  }
  return parts.join('');
}

export default async function handler(req: Request): Promise<Response> {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders });
  if (req.method !== 'POST') return json({ error: 'Method not allowed' }, 405);
  if (!authorized(req)) return json({ error: 'Wrong or missing password' }, 401);

  let body: { topic?: unknown; platform?: unknown; tone?: unknown };
  try { body = await req.json(); } catch { return json({ error: 'Invalid JSON' }, 400); }

  const topic = typeof body.topic === 'string' ? body.topic.trim() : '';
  if (!topic) return json({ error: 'Lagyan ng paksa (topic).' }, 400);
  if (topic.length > TOPIC_MAX) return json({ error: `Masyadong mahaba ang paksa (max ${TOPIC_MAX} characters).` }, 400);
  if (!isCaptionPlatform(body.platform)) return json({ error: 'Pumili ng platform.' }, 400);
  const platform = body.platform;
  const tone = (TONES as readonly string[]).includes(String(body.tone)) ? String(body.tone) : 'hype';
  const rule = CAPTION_PLATFORMS[platform];

  // The AI key saved in API Settings (same one every other bot uses). Lovable's gateway is only the fallback.
  const sb = supabaseAdmin as unknown as SupabaseClient;
  const ai: AiConfig | null = await loadAiConfig(sb).catch(() => null);

  // Shared Brain: guardrails + the newest team lessons for this platform
  const brain = await loadBrain(sb, ai, { platforms: [platform], role: 'aria', context: topic, limit: 4, trackUsage: false });
  const instructions = `You write social media captions for an indie game studio.
Platform: ${rule.label}. Style: ${rule.style}.
Tone: ${tone}.
Caption limit: ${rule.sharedLimit ? `${rule.maxCaption} characters INCLUDING the hashtags` : `${rule.maxCaption} characters (hashtags not counted)`}.
Hashtags: ${rule.minTags === 0 ? `0 to ${rule.maxTags}` : `${rule.minTags} to ${rule.maxTags}`}, relevant to the topic and platform, no spaces inside a hashtag.
Do not put hashtags inside the caption itself. Write in the same language the topic is written in (Tagalog, Taglish or English).${brain.block}`;

  const finish = (parsed: { caption?: unknown; hashtags?: unknown }): Response => {
    const caption = typeof parsed.caption === 'string' ? parsed.caption : '';
    if (!caption.trim()) return json({ error: 'Walang naisulat ang AI. Subukan ulit o baguhin ang paksa.' }, 502);
    const fitted = fitToPlatform(caption, normalizeHashtags(parsed.hashtags, platform), platform);
    return json({ ok: true, platform, ...fitted });
  };

  /** 1) the saved AI key */
  let keyProblem = '';
  if (ai) {
    try {
      const parsed = await aiJson<{ caption?: unknown; hashtags?: unknown }>(
        ai, `${instructions}\n\nTopic: ${topic}\n\nReturn JSON exactly like: {"caption":"...","hashtags":["#one","#two"]}`, 700);
      return finish(parsed);
    } catch (err) {
      const msg = (err as Error).message;
      console.error('caption-writer: saved key failed', msg);
      keyProblem = friendlyKeyError(msg, ai);
      if (aiErrorStatus(msg) === 402 && !lovableAvailable()) return json({ error: keyProblem }, 402);
    }
  }

  /** 2) fallback: Lovable's AI gateway (only when this deployment has it) */
  if (lovableAvailable()) {
    try {
      const res = await generateResponse({
        model: MODEL,
        instructions,
        input: [{ role: 'user', content: `Topic: ${topic}` }],
        text: {
          format: {
            type: 'json_schema',
            name: 'caption',
            strict: true,
            schema: {
              type: 'object',
              additionalProperties: false,
              properties: { caption: { type: 'string' }, hashtags: { type: 'array', items: { type: 'string' } } },
              required: ['caption', 'hashtags'],
            },
          },
        },
      });
      let parsed: { caption?: unknown; hashtags?: unknown };
      try { parsed = JSON.parse(outputText(res as { output?: unknown })); } catch { return json({ error: keyProblem || 'Hindi maintindihan ang sagot ng AI. Subukan ulit.' }, 502); }
      return finish(parsed);
    } catch (err) {
      if (err instanceof PaymentRequiredError) return json({ error: keyProblem || 'Ubos na ang AI credits ng workspace. Mag-top up sa Lovable, o mag-save ng sariling AI key sa API Settings.' }, 402);
      if (err instanceof RateLimitError) return json({ error: 'Masyadong maraming request ngayon. Subukan ulit pagkalipas ng ilang segundo.' }, 429);
      console.error('caption-writer gateway error', err instanceof GatewayError ? [err.code, err.httpStatus, err.ids] : err);
      if (keyProblem) return json({ error: keyProblem }, 502);
    }
  }

  // nothing worked: say exactly WHAT to fix instead of a vague "try again"
  return json({
    error: keyProblem || 'Walang AI key. Pumunta sa API Settings → AI Engine, i-paste ang OpenRouter / OpenAI / Gemini key, i-save, at subukan ulit.',
  }, ai ? 502 : 503);
}

/** The Lovable gateway needs its own key; on Netlify it is normally absent, so we do not even try it there. */
function lovableAvailable(): boolean {
  return Boolean((process.env.LOVABLE_API_KEY ?? '').trim());
}

/** A provider error turned into plain Tagalog that says what to do. */
function friendlyKeyError(message: string, ai: AiConfig): string {
  const v = classifyAiError(message);
  const who = ai.kind === 'openrouter' ? 'OpenRouter' : ai.kind === 'gemini' ? 'Gemini' : 'OpenAI';
  if (v.keyValid === false) return `Tinanggihan ng ${who} ang AI key mo. Palitan ito sa API Settings → AI Engine.`;
  if (v.credits === 'empty') return `Ubos na ang credits ng ${who} key mo. Mag-top up sa ${who}, o mag-save ng ibang key sa API Settings.`;
  if (/rate-limiting|429/.test(v.message)) return `Pansamantalang nililimitahan ng ${who} ang key mo. Subukan ulit pagkalipas ng isang minuto.`;
  if (/model setting/i.test(v.message)) return `Hindi tinanggap ng ${who} ang model na naka-save. Iwanang blangko ang Model sa API Settings para gamitin ang default.`;
  if (/timed out|timeout|aborted/i.test(message)) return `Natagalan ang sagot ng ${who}. Subukan ulit.`;
  return `Hindi nakasagot ang ${who}: ${message.replace(/^(?:OpenAI|OpenRouter|Gemini) \d{3}: /, '').slice(0, 160)}`;
}
