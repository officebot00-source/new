// Server-side 24/7 bot worker. Triggered every minute by pg_cron (see migration).
// Social credentials AND the AI key (OpenRouter / OpenAI / Gemini) come from API Settings (stored server-side in
// integration_secrets); the old DISCORD_WEBHOOK_URL / TELEGRAM_* / GEMINI_API_KEY secrets still work as a fallback.
import type { SupabaseClient } from '@supabase/supabase-js';
import { supabaseAdmin } from '@/integrations/supabase/client.server';
import { aiJson, loadAiConfig, type AiConfig } from './_shared/ai.ts';
import { botIdByName, captureRealtimeLearning, loadBrain } from './_shared/brain.ts';
import { lessonFromAbWinner } from './_shared/lessons.ts';
import { authorized, isServiceCall, claimPost, loadCreds, makeLogger, publishClaimed, sendDiscord as sendDiscordTo, sendTelegram as sendTelegramTo } from './_shared/publish.ts';

const sb = supabaseAdmin as unknown as SupabaseClient;
const env = (k: string) => process.env[k] ?? '';
const HOUR = 3600_000;
const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));

type Level = 'info' | 'success' | 'warning' | 'error';
// sources map to the office bots: system=Cipher, ai-studio=Aria, auto-poster=Blaze, auto-inviter=Nova
async function log(level: Level, source: string, message: string) {
  const { error } = await sb.from('bot_logs').insert({ level, source, message });
  if (error) console.error('log failed', error.message);
}

interface Settings {
  auto_pilot_enabled: boolean; max_posts_per_hour: number; max_invites_per_hour: number;
  min_queue_size: number; winner_min_clicks: number; est_audience: number;
  platform_discord: boolean; platform_telegram: boolean; platform_facebook?: boolean; platform_twitter?: boolean;
}

/* ---------- senders (shared with the manual "Post now" function) ---------- */
let creds: Awaited<ReturnType<typeof loadCreds>> = {};
const sendDiscord = (text: string) => sendDiscordTo(creds.discord, text);
const sendTelegram = (text: string, chatId?: string) => sendTelegramTo(creds.telegram, text, chatId);
const logTo = makeLogger(sb);

/* ---------- AI (OpenRouter / OpenAI / Gemini — whichever key is saved in API Settings) ---------- */
type Copy = { content: string; hashtags: string };
async function aiPair(ai: AiConfig, prompt: string): Promise<{ a: Copy; b: Copy }> {
  const parsed = await aiJson<{ a?: Partial<Copy>; b?: Partial<Copy> }>(ai, prompt, 900);
  for (const k of ['a', 'b'] as const) if (typeof parsed?.[k]?.content !== 'string') throw new Error('AI returned an unexpected shape');
  return { a: { content: parsed.a!.content!, hashtags: parsed.a!.hashtags ?? '' }, b: { content: parsed.b!.content!, hashtags: parsed.b!.hashtags ?? '' } };
}

const PLATFORM_HINTS: Record<string, string> = {
  facebook: 'Facebook: story-driven, friendly, invites comments, up to ~600 characters',
  twitter: 'X/Twitter: punchy, strictly under 260 characters, 2-3 hashtags',
  discord: 'Discord: community call-out, markdown friendly, energetic',
  telegram: 'Telegram: short broadcast in a channel voice',
};
const PLATFORM_ORDER = ['facebook', 'twitter', 'discord', 'telegram'];

/** A platform counts as connected when its credentials are saved in API Settings. */
function connectedPlatforms(c: Awaited<ReturnType<typeof loadCreds>>): string[] {
  const has = (p: string, fields: string[]) => fields.every((f) => (c[p]?.[f] ?? '').trim() !== '');
  return PLATFORM_ORDER.filter((p) =>
    p === 'facebook' ? has(p, ['page_id', 'access_token'])
    : p === 'twitter' ? has(p, ['api_key', 'api_secret', 'access_token', 'access_secret'])
    : p === 'discord' ? has(p, ['webhook_url'])
    : has(p, ['bot_token', 'chat_id']));
}

/* ---------- worker ---------- */
export default async function handler(req: Request): Promise<Response> {
  if (!isServiceCall(req) && !authorized(req)) {
    return new Response(JSON.stringify({ error: 'Not allowed' }), { status: 401, headers: { 'Content-Type': 'application/json' } });
  }
  const summary: Record<string, unknown> = {};
  try {
    // Step A — Cipher: auto-pilot gate + rate limits
    const { data: s, error: sErr } = await sb.from('bot_settings').select('*').eq('id', 1).single();
    if (sErr || !s) throw new Error(`bot_settings unavailable: ${sErr?.message}`);
    const cfg = s as Settings;
    creds = await loadCreds(sb);
    const autoPilot = cfg.auto_pilot_enabled;
    // A post stuck in 'publishing' (a crashed run) goes back to the queue after 5 minutes.
    await sb.from('scheduled_posts').update({ status: 'queued' }).eq('status', 'publishing').lt('claimed_at', new Date(Date.now() - 5 * 60_000).toISOString());

    const since = new Date(Date.now() - HOUR).toISOString();
    const [{ count: postsHr }, { count: invitesHr }] = await Promise.all([
      sb.from('scheduled_posts').select('id', { count: 'exact', head: true }).eq('status', 'published').gte('published_at', since),
      sb.from('invite_queue').select('id', { count: 'exact', head: true }).eq('status', 'sent').gte('sent_at', since),
    ]);
    let postBudget = Math.max(0, cfg.max_posts_per_hour - (postsHr ?? 0));
    let inviteBudget = Math.max(0, cfg.max_invites_per_hour - (invitesHr ?? 0));
    if (new Date().getMinutes() % 15 === 0) await log('info', 'system', `Rate limit safe: posts ${postsHr ?? 0}/${cfg.max_posts_per_hour} hr, invites ${invitesHr ?? 0}/${cfg.max_invites_per_hour} hr.`);
    if (postBudget === 0) await log('warning', 'system', 'Post rate limit reached — holding publishes until next hour.');

    // Every platform that has real credentials is used automatically (the old on/off flags can only switch one OFF explicitly).
    const flagOff: Record<string, boolean> = { discord: cfg.platform_discord === false, telegram: cfg.platform_telegram === false };
    const platforms = connectedPlatforms(creds).filter((p) => !flagOff[p]);
    summary.platforms = platforms;
    const ai = await loadAiConfig(sb);
    if (autoPilot && !ai && new Date().getMinutes() % 10 === 0) await log('warning', 'ai-studio', 'No AI key saved yet — add your OpenRouter key in API Settings so Aria can write posts.');
    if (autoPilot && !platforms.length && new Date().getMinutes() % 10 === 0) await log('warning', 'auto-poster', 'No social account connected yet — save Facebook / X / Discord / Telegram credentials in API Settings.');

    // Step B — Aria: refill queue with A/B variants
    const { count: upcoming } = await sb.from('scheduled_posts').select('id', { count: 'exact', head: true }).eq('status', 'queued').gt('scheduled_at', new Date().toISOString());
    if (autoPilot && ai && (upcoming ?? 0) < cfg.min_queue_size && platforms.length) {
      const { data: games } = await sb.from('games').select('*').eq('active', true).limit(20);
      const game = games?.length ? games[Math.floor(Math.random() * games.length)] : null;
      if (game) {
        try {
          await log('info', 'ai-studio', `Drafting Variant A & B hooks for ${game.title}...`);
          const { data: last } = await sb.from('ab_results').select('variant_group, winner').eq('game_id', game.id).order('decided_at', { ascending: false }).limit(1).maybeSingle();
          let winnerHint = '';
          if (last) {
            const { data: w } = await sb.from('scheduled_posts').select('content').eq('variant_group', last.variant_group).eq('variant', last.winner).limit(1).maybeSingle();
            if (w) winnerHint = `\nA previous test was won by this style — keep that angle for both variants but vary the wording:\n"""${w.content.slice(0, 400)}"""`;
          }
          const brain = await loadBrain(sb, ai, { platforms, role: 'aria', context: `${game.title} ${game.genre ?? ''} ${game.description ?? ''}` });
          const group = crypto.randomUUID();
          const appOrigin = (env('PUBLIC_APP_URL') || new URL(req.url).origin).replace(/\/+$/, '');
          const track = (v: string) => `${appOrigin}/api/public/bot/track-click?c=${group}&v=${v}`;
          const out = await aiPair(ai, `You are a copywriter for an indie game studio. Write TWO promo posts for an A/B test.
Game: ${game.title}\nGenre: ${game.genre || 'n/a'}\nDescription: ${game.description || 'n/a'}${winnerHint}${brain.block}
Variant A angle: hype, FOMO, limited-time reward. Variant B angle: competitive challenge, gameplay curiosity.
Under 600 characters each. Do NOT include any URL. Return ONLY JSON: {"a":{"content":"...","hashtags":"#a #b #c"},"b":{"content":"...","hashtags":"#a #b #c"}}`);
          const start = Date.now() + 5 * 60_000;
          const rows = (['a', 'b'] as const).map((v, i) => ({
            game_id: game.id, game_title: game.title, platforms, tone: v === 'a' ? 'fomo' : 'competitive',
            content: `${out[v].content}\n${track(v)}`, hashtags: out[v].hashtags,
            status: 'queued', scheduled_at: new Date(start + i * 30 * 60_000).toISOString(), variant_group: group, variant: v, brain_rule_ids: brain.ids,
          }));
          const { error } = await sb.from('scheduled_posts').insert(rows);
          if (error) throw new Error(error.message);
          summary.generated = rows.length;
          await log('success', 'ai-studio', `Aria queued Variant A & B for ${game.title}`);
        } catch (e) {
          await log('error', 'ai-studio', `Auto-generate failed: ${(e as Error).message}`);
        }
      }
    }

    // Step B2 — Aria: daily coverage. Every connected platform gets at least one post in every 24 hours.
    if (autoPilot && ai && platforms.length) {
      try {
        const dayAgo = new Date(Date.now() - 24 * HOUR).toISOString();
        const { data: recent } = await sb.from('scheduled_posts').select('platforms, status, published_at, created_at')
          .in('status', ['queued', 'publishing', 'published']).or(`created_at.gte.${dayAgo},published_at.gte.${dayAgo}`);
        const covered = new Set<string>();
        for (const r of recent ?? []) for (const p of (r.platforms ?? []) as string[]) covered.add(p);
        const missing = platforms.filter((p) => !covered.has(p)).slice(0, 2); // 2 per run keeps the function fast
        if (missing.length) {
          const { data: games } = await sb.from('games').select('*').eq('active', true).limit(20);
          if (!games?.length) await log('warning', 'ai-studio', 'Daily post needs at least one ACTIVE game in Game Profiles.');
          for (const platform of games?.length ? missing : []) {
            const game = games![Math.floor(Math.random() * games!.length)];
            try {
              await log('info', 'ai-studio', `Aria: no post for ${platform} in the last 24h — drafting today's ${platform} post for ${game.title}...`);
              const brain = await loadBrain(sb, ai, { platforms: [platform], role: 'aria', context: `${game.title} ${game.genre ?? ''} ${game.description ?? ''} ${platform}` });
              const out = await aiJson<Partial<Copy>>(ai, `You are a social media copywriter for an indie game studio. Write ONE fresh promo post.
Game: ${game.title}\nGenre: ${game.genre || 'n/a'}\nDescription: ${game.description || 'n/a'}\nPromo link: ${game.promo_link || 'none'}
Platform: ${PLATFORM_HINTS[platform]}${brain.block}
Put the promo link on its own line if there is one. Return JSON: {"content":"...","hashtags":"#a #b #c"}`, 500);
              if (typeof out.content !== 'string') throw new Error('AI returned no content');
              const { error } = await sb.from('scheduled_posts').insert({
                game_id: game.id, game_title: game.title, platforms: [platform], tone: 'hype',
                content: out.content, hashtags: out.hashtags ?? '', status: 'queued', scheduled_at: new Date(Date.now() + 60_000).toISOString(), brain_rule_ids: brain.ids,
              });
              if (error) throw new Error(error.message);
              await log('success', 'ai-studio', `Aria queued today's ${platform} post for ${game.title}`);
            } catch (e) {
              await log('error', 'ai-studio', `Daily ${platform} post failed: ${(e as Error).message}`);
            }
          }
        }
      } catch (e) {
        await log('error', 'system', `Daily coverage check failed: ${(e as Error).message}`);
      }
    }

    // Step C — Blaze: publish due posts for real (manual schedules run even when auto-pilot is off)
    const { data: due } = await sb.from('scheduled_posts').select('id').eq('status', 'queued').lte('scheduled_at', new Date().toISOString()).order('scheduled_at').limit(10);
    let published = 0;
    for (const row of due ?? []) {
      if (postBudget <= 0) break;
      const post = await claimPost(sb, row.id as string);
      if (!post) continue; // another run or "Post now" already took it
      const outcome = await publishClaimed(sb, post, creds, cfg.est_audience, logTo);
      if (outcome.status === 'published') { postBudget--; published++; }
    }
    summary.published = published;

    // Step D — Nova: process invites within the hourly limit
    const { data: invites } = autoPilot
      ? await sb.from('invite_queue').select('*').eq('status', 'pending').order('created_at').limit(Math.min(inviteBudget, 5))
      : { data: [] as Record<string, any>[] };
    let invited = 0;
    for (const inv of invites ?? []) {
      if (inviteBudget <= 0) break;
      try {
        if (inv.platform === 'telegram') await sendTelegram(inv.message, /^-?\d+$/.test(inv.target_user) ? inv.target_user : undefined);
        else await sendDiscord(inv.message);
        await sb.from('invite_queue').update({ status: 'sent', sent_at: new Date().toISOString(), error: null }).eq('id', inv.id);
        inviteBudget--; invited++;
        await log('success', 'auto-inviter', `[${inv.platform}] Sent invite to ${inv.target_user}`);
      } catch (e) {
        await sb.from('invite_queue').update({ status: 'failed', error: (e as Error).message }).eq('id', inv.id);
        await log('error', 'auto-inviter', `[${inv.platform}] Invite to ${inv.target_user} failed: ${(e as Error).message}`);
      }
      await sleep(1500 + Math.random() * 2500); // randomized anti-ban delay (kept short for the function time limit)
    }
    summary.invited = invited;

    // Step E — Cipher: A/B winner check
    const { data: decided } = await sb.from('ab_results').select('variant_group');
    const done = new Set((decided ?? []).map((r) => r.variant_group));
    const { data: ab } = await sb.from('scheduled_posts').select('game_id, variant_group, variant, clicks, impressions').eq('status', 'published').not('variant_group', 'is', null);
    const groups = new Map<string, Record<string, { clicks: number; imp: number }> & { game?: string }>();
    for (const r of ab ?? []) {
      const g = groups.get(r.variant_group) ?? {};
      g[r.variant] = { clicks: (g[r.variant]?.clicks ?? 0) + r.clicks, imp: (g[r.variant]?.imp ?? 0) + r.impressions };
      g.game = r.game_id;
      groups.set(r.variant_group, g);
    }
    for (const [group, g] of groups) {
      if (done.has(group) || !g.a || !g.b) continue;
      if (g.a.clicks + g.b.clicks < cfg.winner_min_clicks) continue;
      const ctrA = (g.a.clicks / Math.max(g.a.imp, 1)) * 100, ctrB = (g.b.clicks / Math.max(g.b.imp, 1)) * 100;
      if (ctrA === ctrB) continue;
      const winner = ctrA > ctrB ? 'a' : 'b';
      await sb.from('ab_results').insert({ variant_group: group, game_id: g.game, winner, ctr_a: ctrA, ctr_b: ctrB });
      await log('success', 'system', `Variant ${winner.toUpperCase()} winning at ${Math.max(ctrA, ctrB).toFixed(1)}% CTR! Switching future posts to Variant ${winner.toUpperCase()}...`);
      await log('info', 'auto-poster', `Blaze: future auto-generated posts will use the Variant ${winner.toUpperCase()} style.`);
      // real-time lesson: the winning angle is shared with every bot right now, not at the next reflector run
      try {
        const { data: wp } = await sb.from('scheduled_posts').select('tone, platforms').eq('variant_group', group).eq('variant', winner).limit(1).maybeSingle();
        const lesson = wp && lessonFromAbWinner({ winnerTone: String(wp.tone), ctrWin: Math.max(ctrA, ctrB), ctrLose: Math.min(ctrA, ctrB), platforms: (wp.platforms ?? []) as string[] });
        if (lesson) {
          const r = await captureRealtimeLearning(sb, ai, lesson, { botId: await botIdByName(sb, 'Cipher') });
          if (r.status === 'created' || r.status === 'pending_review') await log('success', 'system', `Cipher: A/B result shared with the team — ${r.title}`);
        }
      } catch (e) { console.error('A/B lesson failed', (e as Error).message); }
    }

    return Response.json({ ok: true, ...summary });
  } catch (e) {
    await log('error', 'system', `Worker run failed: ${(e as Error).message}`);
    return Response.json({ ok: false, error: (e as Error).message }, { status: 500 });
  }
}
