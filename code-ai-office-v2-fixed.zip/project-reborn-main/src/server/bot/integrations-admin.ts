// Saves API credentials server-side (never readable from the browser) and tests them against the real services.
// Body: { action: 'save' | 'test' | 'send_test' | 'ai_status', provider: string, fields?: Record<string,string> }
import type { SupabaseClient } from '@supabase/supabase-js';
import { supabaseAdmin } from '@/integrations/supabase/client.server';
import { aiKeyStatus, loadAiConfig } from './_shared/ai.ts';
import { authorized, checkConnection, corsHeaders, FIELDS, json, loadCreds, makeLogger, sendTo } from './_shared/publish.ts';

const sb = supabaseAdmin as unknown as SupabaseClient;

export default async function handler(req: Request): Promise<Response> {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders });
  if (req.method !== 'POST') return json({ error: 'POST only' }, 405);
  if (!authorized(req)) return json({ error: 'Wrong or missing passcode' }, 401);

  let body: { action?: string; provider?: string; fields?: Record<string, unknown> };
  try { body = await req.json(); } catch { return json({ error: 'Invalid JSON' }, 400); }
  const provider = String(body.provider ?? '');
  if (!FIELDS[provider]) return json({ error: 'Unknown provider' }, 400);
  const log = makeLogger(sb);

  try {
    if (body.action === 'save') {
      const { data: row } = await sb.from('integration_secrets').select('secrets').eq('provider', provider).maybeSingle();
      const merged: Record<string, string> = { ...((row?.secrets ?? {}) as Record<string, string>) };
      for (const f of FIELDS[provider]) {
        const v = body.fields?.[f];
        if (typeof v === 'string' && v.trim() !== '') merged[f] = v.trim().slice(0, 2000); // empty = keep the saved value
      }
      const { error } = await sb.from('integration_secrets').upsert({ provider, secrets: merged, updated_at: new Date().toISOString() });
      if (error) throw new Error(error.message);
      const flags: Record<string, string> = {};
      for (const f of FIELDS[provider]) if (merged[f]) flags[f] = 'set';
      await sb.from('integrations').update({ config: flags, status: 'untested' }).eq('provider', provider);
      await log('info', 'system', `Cipher: saved credentials for ${provider} (stored server-side)`);
      return json({ ok: true, config: flags });
    }

    if (body.action === 'ai_status') {
      if (provider !== 'openai') return json({ error: 'ai_status is only for the AI key' }, 400);
      const status = await aiKeyStatus(await loadAiConfig(sb));
      if (status.configured) {
        const ok = status.keyValid === true && status.credits === 'ok';
        const bad = status.keyValid === false || status.credits === 'empty';
        if (ok || bad) await sb.from('integrations').update({ status: ok ? 'connected' : 'error' }).eq('provider', 'openai');
      }
      return json({ ok: true, status });
    }

    const creds = await loadCreds(sb);
    if (body.action === 'test') {
      try {
        const detail = await checkConnection(provider, creds);
        await sb.from('integrations').update({ status: 'connected' }).eq('provider', provider);
        await log('success', 'system', `Cipher: ${provider} connection verified — ${detail}`);
        return json({ ok: true, detail });
      } catch (e) {
        await sb.from('integrations').update({ status: 'error' }).eq('provider', provider);
        await log('error', 'system', `Cipher: ${provider} connection failed — ${(e as Error).message}`);
        return json({ ok: false, error: (e as Error).message });
      }
    }
    if (body.action === 'send_test') {
      if (provider === 'openai') return json({ ok: false, error: 'The AI key cannot send posts — use Test connection' });
      try {
        const r = await sendTo(provider, creds, `✅ Test post from Code Ai Office — ${new Date().toLocaleString('en-PH', { timeZone: 'Asia/Manila' })}`);
        await sb.from('integrations').update({ status: 'connected' }).eq('provider', provider);
        await log('success', 'auto-poster', `Blaze sent a real test post to ${provider}${r.url ? ` — ${r.url}` : ''}`);
        return json({ ok: true, detail: `Sent!${r.url ? ` ${r.url}` : ''}` });
      } catch (e) {
        await sb.from('integrations').update({ status: 'error' }).eq('provider', provider);
        await log('error', 'auto-poster', `Test post to ${provider} failed — ${(e as Error).message}`);
        return json({ ok: false, error: (e as Error).message });
      }
    }
    return json({ error: 'Unknown action' }, 400);
  } catch (e) {
    return json({ ok: false, error: (e as Error).message }, 500);
  }
}
