// Server-only. Cleans common copy/paste mistakes in Netlify env vars BEFORE anything reads them:
//   SUPABASE_URL = "https://abc.supabase.co/rest/v1/"  ->  https://abc.supabase.co
//   keys with quotes / spaces / newlines                ->  trimmed
// (supabase-js adds /rest/v1/... itself, so an extra path gives "Invalid path specified in request URL".)

const strip = (v: string) => v.trim().replace(/^["'`]+|["'`]+$/g, '').trim();

export function cleanSupabaseUrl(raw: string): string {
  const v = strip(raw);
  if (!v) return v;
  try {
    return new URL(/^https?:\/\//i.test(v) ? v : `https://${v}`).origin;
  } catch {
    return v;
  }
}

export function normalizeEnv(env: Record<string, string | undefined> = process.env): void {
  for (const k of ['SUPABASE_URL', 'VITE_SUPABASE_URL']) {
    if (env[k]) env[k] = cleanSupabaseUrl(env[k] as string);
  }
  for (const k of ['SUPABASE_SERVICE_ROLE_KEY', 'SUPABASE_PUBLISHABLE_KEY', 'VITE_SUPABASE_PUBLISHABLE_KEY', 'APP_PASSCODE', 'CRON_SECRET']) {
    if (env[k]) env[k] = strip(env[k] as string);
  }
}

if (typeof process !== 'undefined' && process.env) normalizeEnv();
