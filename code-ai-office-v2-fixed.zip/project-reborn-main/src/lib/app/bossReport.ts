// Ulat ng team kay Boss: totoong datos (posts at bot logs ngayong araw), hindi hula ng AI.
// Ginagamit kapag nagtanong ang owner ng "ano na ang natapos mo / ng team?" at para bigyan ang AI ng tunay na datos.
import { db } from './db';
import type { BotLog, Post } from './types';
import type { VoiceLang } from './voice';

export interface TeamReport {
  /** mga post na na-publish ngayong araw */
  published: number;
  /** mga post na naka-schedule pa */
  scheduled: number;
  /** mga post na pumalpak ngayong araw */
  failed: number;
  /** matagumpay na gawa ngayong araw, bawat bot (mula sa bot logs) */
  aria: number;
  blaze: number;
  /** Reel (video editor) */
  reel: number;
  nova: number;
  cipher: number;
  argus: number;
  /** ibang gawa ng team (IT, Shared Brain, utos ni Boss) */
  team: number;
  /** mga error at babala ngayong araw */
  errors: number;
  warnings: number;
  /** ilang utos ni Boss ang sinusunod ngayon */
  orders: number;
}

const startOfToday = (): number => { const d = new Date(); d.setHours(0, 0, 0, 0); return d.getTime(); };
const at = (iso: string | null | undefined): number => (iso ? new Date(iso).getTime() : 0);

const BLAZE = new Set(['auto-poster', 'scheduler']);
const REEL = new Set(['video-editor']);
const NOVA = new Set(['auto-inviter', 'comment-bot', 'x-bot']);

/** Kinukuha ang tunay na datos. Hindi nagt-throw: ibinabalik ang null kung walang mabasa. */
export async function loadTeamReport(orders = 0): Promise<TeamReport | null> {
  try {
    const [posts, logs] = await Promise.all([
      db.listPosts().catch(() => [] as Post[]),
      db.listLogs(300).catch(() => [] as BotLog[]),
    ]);
    const since = startOfToday();
    const now = Date.now();
    const r: TeamReport = { published: 0, scheduled: 0, failed: 0, aria: 0, blaze: 0, reel: 0, nova: 0, cipher: 0, argus: 0, team: 0, errors: 0, warnings: 0, orders };

    for (const p of posts) {
      if (p.status === 'published' && at(p.published_at ?? p.scheduled_at) >= since) r.published++;
      else if ((p.status === 'scheduled' || p.status === 'publishing') && at(p.scheduled_at) >= now - 60_000) r.scheduled++;
      else if (p.status === 'failed' && at(p.published_at ?? p.scheduled_at) >= since) r.failed++;
    }
    for (const l of logs) {
      if (at(l.created_at) < since) continue;
      if (l.level === 'error') { r.errors++; continue; }
      if (l.level === 'warning') { r.warnings++; continue; }
      if (l.level !== 'success') continue;
      if (l.source === 'ai-studio') r.aria++;
      else if (BLAZE.has(l.source)) r.blaze++;
      else if (REEL.has(l.source)) r.reel++;
      else if (NOVA.has(l.source)) r.nova++;
      else if (l.source === 'system') r.cipher++;
      else if (l.source === 'watchdog') r.argus++;
      else r.team++;
    }
    // kung walang nabasang posts pero may log na "LIVE: published", ibilang ito
    if (!r.published && r.blaze) r.published = logs.filter((l) => l.level === 'success' && l.source === 'auto-poster' && at(l.created_at) >= since && /LIVE: published/i.test(l.message)).length;
    return r;
  } catch {
    return null;
  }
}

const total = (r: TeamReport): number => r.published + r.aria + r.blaze + r.reel + r.nova + r.cipher + r.argus + r.team;

/** Ang ulat na sasabihin ni Boss (maikli, walang listahan, madaling basahin ng boses). */
export function reportText(r: TeamReport | null, lang: VoiceLang): string {
  const fil = lang === 'fil-PH';
  if (!r) {
    return fil
      ? 'Pasensya na, boss, hindi ko mabasa ang tala ng team ngayon. Subukan natin ulit sa ilang sandali.'
      : "Sorry, boss, I can't read the team's records right now. Let's try again in a moment.";
  }
  const parts: string[] = [];
  if (r.published) parts.push(fil ? `si Blaze ay nag-publish ng ${r.published} post` : `Blaze published ${r.published} post${r.published === 1 ? '' : 's'}`);
  if (r.reel) parts.push(fil ? `si Reel ay may ${r.reel} video na natapos` : `Reel finished ${r.reel} video task${r.reel === 1 ? '' : 's'}`);
  if (r.aria) parts.push(fil ? `si Aria ay nakagawa ng ${r.aria} content` : `Aria wrote ${r.aria} piece${r.aria === 1 ? '' : 's'} of content`);
  if (r.nova) parts.push(fil ? `si Nova ay may ${r.nova} invite at reply na natapos` : `Nova finished ${r.nova} invite${r.nova === 1 ? '' : 's'} and repl${r.nova === 1 ? 'y' : 'ies'}`);
  if (r.cipher + r.argus) parts.push(fil ? `sina Cipher at Argus ay may ${r.cipher + r.argus} tsek na natapos` : `Cipher and Argus completed ${r.cipher + r.argus} check${r.cipher + r.argus === 1 ? '' : 's'}`);
  if (r.team) parts.push(fil ? `at may ${r.team} pang gawain ang team gaya ng IT at Shared Brain` : `and the team did ${r.team} other task${r.team === 1 ? '' : 's'} like IT and Shared Brain`);

  const lines: string[] = [];
  if (total(r) > 0) {
    lines.push(fil ? `Boss, ito ang natapos namin ngayong araw: ${parts.join(', ')}.` : `Boss, here's what we finished today: ${parts.join(', ')}.`);
  } else {
    lines.push(fil ? 'Boss, wala pa kaming naitalang natapos na gawain ngayong araw.' : "Boss, we haven't logged any finished work today yet.");
  }
  if (r.scheduled) lines.push(fil ? `May ${r.scheduled} pang post na naka-schedule.` : `${r.scheduled} more post${r.scheduled === 1 ? ' is' : 's are'} scheduled.`);
  const bad = r.failed + r.errors;
  if (bad) lines.push(fil ? `May ${bad} problema na kailangan nating tingnan.` : `There ${bad === 1 ? 'is' : 'are'} ${bad} problem${bad === 1 ? '' : 's'} we should look at.`);
  else lines.push(fil ? 'Wala kaming problema.' : 'We have no problems.');
  if (r.orders) lines.push(fil ? `Sinusunod pa rin namin ang ${r.orders} utos mo.` : `We're still following your ${r.orders} order${r.orders === 1 ? '' : 's'}.`);
  lines.push(fil ? 'May iba ka bang ipapagawa?' : 'Anything else you want done?');
  return lines.join(' ');
}

/** Dagdag na linya sa "live status" para ang AI ay may tunay na datos na mababasa (hindi nag-iimbento). */
export function reportForAi(r: TeamReport | null): string {
  if (!r) return '';
  return `Finished today (real data): ${r.published} posts published, ${r.scheduled} scheduled, ${r.failed} failed posts; successful tasks: Aria ${r.aria}, Blaze ${r.blaze}, Reel ${r.reel}, Nova ${r.nova}, Cipher ${r.cipher}, Argus ${r.argus}, team ${r.team}; errors ${r.errors}, warnings ${r.warnings}; orders followed ${r.orders}.`;
}
