import { supabase as cloudClient } from '@/integrations/supabase/client';
import type { SupabaseClient } from '@supabase/supabase-js';

/** Every read and write goes through the app's own server routes; kept for the original screens' imports. */
export const supabase = cloudClient as unknown as SupabaseClient;

/** The backend is always connected in this app. Kept so the original screens keep their checks. */
export const isSupabaseConfigured = true;

/**
 * Where the app's own server routes live (the old Supabase functions, same names). Normally this same site;
 * a copy hosted elsewhere (e.g. Netlify) sets VITE_BOT_API_BASE to the Lovable-published site, because only
 * that server holds the database key.
 */
const apiBase = String(import.meta.env.VITE_BOT_API_BASE ?? '').replace(/\/+$/, '');
/** The host that actually answers the app's data requests (the Lovable-published site when VITE_BOT_API_BASE is set). */
export const botApiHost = (() => {
  try { return apiBase ? new URL(apiBase).host : window.location.host; } catch { return apiBase || 'this site'; }
})();
export const botFnUrl = (fn: string) => `${apiBase}/api/public/bot/${fn}`;
