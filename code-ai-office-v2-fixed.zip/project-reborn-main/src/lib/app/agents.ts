export type AgentId = 'aria' | 'blaze' | 'nova' | 'cipher';

export type AgentStatus = 'idle' | 'thinking' | 'typing' | 'posting' | 'paused';

export interface AgentDef {
  id: AgentId;
  name: string;
  role: string;
  color: string;
  glow: string;
  /** positions on the 900x520 office floor (isometric SVG coords) */
  x: number;
  y: number;
  sources: string[];
  idleLines: string[];
}

export const AGENTS: AgentDef[] = [
  {
    id: 'aria',
    name: 'Aria',
    role: 'Content Strategist & Copywriter',
    color: '#34d399',
    glow: 'rgba(52, 211, 153, 0.35)',
    x: 200,
    y: 150,
    sources: ['ai-studio', 'auto-pilot'],
    idleLines: [
      'Naghahanap ng bagong hook…', 'Binabasa ang game profiles', 'Pahinga muna sa draft ☕', 'Ang ganda ng caption na ito!',
      'Isa pang draft, tapos na!', 'Anong tone kaya: hype o chill?', 'Nag-edit ng hashtags #️⃣', 'Ayos na ang A/B copy ✍️',
      'Kailangan ko ng kape ☕', 'Magandang headline ito 💡', 'Tinitingnan ang trending words', 'Konting polish na lang ✨',
    ],
  },
  {
    id: 'blaze',
    name: 'Blaze',
    role: 'Social Media Publisher',
    color: '#38bdf8',
    glow: 'rgba(56, 189, 248, 0.35)',
    x: 620,
    y: 150,
    sources: ['auto-poster', 'scheduler'],
    idleLines: [
      'Binabantayan ang queue 👀', 'Chine-check ang koneksyon', 'Hinihintay ang next slot ⏱️', 'Ready na ang susunod na post',
      'Maayos ang Discord at Telegram', 'Tamang oras na ba? Malapit na!', 'Inaayos ang schedule 🗓️', 'Walang nakatambay na post!',
      'Pila ay maayos, boss', 'Handa na akong mag-publish 🚀', 'Sinusuri ang best posting hour', 'Steady lang ang pag-post',
    ],
  },
  {
    id: 'nova',
    name: 'Nova',
    role: 'Community Outreach & Auto-Invite',
    color: '#f472b6',
    glow: 'rgba(244, 114, 182, 0.35)',
    x: 200,
    y: 390,
    sources: ['auto-inviter', 'comment-bot', 'x-bot'],
    idleLines: [
      'Naghahanap ng bagong players 🔎', 'Nakikinig sa mga comment', 'Radar sweep na naman 📡', 'May interesadong player!',
      'Nagpapadala ng welcome 👋', 'Ang daming gamer ngayong gabi', 'Sinusuri ang mga keyword', 'Mabait ang community ngayon',
      'May nag-reply na player!', 'Isa pang invite, ayos!', 'Chine-check ang invite limit', 'Pa-welcome pa tayo 🎮',
    ],
  },
  {
    id: 'cipher',
    name: 'Cipher',
    role: 'Analytics & Anti-Ban Security',
    color: '#fbbf24',
    glow: 'rgba(251, 191, 36, 0.35)',
    x: 620,
    y: 390,
    sources: ['system', 'watchdog'],
    idleLines: [
      'Normal ang rate limits ✅', 'Tinitingnan ang engagement 📈', 'Wala akong nakitang panganib', 'Ligtas pa ang lahat 🔒',
      'Sinusuri ang CTR ng A at B', 'Ginagawa ang weekly report', 'Walang ban-risk, ayos!', 'Mababa pa ang invite rate',
      'Tamang bilis, hindi spam', 'May bagong data sa graph', 'Nagbabantay sa anti-ban 🛡️', 'Bilang ng clicks: tumataas!',
    ],
  },
];

export const AGENT_BY_ID = Object.fromEntries(AGENTS.map((a) => [a.id, a])) as Record<AgentId, AgentDef>;
