import type { Game } from './types';

/** Special value for the Game selector: post ALL saved (active) games at once. */
export const ALL_GAMES = '__all__';

export interface SavedCopy {
  content: string;
  hashtags: string;
}

const URL_RE = /https?:\/\/[^\s<>"')]+/gi;

export function gameLink(g: Pick<Game, 'promo_link'>): string {
  return (g.promo_link ?? '').trim();
}

/** Active games that actually have a saved link. */
export function linkedGames(games: Game[]): Game[] {
  return games.filter((g) => g.active !== false && gameLink(g));
}

/** One line per game: "Title — link". */
export function linksBlock(games: Game[]): string {
  return linkedGames(games)
    .map((g) => `${g.title}: ${gameLink(g)}`)
    .join('\n');
}

/**
 * Replaces whatever links are in the copy (old promo link, tracking link, Lovable preview link, bare domains)
 * with the links saved in the Games button, so the user never has to edit them by hand.
 * One game -> its link. All games -> a block with every game link.
 */
export function applyGameLinks(content: string, targets: Game[]): string {
  const withLinks = linkedGames(targets);
  if (withLinks.length === 0) return content;
  const replacement = withLinks.length === 1 ? gameLink(withLinks[0]) : linksBlock(withLinks);

  // keep our own game links as they are; only swap foreign ones
  const own = new Set(withLinks.map((g) => gameLink(g).toLowerCase()));
  let replaced = false;
  const swap = (m: string) => {
    if (own.has(m.toLowerCase())) return m;
    if (replaced) return '';
    replaced = true;
    return replacement;
  };
  let out = content.replace(URL_RE, swap);

  const hasAll = withLinks.every((g) => out.includes(gameLink(g)));
  if (!hasAll) {
    // remove blank leftovers, then append the missing links
    out = out.replace(/\n{3,}/g, '\n\n').trimEnd();
    const missing = withLinks.filter((g) => !out.includes(gameLink(g)));
    out += `\n\n${withLinks.length === 1 ? gameLink(missing[0] ?? withLinks[0]) : linksBlock(missing)}`;
  }
  return out;
}

/** Auto post covering every saved game, links included. */
export function buildAllGamesPost(games: Game[], hook?: string): { content: string; hashtags: string } {
  const list = linkedGames(games).length ? linkedGames(games) : games.filter((g) => g.active !== false);
  const lines = list.map((g) => (gameLink(g) ? `🎮 ${g.title} — ${gameLink(g)}` : `🎮 ${g.title}`)).join('\n');
  const intro = hook ?? 'Lahat ng laro namin, isang tap lang! Pili ka na at sumali na ngayon:';
  const tags = ['#gaming', '#playnow', ...list.map((g) => `#${g.title.toLowerCase().replace(/[^a-z0-9]/g, '')}`).filter((t) => t.length > 3)];
  return { content: `${intro}\n\n${lines}`, hashtags: [...new Set(tags)].slice(0, 6).join(' ') };
}
