/** Picks a random item but avoids repeating what was said recently (remembers the last few picks per list). */
const recent = new WeakMap<object, number[]>();

export function pickFresh<T>(arr: readonly T[]): T {
  if (arr.length <= 1) return arr[0];
  const hist = recent.get(arr) ?? [];
  const keep = Math.min(Math.max(1, Math.floor(arr.length / 2)), 14);
  let i = 0;
  let tries = 0;
  do {
    i = Math.floor(Math.random() * arr.length);
    tries++;
  } while (hist.includes(i) && tries < 25);
  hist.push(i);
  while (hist.length > keep) hist.shift();
  recent.set(arr, hist);
  return arr[i];
}

/**
 * Shortens a line so a speech bubble stays small on a phone and never hides the office details.
 * Keeps the first sentence if it is short enough, otherwise cuts at a word boundary.
 */
export function compactLine(text: string, max: number): string {
  const t = text.replace(/\s+/g, ' ').trim();
  if (t.length <= max) return t;
  const first = t.match(/^.{8,}?[.!?](?=\s|$)/u)?.[0];
  if (first && first.length <= max) return first;
  const cut = t.slice(0, max - 1);
  const sp = cut.lastIndexOf(' ');
  return `${(sp > max * 0.55 ? cut.slice(0, sp) : cut).replace(/[\s,.;:—-]+$/u, '')}…`;
}
