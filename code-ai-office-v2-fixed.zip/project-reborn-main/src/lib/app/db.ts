import { isSupabaseConfigured } from './supabase';
import { adminRead, adminWrite } from './publish';
import type { BotLog, Game, Integration, InviteRule, LogLevel, Post } from './types';

export interface SavedCopyRow {
  id: string;
  copy_key: string;
  content: string;
  hashtags: string;
}

async function log(level: LogLevel, source: string, message: string) {
  try {
    await adminWrite('bot_logs', 'insert', { row: { level, source, message } });
  } catch (err) {
    console.error('Failed to write log:', err instanceof Error ? err.message : err);
  }
}

const remoteDb = {
  async listGames() {
    return (await adminRead<Game[]>('games')) ?? [];
  },
  async saveGame(game: Partial<Game> & { title: string }) {
    if (game.id) {
      await adminWrite('games', 'update', { id: game.id, row: game as Record<string, unknown> });
      return;
    }
    await adminWrite('games', 'insert', { row: game as Record<string, unknown> });
  },
  async deleteGame(id: string) {
    await adminWrite('games', 'delete', { id });
  },

  async listSavedCopies() {
    return (await adminRead<SavedCopyRow[]>('studio_saved_copy')) ?? [];
  },
  async saveSavedCopy(copy_key: string, content: string, hashtags: string, id?: string): Promise<string> {
    const row = { copy_key, content, hashtags, updated_at: new Date().toISOString() };
    if (id) {
      await adminWrite('studio_saved_copy', 'update', { id, row });
      return id;
    }
    const r = await adminWrite('studio_saved_copy', 'insert', { row });
    return r.id as string;
  },
  async deleteSavedCopy(id: string) {
    await adminWrite('studio_saved_copy', 'delete', { id });
  },

  async listPosts() {
    const data = await adminRead<Record<string, unknown>[]>('scheduled_posts');
    // the worker uses 'queued'; the UI calls the same state 'scheduled'
    return (data ?? []).map((r) => ({
      ...r,
      status: r.status === 'queued' ? 'scheduled' : r.status,
    })) as unknown as Post[];
  },
  async savePost(input: Partial<Post> & { game_id: string | null; game_title: string }): Promise<string> {
    const post = { ...input, status: input.status === 'scheduled' ? 'queued' : input.status };
    if (post.id) {
      await adminWrite('scheduled_posts', 'update', { id: post.id, row: post as Record<string, unknown> });
      return post.id;
    }
    const r = await adminWrite('scheduled_posts', 'insert', { row: post as Record<string, unknown> });
    return r.id as string;
  },
  async deletePost(id: string) {
    await adminWrite('scheduled_posts', 'delete', { id });
  },

  async listInviteRules() {
    return (await adminRead<InviteRule[]>('invite_rules')) ?? [];
  },
  async saveInviteRule(rule: Partial<InviteRule> & { name: string }) {
    if (rule.id) {
      await adminWrite('invite_rules', 'update', { id: rule.id, row: rule as Record<string, unknown> });
      return;
    }
    await adminWrite('invite_rules', 'insert', { row: rule as Record<string, unknown> });
  },
  async deleteInviteRule(id: string) {
    await adminWrite('invite_rules', 'delete', { id });
  },

  async getAutoPilot(): Promise<boolean> {
    const data = await adminRead<{ auto_pilot_enabled?: boolean } | null>('bot_settings');
    return Boolean(data?.auto_pilot_enabled);
  },
  async setAutoPilot(enabled: boolean) {
    await adminWrite('bot_settings', 'update', { id: 1, row: { auto_pilot_enabled: enabled, updated_at: new Date().toISOString() } });
  },

  async listLogs(limit = 100) {
    return (await adminRead<BotLog[]>('bot_logs', { limit })) ?? [];
  },
  log,

  async listIntegrations() {
    return (await adminRead<Integration[]>('integrations')) ?? [];
  },
  // Remote mode: credentials are saved through the `integrations-admin` function (see lib/publish.ts); this table only
  // keeps which fields are set and the connection status.
  async saveIntegration(integration: Integration) {
    await adminWrite('integrations', 'update', { id: integration.id, row: { status: integration.status } });
  },
};

/* ------------------------------------------------------------------ *
 * Local mode: when Supabase env vars are missing (e.g. Netlify build
 * without them) the whole app keeps working using localStorage instead
 * of throwing errors. Data stays in this browser only.
 * ------------------------------------------------------------------ */
const LOG_EVENT = 'botoffice:log';
const uid = () => (crypto.randomUUID ? crypto.randomUUID() : `${Date.now()}-${Math.random().toString(16).slice(2)}`);

function lread<T>(key: string, fallback: T): T {
  try {
    const raw = localStorage.getItem(`local_${key}`);
    return raw ? (JSON.parse(raw) as T) : fallback;
  } catch {
    return fallback;
  }
}
function lwrite(key: string, value: unknown) {
  try {
    localStorage.setItem(`local_${key}`, JSON.stringify(value));
  } catch {
    /* storage full/unavailable: ignore */
  }
}

type Row = { id: string; created_at: string } & Record<string, unknown>;
function upsertLocal<T extends Row>(key: string, item: Partial<T>) {
  const rows = lread<T[]>(key, []);
  if (item.id) {
    lwrite(key, rows.map((r) => (r.id === item.id ? { ...r, ...item } : r)));
  } else {
    lwrite(key, [{ ...item, id: uid(), created_at: new Date().toISOString() }, ...rows]);
  }
}
const newest = <T extends { created_at: string }>(rows: T[]) =>
  [...rows].sort((a, b) => b.created_at.localeCompare(a.created_at));

const DEFAULT_INTEGRATIONS: Integration[] = [
  { id: 'local-openai', provider: 'openai', label: 'OpenAI', config: { model: 'gpt-4o-mini', api_key: '' }, status: 'untested', created_at: '2026-01-01T00:00:00Z' },
  { id: 'local-facebook', provider: 'facebook', label: 'Facebook Page', config: { page_id: '', access_token: '' }, status: 'untested', created_at: '2026-01-01T00:00:01Z' },
  { id: 'local-discord', provider: 'discord', label: 'Discord', config: { webhook_url: '' }, status: 'untested', created_at: '2026-01-01T00:00:02Z' },
  { id: 'local-telegram', provider: 'telegram', label: 'Telegram', config: { bot_token: '', chat_id: '' }, status: 'untested', created_at: '2026-01-01T00:00:03Z' },
  { id: 'local-twitter', provider: 'twitter', label: 'X (Twitter)', config: {}, status: 'untested', created_at: '2026-01-01T00:00:04Z' },
];

const localDb: typeof remoteDb = {
  async listGames() {
    return newest(lread<Game[]>('games', []));
  },
  async saveGame(game) {
    upsertLocal<Game & Row>('games', game as Partial<Game & Row>);
  },
  async deleteGame(id) {
    lwrite('games', lread<Game[]>('games', []).filter((g) => g.id !== id));
  },
  async listSavedCopies() {
    return lread<SavedCopyRow[]>('studio_saved_copy', []);
  },
  async saveSavedCopy(copy_key, content, hashtags, id) {
    const rows = lread<SavedCopyRow[]>('studio_saved_copy', []);
    const existing = rows.find((r) => r.copy_key === copy_key || (id && r.id === id));
    const rid = existing?.id ?? uid();
    lwrite('studio_saved_copy', [{ id: rid, copy_key, content, hashtags }, ...rows.filter((r) => r.id !== rid)]);
    return rid;
  },
  async deleteSavedCopy(id) {
    lwrite('studio_saved_copy', lread<SavedCopyRow[]>('studio_saved_copy', []).filter((r) => r.id !== id));
  },
  async listPosts() {
    return [...lread<Post[]>('posts', [])].sort((a, b) => b.scheduled_at.localeCompare(a.scheduled_at));
  },
  async savePost(input) {
    upsertLocal<Post & Row>('posts', input as Partial<Post & Row>);
    return input.id ?? '';
  },
  async deletePost(id) {
    lwrite('posts', lread<Post[]>('posts', []).filter((p) => p.id !== id));
  },
  async listInviteRules() {
    return newest(lread<InviteRule[]>('invite_rules', []));
  },
  async saveInviteRule(rule) {
    upsertLocal<InviteRule & Row>('invite_rules', rule as Partial<InviteRule & Row>);
  },
  async deleteInviteRule(id) {
    lwrite('invite_rules', lread<InviteRule[]>('invite_rules', []).filter((r) => r.id !== id));
  },
  async getAutoPilot() {
    return lread<boolean>('auto_pilot', false);
  },
  async setAutoPilot(enabled) {
    lwrite('auto_pilot', enabled);
  },
  async listLogs(limit = 100) {
    return newest(lread<BotLog[]>('bot_logs', [])).slice(0, limit);
  },
  async log(level, source, message) {
    const row: BotLog = { id: uid(), level, source, message, created_at: new Date().toISOString() };
    lwrite('bot_logs', [row, ...lread<BotLog[]>('bot_logs', [])].slice(0, 300));
    window.dispatchEvent(new CustomEvent(LOG_EVENT, { detail: row }));
  },
  async listIntegrations() {
    return lread<Integration[]>('integrations', DEFAULT_INTEGRATIONS);
  },
  async saveIntegration(integration) {
    const rows = lread<Integration[]>('integrations', DEFAULT_INTEGRATIONS);
    lwrite('integrations', rows.map((r) => (r.id === integration.id ? integration : r)));
  },
};

export const db = isSupabaseConfigured ? remoteDb : localDb;

/** Live bot_logs feed. Uses Supabase realtime when configured, a window event in local mode. */
export function subscribeLogs(onInsert: (row: BotLog) => void): () => void {
  if (!isSupabaseConfigured) {
    const handler = (e: Event) => onInsert((e as CustomEvent<BotLog>).detail);
    window.addEventListener(LOG_EVENT, handler);
    return () => window.removeEventListener(LOG_EVENT, handler);
  }
  // The activity log is private, so instead of a public live feed the server is asked every few seconds for
  // anything newer than the last entry seen (only while the tab is visible).
  let since = new Date().toISOString();
  let stopped = false;
  const poll = async () => {
    if (stopped || document.hidden) return;
    try {
      const rows = await adminRead<BotLog[]>('bot_logs', { since, limit: 50 });
      if (stopped || !rows?.length) return;
      since = rows[0].created_at;
      for (const row of [...rows].reverse()) onInsert(row);
    } catch { /* offline or locked: try again next tick */ }
  };
  const t = window.setInterval(() => void poll(), 5000);
  return () => {
    stopped = true;
    window.clearInterval(t);
  };
}
