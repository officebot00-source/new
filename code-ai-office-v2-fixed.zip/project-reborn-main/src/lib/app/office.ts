import { useCallback, useEffect, useRef, useState } from 'react';
import { AGENTS, type AgentId } from './agents';
import { PERSON_NAME, type AfterCallPlan, type PersonKey } from './callActions';
import { hasPlan, queuePlan, takePlan } from './pendingPlans';
import { db } from './db';
import { pickFresh } from './dialogue';
import { isSupabaseConfigured } from './supabase';
import { adminRead } from './publish';
import type { CommandMode } from './bossCommand';
import { ARGUS_BREAK_BACK, ARGUS_BREAK_GO, initReelRoutine, stepReel, type ReelDoing, type ReelRoutine } from './reelRoutine';

/** Mga aral na totoong natutunan ng team (galing sa Shared Brain) — ito ang "inilalagay" ng mga bot sa hologram. */
interface Lesson { id: string; title: string; category: string }
const LESSON_BOT: Record<string, AgentId> = { winning_hook: 'aria', audience_insight: 'aria', best_timing: 'blaze', invite_script: 'nova', ban_guardrail: 'cipher' };
async function fetchLessons(): Promise<Lesson[]> {
  if (!isSupabaseConfigured) return [];
  try {
    return (await adminRead<Lesson[]>('lessons')) ?? [];
  } catch { return []; }
}

/** Mga miyembro ng pangunahing team (kasama sa meeting at coffee break). */
export type TeamId = AgentId | 'boss' | 'sec';
/** Lahat ng empleyado, kasama si Dex ng IT (Server Room) at si Argus ang Watchdog (sariling office). Si Argus ay sumasama sa meeting; si Dex at si Argus ay hindi kasama sa coffee/arcade. */
export type MemberId = TeamId | 'it' | 'argus';
/** office = sariling desk · rest = idlip sa sofa ng sariling office (nagpapahinga kapag pagod)
 *  lab = nakaupo sa meeting table · bar = mini bar
 *  drop = nakatayo sa hologram ng Shared Brain (ilagay/basahin ang idea) · brief = secretary sa tabi ng boss
 *  dine = nakaupo sa Canteen (kainan) · play = nakatayo sa arcade machine
 *  fix = si Dex (IT) lang: nakatayo sa tabi ng desk ng empleyadong inaayusan niya (tingnan ang itTarget) */
export type Place = 'office' | 'rest' | 'lab' | 'bar' | 'drop' | 'brief' | 'dine' | 'play' | 'fix';
/** ideas = pangongolekta, pagbabasa at pag-uulat ng secretary bago ang meeting
 *  meal = kainan sa Canteen (almusal / tanghalian / hapunan) · arcade = arcade break */
export type Phase = 'work' | 'ideas' | 'meeting' | 'coffee' | 'meal' | 'arcade' | 'service';
export type Meal = 'breakfast' | 'lunch' | 'dinner';

export interface Idea {
  id: string;
  by: AgentId;
  text: string;
  verdict: string;
  at: number;
  /** true = totoong natutunan mula sa Shared Brain (hindi kathang-isip) */
  real?: boolean;
}

export const BOSS = {
  id: 'boss' as const,
  name: 'Code Solo',
  role: 'Boss · Chief Orchestrator',
  color: '#f59e0b',
};

export const SECRETARY = {
  id: 'sec' as const,
  name: 'Ms. Mira',
  role: 'Executive Secretary · Meetings & Planning',
  color: '#f472b6',
};

export const IT_STAFF = {
  id: 'it' as const,
  name: 'Dex',
  role: 'IT Administrator · Servers & Network',
  color: '#22d3ee',
};

/** Si Argus ang Watchdog: nagbabantay sa lahat ng post at comment, kinukulit ang team kapag may na-miss. Hindi siya umaalis sa office niya. */
export const ARGUS = {
  id: 'argus' as const,
  name: 'Argus',
  role: 'Watchdog · Missed Posts & Comments',
  color: '#fb7185',
};

/** Oras ng kainan (24-hour clock). Kapag pumasok ang oras sa window, kakain ang buong team ng isang beses kada araw. */
export const MEAL_INFO: Record<Meal, { label: string; emoji: string; from: number; to: number; time: string }> = {
  breakfast: { label: 'Almusal', emoji: '🍳', from: 7, to: 9, time: '7:00 AM' },
  lunch: { label: 'Tanghalian', emoji: '🍛', from: 12, to: 14, time: '12:00 NN' },
  dinner: { label: 'Hapunan', emoji: '🍲', from: 18, to: 20, time: '6:00 PM' },
};

/** Anong kainan ang dapat ngayon (ayon sa oras), o ang pinakamalapit kapag manual na pinindot ang button. */
export function mealForHour(hour: number): Meal {
  if (hour < 10) return 'breakfast';
  if (hour < 16) return 'lunch';
  return 'dinner';
}

function activeMeal(now: Date): Meal | null {
  const h = now.getHours();
  for (const m of Object.keys(MEAL_INFO) as Meal[]) {
    if (h >= MEAL_INFO[m].from && h < MEAL_INFO[m].to) return m;
  }
  return null;
}

const mealKey = (now: Date, m: Meal) => `office-meal:${now.getFullYear()}-${now.getMonth() + 1}-${now.getDate()}:${m}`;
function mealDone(now: Date, m: Meal): boolean {
  try { return window.localStorage.getItem(mealKey(now, m)) === '1'; } catch { return false; }
}
function markMealDone(now: Date, m: Meal) {
  try { window.localStorage.setItem(mealKey(now, m), '1'); } catch { /* private mode: ok lang */ }
}

/** Isang IT ticket: ang problema sa internet o computer na inayos ni Dex sa office ng empleyado. */
export type TicketKind = 'net' | 'pc';
export interface Ticket {
  id: string;
  who: TeamId;
  kind: TicketKind;
  issue: string;
  cause: string;
  at: number;
}

export interface IdeaReport {
  summary: string;
  count: number;
  at: number;
}

/* ------------------------------------------------------------------ *
 * Floor plan (percent of the office container, world 80 x 52 units)
 * ------------------------------------------------------------------ */
export interface Room { x: number; y: number; w: number; h: number }

export const ROOMS: Record<AgentId | 'boss' | 'lab' | 'bar' | 'server' | 'canteen' | 'arcade' | 'argus', Room> = {
  // four private offices in the corners, with a wide hallway on each side
  aria: { x: 3, y: 3, w: 23, h: 38 },
  nova: { x: 3, y: 59, w: 23, h: 38 },
  blaze: { x: 74, y: 3, w: 23, h: 38 },
  cipher: { x: 74, y: 59, w: 23, h: 38 },
  // shared rooms down the middle, separated by cross-hallways
  boss: { x: 33, y: 3, w: 34, h: 24 },
  lab: { x: 33, y: 35, w: 34, h: 28 },
  bar: { x: 33, y: 71, w: 34, h: 26 },
  // Office ni Argus (Watchdog): sa kanang gilid, sa pagitan nina Blaze at Cipher — ang pinto ay nakaharap sa kanang hallway.
  // Ang hilaga at timog na pader ay ang mga pader na nina Blaze (y=41) at Cipher (y=59).
  argus: { x: 74, y: 41, w: 23, h: 18 },
  // timog pakpak (south wing): Server Room (IT) · Canteen · Arcade — nasa dulo ng dalawang hallway
  // (y > 100 dahil nasa labas ng orihinal na 80 x 52 na plano; 1% = 0.52 units sa z)
  server: { x: 3, y: 104.8, w: 23, h: 25 },
  canteen: { x: 33, y: 104.8, w: 34, h: 25 },
  arcade: { x: 74, y: 104.8, w: 23, h: 25 },
};

type XY = { x: number; y: number };

const deskSpot = (id: AgentId): XY => ({ x: ROOMS[id].x + ROOMS[id].w / 2, y: ROOMS[id].y + ROOMS[id].h * 0.66 });

const LAB_SPOTS: Record<TeamId, XY> = {
  boss: { x: 50, y: 42 },
  aria: { x: 40, y: 47.5 },
  blaze: { x: 60, y: 47.5 },
  nova: { x: 40, y: 52 },
  cipher: { x: 60, y: 52 },
  sec: { x: 50, y: 56 },
};

const BAR_SPOTS: Record<TeamId, XY> = {
  aria: { x: 40.6, y: 83.5 },
  nova: { x: 44.4, y: 83.5 },
  sec: { x: 48.1, y: 83.5 },
  boss: { x: 51.9, y: 83.5 },
  blaze: { x: 55.6, y: 83.5 },
  cipher: { x: 59.4, y: 83.5 },
};

const DROP_SPOTS: Record<TeamId, XY> = {
  aria: { x: 45.5, y: 55 },
  nova: { x: 48.5, y: 55 },
  blaze: { x: 51.5, y: 55 },
  cipher: { x: 54.5, y: 55 },
  sec: { x: 46.7, y: 43 },
  boss: { x: 50, y: 43 },
};

export function spotFor(id: MemberId, place: Place): XY {
  if (id === 'argus') {
    // sumasama si Argus sa meeting: upuan niya ay sa hilagang-silangang gilid ng mesa
    if (place === 'lab') return { x: 56, y: 45 };
    return { x: ROOMS.argus.x + ROOMS.argus.w / 2, y: ROOMS.argus.y + ROOMS.argus.h * 0.5 };
  }
  if (id === 'it') return { x: ROOMS.server.x + ROOMS.server.w / 2, y: ROOMS.server.y + ROOMS.server.h * 0.5 };
  if (place === 'dine') return { x: 50, y: 117 };
  if (place === 'play') return { x: 85, y: 117 };
  if (place === 'lab') return LAB_SPOTS[id];
  if (place === 'bar') return BAR_SPOTS[id];
  if (place === 'drop') return DROP_SPOTS[id];
  if (place === 'brief') return { x: 54, y: 14 };
  if (id === 'sec') return { x: 59, y: 15 };
  if (id === 'boss') return { x: 50, y: 15 };
  return deskSpot(id);
}

/* ------------------------------------------------------------------ *
 * Dialogue pools
 * ------------------------------------------------------------------ */
const IDEAS: Record<AgentId, string[]> = {
  aria: [
    'Gumawa tayo ng "Weekend Tournament" teaser na may countdown!',
    'Gawin nating meme-style ang hook ng leaderboard post.',
    'Mag-A/B test tayo: hype tone vs FOMO tone sa bagong game.',
    'Daily Challenge post series para laging may reason bumalik ang players.',
    'Mag-post ng \"Player of the Week\" shoutout para sumigla ang community.',
    'Gumawa ng polls: \"Anong game ang next update?\" para sumali ang lahat.',
    'Short \"Tips & Tricks\" series para sa mga bagong player.',
    'Gamitin ang Tagalog slang sa hook para mas relatable.',
  ],
  blaze: [
    'Best engagement ay 7–9PM, doon natin i-schedule ang big posts.',
    'Cross-post sa Discord at Telegram 10 mins pagkatapos ng Facebook.',
    'Mag-reuse tayo ng top post bilang "Throwback Thursday".',
    'Gawin nating 3 posts/day lang para di mukhang spam.',
    'Mag-iba ng oras bawat araw para hindi predictable ang pattern.',
    'Pin natin ang pinakamagandang post sa itaas ng page.',
    'Mag-repost ng reminder bago magsimula ang event.',
    'I-check ang reply sa unang 30 minutos para mas tumaas ang reach.',
  ],
  nova: [
    'Auto-invite natin ang mga nag-comment ng "join" o "link".',
    'Welcome DM na may promo link para sa mga bagong player.',
    'Mag-target tayo ng gaming groups na active tuwing gabi.',
    'Gumawa ng referral invite: mag-invite ng friend, may reward.',
    'Mag-welcome ng bagong member sa pangalan nila para personal.',
    'Gumawa ng \"Looking for Group\" thread tuwing weekend.',
    'Mag-thank you sa mga player na nag-share ng post natin.',
    'I-segment ang invites ayon sa laro: racing, fighting, puzzle.',
  ],
  cipher: [
    'Limit natin sa 12 invites/hour para iwas ban.',
    'I-pause ang variant B, mababa ang CTR niya.',
    'Mag-add tayo ng random delay para mukhang natural ang activity.',
    'Weekly report: top game, top platform, at best posting hour.',
    'Mag-alarm kapag lumagpas sa safe limit ang invites.',
    'I-compare ang CTR ng umaga at gabi para mas matalino ang schedule.',
    'Mag-backup ng queue araw-araw para walang mawala.',
    'Gawing 20% ang random delay para mas natural sa platform.',
  ],
};

const REACTIONS = [
  'Solid yan! 🔥', '+1 dito!', 'Noted, i-aayon ko ang plano ko.', 'Magandang idea, Boss!', 'Game ako diyan! 💪',
  'Ayos! Pwede yan i-combine sa akin.', 'Sang-ayon ako! 👍', 'Ang galing nito!', 'Gawin natin agad!', 'Panalo yan!',
  'May naisip akong dagdag diyan.', 'Sige, ako na bahala sa parte ko.', 'Maganda ang timing niyan ⏱️', 'Pak! Ganda ng plano 🎯',
];

const VERDICTS = [
  'Approved ✅ — i-queue na natin yan ngayong linggo.',
  'Approved ✅ — Aria mag-draft, Blaze mag-schedule.',
  'Approved ✅ — i-test muna natin, tapos i-scale.',
  'Approved ✅ — simulan na bukas ng umaga.',
  'Approved ✅ — Cipher, bantayan ang resulta.',
  'Approved ✅ — gawin natin ngayong linggo.',
];

const JOKES = [
  'Bakit pagod lagi ang server? 24/7 naka-duty, walang 13th month! 😅',
  'Anong paborito kong kape? Java-Script! ☕',
  'Bakit mabagal ang kape? Kasi mataas ang latte-ncy. 🐢',
  'Boss, kape po. — Sige, i-charge sa budget ng Brainstorm. 😂',
  'Bakit di nagugutom ang bot? Kasi laging may cache! 🍪',
  'Bakit di ngumingiti si Cipher? Rate-limited po siya. 😆',
  'Sabi ng bot sa kape: "Thanks, na-upgrade ako sa v2.0!" ⚡',
  'Bakit di nag-aaway ang mga bot? Kasi pareho silang naka-sync! 🤝',
  'Anong sabi ng bug sa dev? \"Feature ako, hindi error!\" 🐛',
  'Bakit malungkot ang laptop? Walang Windows sa buhay niya. 🪟',
  'Bakit mahilig sa kape ang coder? Para hindi mag-timeout. ⏳',
  'Anong paboritong ulam ng programmer? Byte-sing! 🍗',
  'Bakit laging kalmado si Dex? May backup siya sa lahat. 💾',
  'Anong sabi ng database sa server? \"Ikaw ang aking query!\" 💕',
  'Bakit di nagsisinungaling ang bot? Kasi may logs! 📜',
  'Boss, kailan ang sahod? — Loading… 99% ⏳',
];

const LAUGHS = [
  'HAHAHA 😂', 'Ang corny pero tawa pa rin ako 🤣', 'Hahaha, Boss ikaw talaga!', 'LOL 😆', 'Isa pa nga! 😄',
  'Naiyak ako sa tawa 😭', 'Ayos! Corny pero okay 😅', 'Hahaha, sakit ng tiyan ko!', 'Grabe ka talaga! 🤣', 'Pak na pak! 👏',
];
const FOOD_REPLY = ['Sarap! 😋', 'Penge pa ng ulam!', 'Ang bango! 🤤', 'Sulit ang luto ngayon!', 'Dagdag kanin pa! 🍚', 'Busog na busog! 😌', 'Pakipasa ng sawsawan!', 'Ang sarap talaga!'];

const MEAL_CALL: Record<Meal, string> = {
  breakfast: 'Boss, almusal na po! 🍳 Handa na ang sinangag, itlog at kape sa Canteen.',
  lunch: 'Boss, tanghalian na po! 🍛 Naghihintay na ang kanin at ulam sa Canteen.',
  dinner: 'Boss, hapunan na po! 🍲 Mainit pa ang sabaw at ulam sa Canteen.',
};
const MEAL_BOSS: Record<Meal, string> = {
  breakfast: 'Sige, almusal muna bago ang laban ngayong araw! Tara, team! 🌅',
  lunch: 'Mabuti. Pahinga muna sa trabaho — tanghalian tayo, team! ☀️',
  dinner: 'Tamang-tama, gutom na rin ako. Hapunan na, team! 🌙',
};
const MEAL_DISHES: Record<Meal, string[]> = {
  breakfast: ['Sinangag, itlog at tapsilog! 🍳', 'Pandesal na may kesong puti at mainit na kape ☕', 'Champorado na may tuyo, klasik! 🥣', 'Longsilog ang akin — ang sarap! 🌭', 'Bangus silog, panalo! 🐟', 'Arroz caldo na may itlog! 🍚', 'Tocino at mainit na sinangag 🥓', 'Pandesal at kape lang, sapat na! 🥖'],
  lunch: ['Adobo at maraming kanin! 🍛', 'Sinigang na baboy, ang asim-sarap! 🍲', 'Chicken inasal na may extra rice! 🍗', 'Kare-kare na may bagoong, panalo! 🥘', 'Bulalo, mainit at malinamnam! 🍖', 'Pinakbet na may bagnet! 🥬', 'Sisig at sinaing, solid! 🔥', 'Menudo at kanin, sarap! 🍛'],
  dinner: ['Tinolang manok, mainit at masabaw! 🍲', 'Pritong isda at sinangag, simpleng sarap 🐟', 'Pancit canton para sa mahabang buhay! 🍜', 'Lechon kawali na may sawsawang suka! 🥓', 'Nilagang baka, nakakagaan ng loob 🍲', 'Ginataang gulay at isda 🥥', 'Sinampalukang manok, asim-sarap! 🍗', 'Bistek at maraming sibuyas! 🧅'],
};
const MEAL_TALK: Record<Meal, string[]> = {
  breakfast: ['Ang aga natin ngayon ah, may energy na tayo! ⚡', 'Mas masarap ang kape kapag may kasabay na pandesal. ☕', 'Handa na ako sa mga post at invites ngayong araw! 💪', 'Almusal muna, tapos laban na ulit! 🌅'],
  lunch: ['Busog na busog! Baka antukin ako mamaya, hehe 😴', 'Ang sarap ng ulam ngayon, sino ang nagluto? 😋', 'Pahinga muna ang isip, kain muna tayo! 🍽️', 'Dagdag kanin pa, please! 🍚'],
  dinner: ['Magandang pagtatapos ng araw, kain tayo! 🌆', 'Night shift pa rin ang servers, pero kain muna ako. 😅', 'Ang init ng sabaw, ang sarap sa pakiramdam! 🍲', 'Salamat sa buong araw, team! 🙌'],
};
const MEAL_THANKS: Record<Meal, string> = {
  breakfast: 'Salamat sa almusal! Balik na sa trabaho, team! 💪',
  lunch: 'Busog na! Balik na tayo sa trabaho, team! 💪',
  dinner: 'Salamat sa hapunan! Tapusin na natin ang shift, team! 💪',
};

const IT_LINES = [
  'Mino-monitor ko ang uptime ng servers… 🖥️',
  'Nagba-backup ng database, 100% ligtas! 💾',
  'Tinitingnan ko ang temperatura ng server rack ❄️',
  'Walang downtime ngayon, panalo! ✅',
  'Ina-update ko ang firewall rules 🔒',
  'Chine-check ko ang network cables at switch 🔌',
  'Mabilis ang ping ngayon! ⚡',
  'Nag-restart ako ng isang lumang service 🔄',
  'Walang kahina-hinalang login ✅',
  'Nililinis ko ang lumang logs 🧹',
  'Malamig ang server room, ayos! ❄️',
  'Na-patch ko na ang security update 🛡️',
  'Sapat pa ang storage natin 💽',
  'Lahat ng backup ay verified ✔️',
  'May bagong ticket? Wala pa naman 🎫',
  'Nilalagyan ko ng label ang mga cable 🏷️',
  'Sinusubukan ko ang bagong WiFi channel 📶',
  'Ang linis ng cable management ko 😎',
  'Ina-update ko ang inventory ng spare parts 🧰',
  'Sapat pa ang bandwidth natin 🌐',
];
const ARCADE_CALL = [
  'Boss, medyo pagod na ang team. Arcade break muna? 🕹️',
  'Boss, may arcade room po tayo — pampa-relax ng utak! 🎮',
  'Boss, 10 minutos lang sa arcade? 🎯',
  'Boss, pwede po bang mag-game break? 🎮',
];
const ARCADE_BOSS = ['Sige, 15 minutos lang! Relax muna, team! 🎮', 'Magandang idea, Mira. Mag-arcade tayo sandali! 🕹️', 'Go! Pero ako ang mananalo! 😎', 'Sige na nga, kaunting laro! 🕹️'];
const ARCADE_SPARKS = ['Player 1 ready! 🎮', 'Game na! Beat my high score! 🏆', 'Una ako sa racing game! 🏎️', 'Fighting game tayo! 🥊', 'Sisirain ko ang record ni Boss! 😎', 'Insert coin… 🪙', 'Ako sa claw machine! 🧸', 'Pinball naman tayo! 🔵', 'Dance game, sino sasabay? 💃', 'Ready na ang joystick ko! 🕹️'];
const ARCADE_WIN = ['Level up! ⭐', 'Combo! 🔥', 'New high score! 🏆', 'GG! 🎉', 'Konting tapik na lang, boss level na! 👾', 'Game over… isa pa nga! 😆', 'Perfect run! 💯', 'Sayang, ang lapit na! 😅', 'Nakuha ko ang bonus! 🎁', 'Triple combo! ⚡'];

/** Mga linya ni Argus habang nagbabantay (galing sa totoong trabaho niya: 5-minutong scan ng post/comment at pagpapaalala sa Telegram/Discord). */
const ARGUS_LINES = [
  'Ini-scan ko ang lahat ng post at comment 👁️', 'Walang nakakalusot sa akin! 🐕', 'May comment na hindi pa nasasagot… chine-check ko 🔎',
  'Kada 5 minuto, ikot ulit ako ⏱️', 'Wala pang na-miss ngayon, ayos! ✅', 'Naka-standby ang Telegram reminder ko 📨',
  'Kapag may na-miss, kukulitin ko ang team 😤', 'Binabantayan ko ang mentions sa X 🐦', 'Tingnan natin ang CCTV ng buong office 📹',
  'Hindi ako natutulog, 24/7 ako 🌙', 'May nakita akong post na walang reply 👀', 'Aayusin muna bago ko tigilan ang pagkulit 😏',
  'Lahat ng comment, may sagot dapat! 💬', 'Naka-alerto ang mga mata ko, lahat sila! 👀👀👀', 'Nagpaalala na ako sa group chat 🔔',
];

/** Ulat ni Argus kapag sumama siya sa meeting (galing sa totoong trabaho niya: pagbabantay ng missed posts at comments). */
const ARGUS_MEETING = [
  'Ulat ng Watchdog: wala akong nakitang na-miss na post ngayon ✅', 'May ilang comment na binabantayan ko pa, Boss. Aayusin natin 🔎',
  'Sumama ako sa meeting pero nakatutok pa rin ang CCTV ko 👁️', 'Kapag may na-miss habang nag-uusap tayo, kukulitin ko kayo agad 😤',
  'Naka-ikot na ang huling 5-minutong scan, malinis! 🧹', 'Nandito ako para sa mga na-miss na item, Boss 📋',
];

/** Mga salita habang nagtatrabaho. Bawat empleyado ay may sariling linya + may mga pangkalahatang linya. */
const WORK_LINES: Record<MemberId, string[]> = {
  boss: ['Kumusta ang metrics ngayon? 📊', 'Magandang trabaho, team! 👏', 'Focus lang, malapit na ang target 🎯', 'Sino may bagong idea? 💡', 'Salamat sa sipag ninyo! 🙌', 'Tingnan ko ang report mamaya 📑', 'Ayos ang takbo ng araw! ☀️', 'Mira, ano ang schedule ko mamaya?', 'Maganda ang trend ngayong linggo 📈', 'Huwag kalimutang mag-hydrate, team! 💧', 'Pag-aaralan ko ang plano ng Shared Brain 🧠', 'Kailangan natin ng mas matapang na campaign!'],
  sec: ['Naka-schedule na ang meeting 📅', 'Inaayos ko ang mga tala 📝', 'Boss, may update po ako 🗂️', 'Nai-file ko na ang report ✅', 'Paalala: may coffee break mamaya ☕', 'Nasa kalendaryo na po 🗓️', 'Inaayos ko ang agenda 📋', 'Na-print ko na ang minutes 🖨️', 'May tatlong paalala para sa Boss 📌', 'Binubura ko ang mga lumang task ✔️', 'Na-confirm ko na ang lahat ng appointment 📞', 'Sinusulat ko ang buod ng linggo ✍️'],
  aria: ['Isa pang caption, tapos na! ✍️', 'Ang ganda ng hook na ito! 💫', 'Pino-polish ko ang copy ✨', 'Naghahanap ng tamang hashtag #️⃣', 'Tone check: hype o chill? 🤔', 'Draft #3, ayos na! 📝', 'Binabasa ko ulit ang headline 👀', 'Mas maikli, mas malakas ang dating! ✂️', 'May bagong emoji na bagay sa post 😎', 'Nire-rewrite ko ang unang linya', 'Ang tagal ko sa isang salita lang 😅', 'Idadagdag ko ang call-to-action 📣'],
  blaze: ['Naka-queue na ang susunod 🚀', 'Chine-check ko ang oras ng post ⏱️', 'Naka-publish na! ✅', 'Ayos ang Discord feed 💬', 'Pila ay malinis 🧼', 'Next slot, 7PM! 🕖', 'Binabalanse ko ang oras ng mga post ⚖️', 'Walang nag-overlap na schedule 🗓️', 'Sinusubaybayan ko ang reach ng huling post', 'Telegram channel, ayos na rin! 📨', 'Naglilipat ako ng slot para hindi spam', 'Pina-pin ko ang pinakamagandang post 📌'],
  nova: ['May bagong player! 🎮', 'Nag-welcome na ako ng 3 👋', 'Maraming active ngayon 🔥', 'Nagre-reply na sila! 💬', 'Chine-check ko ang invite limit ✅', 'Ang bait ng community! 😊', 'May nag-thank you sa invite ko 🥰', 'Binabasa ko ang mga comment 🔎', 'May mga gamer sa racing group ngayon 🏎️', 'Nag-follow up ako sa isang player', 'Bagong thread sa Looking for Group! 🧵', 'Nag-shout out ako sa isang bagong member'],
  cipher: ['Rate limits ay normal ✅', 'Ligtas ang lahat 🔒', 'CTR tumataas! 📈', 'Walang ban-risk ngayon 🛡️', 'Report ay halos tapos na 📊', 'Tamang bilis lang tayo ⚖️', 'Ini-scan ko ang mga log 📜', 'Walang kahina-hinalang activity ✅', 'Naghahambing ako ng A at B 🔬', 'May spike sa clicks ngayong oras!', 'Ina-update ko ang weekly graph 📉', 'Naka-alarm ako kapag lumampas sa limit 🚨'],
  it: IT_LINES,
  argus: ARGUS_LINES,
};
/** Mga linyang pwedeng sabihin ng kahit sino habang nagtatrabaho (para hindi paulit-ulit ang bawat tao). */
const GENERIC_WORK = [
  'Focus mode on! 🎯', 'Konting stretch muna 🙆', 'Ang tahimik ngayon, ang sarap magtrabaho', 'Kailangan ko na ng kape ☕', 'Ang ganda ng takbo ng araw!', 'Malapit na ang break ✨',
  'Isa pang task, tapos na! ✅', 'Hmm, saan ko nga ba nilagay yun? 🤔', 'Ang bilis ng oras ⏰', 'Tuloy lang, kaya natin ito! 💪', 'May bago akong natutunan ngayon 💡', 'Nakakatuwa ang team natin 😊',
];
const WORK_POOL = Object.fromEntries(
  (Object.keys(WORK_LINES) as MemberId[]).map((k) => [k, [...WORK_LINES[k], ...GENERIC_WORK]]),
) as Record<MemberId, string[]>;

/** Tanungan sa pagitan ng dalawang empleyado: bawat tanong ay may kaukulang sagot (hindi random na sagot). */
const CHATS: { ask: string; reply: string[] }[] = [
  { ask: 'Kumusta ang trabaho?', reply: ['Ayos lang, steady! 👍', 'Medyo busy pero kaya naman 💪', 'Halos tapos na ang task ko!'] },
  { ask: 'Kape tayo mamaya? ☕', reply: ['Sige, libre mo ha! 😄', 'Game! Pagkatapos ng task na ito.', 'Oo naman, kailangan ko na ng caffeine!'] },
  { ask: 'Ano ulam mamaya? 🍽️', reply: ['Adobo daw! 😋', 'Sabi ni Mira, sinigang ata.', 'Wala pang balita, sana lechon kawali 🤤'] },
  { ask: 'Sino may extra charger? 🔌', reply: ['Meron ako dito! 🔌', 'Type-C lang ang meron ako.', 'Kay Dex ka manghiram, marami siya niyan!'] },
  { ask: 'Nakita mo ba ang report?', reply: ['Oo, ang ganda ng numbers!', 'Hindi pa, ipasa mo nga please 🙏', 'Nasa shared folder na po.'] },
  { ask: 'Handa ka na sa meeting?', reply: ['Handa na, tara! 💪', 'Konting minuto na lang, may tinatapos pa.', 'Hala, may meeting ba? Salamat sa paalala! 😅'] },
  { ask: 'Kamusta ang pila ng posts?', reply: ['Malinis ang pila!', 'May tatlong naka-queue pa.', 'Naka-schedule na lahat ✅'] },
  { ask: 'Ang lamig ng aircon, ano?', reply: ['Oo nga, kailangan ko ng jacket 🧥', 'Ayos nga eh, antok-lamig 😴', 'Sabihan natin si Dex, baka sira ang thermostat.'] },
  { ask: 'Nakakaantok na, may kape pa?', reply: ['Meron sa bar, tara na! ☕', 'Maglakad-lakad muna tayo 🚶', 'Ako rin eh, pangatlong kape ko na.'] },
  { ask: 'Nakita mo ba ang bagong update?', reply: ['Oo! Ang daming improvement.', 'Hindi pa, anong bago?', 'Kakabasa ko lang, ayos!'] },
  { ask: 'Pwede mo ba akong tulungan saglit?', reply: ['Sige, ano yun?', 'Pagkatapos ko dito, promise!', 'Siyempre, ikaw pa ba 😊'] },
  { ask: 'Weekend na bukas, may plano ka?', reply: ['Pahinga at tulog lang 😴', 'Lalaro ako sa arcade! 🕹️', 'Kain sa labas, sama ka?'] },
  { ask: 'Ang bilis ng internet ngayon, no?', reply: ['Oo, salamat kay Dex! ⚡', 'Ngayon lang, kanina nag-lag.', 'Sana ganito palagi 🙏'] },
  { ask: 'Nag-backup ka na ba ng files?', reply: ['Oo, auto na kay Dex.', 'Ay, oo nga pala! Gagawin ko na.', 'Kahapon pa, safe tayo 💾'] },
  { ask: 'Anong oras uwian?', reply: ['Hindi umuuwi ang bot, 24/7 tayo 😂', 'Pagkatapos ng huling post.', 'Sana mamaya na 😩'] },
  { ask: 'Gusto mo ng pandesal?', reply: ['Oo naman! Salamat 🥖', 'Busog pa ako, mamaya na.', 'May palaman ba? 😋'] },
  { ask: 'Napansin mo ba ang CTR ngayon?', reply: ['Tumataas! 📈', 'Medyo bumaba, titingnan ko pa.', 'Steady lang, walang pagbabago.'] },
  { ask: 'Ano sa tingin mo ang bagong design?', reply: ['Malinis at maganda! ✨', 'Parang kulang sa kulay, pero okay.', 'Gusto ko! Bagay sa brand natin.'] },
  { ask: 'May deadline ba tayo ngayon?', reply: ['Wala naman, relax lang.', 'Meron, mamayang gabi pa.', 'Tanong mo kay Mira, siya ang may kalendaryo 📅'] },
  { ask: 'Pagod ka na ba?', reply: ['Konti lang, kaya pa! 💪', 'Medyo, arcade break tayo mamaya?', 'Hindi naman, bot ako eh 😆'] },
  { ask: 'Ano ang pinapakinggan mo habang nagtatrabaho?', reply: ['Lo-fi beats lang 🎧', 'Tahimik ako, mas focus.', 'OPM tayo palagi! 🎶'] },
  { ask: 'Uy, may bagong player sa community!', reply: ['Welcome siya! 🎮', 'Ayos, salamat Nova!', 'Sana active siya 😄'] },
  { ask: 'Na-save mo na ba ang draft?', reply: ['Oo, may dalawang backup pa.', 'Ay hindi pa pala! Salamat 😅', 'Auto-save naman eh ✅'] },
  { ask: 'Malakas ang ulan sa labas, no?', reply: ['Buti nasa loob tayo ☔', 'Sarap matulog nito 😴', 'Ayos lang, 24/7 pa rin ang servers.'] },
  { ask: 'Natikman mo na ba ang bagong kape?', reply: ['Oo, ang bango! ☕', 'Hindi pa, anong flavor?', 'Medyo matapang pero okay!'] },
  { ask: 'Pwede bang i-adjust ang schedule mamaya?', reply: ['Sige, ilipat natin ng 30 mins.', 'Medyo masikip, pero kaya.', 'Tanong muna natin si Mira 🗓️'] },
  { ask: 'Nakita mo ba si Dex?', reply: ['Nasa Server Room siguro 🖥️', 'May inaayos sa kabilang office.', 'Hindi pa, bakit may sira ba?'] },
  { ask: 'Anong bago sa Discord?', reply: ['Dumami ang active ngayong gabi 🌙', 'May bagong meme sa general 😂', 'Tahimik lang, wala masyado.'] },
];
/** Minsan, sumasagot ulit ang nagtanong (para hindi laging 2 linya lang ang usapan). */
const CHAT_FOLLOWUP = ['Salamat! 🙌', 'Noted! 👍', 'Sige, ayos!', 'Hehe, ikaw talaga 😄', 'Okay, balitaan mo ako.', 'Thanks, ha!', 'Sige, usap tayo ulit mamaya.', 'Ayos, magaan na ang loob ko 😌'];

/* ------------------------------------------------------------------ *
 * IT service round ni Dex: ayusin ang internet / computer sa bawat office
 * ------------------------------------------------------------------ */
const NET_COMPLAINT = [
  'Walang internet! Hindi mag-load ang mga page 📶', 'Ang bagal ng koneksyon ko, nag-bu-buffer lahat 🐢', 'Dex! Putol-putol ang WiFi ko!', 'Hindi ako maka-connect sa server, help! 🆘',
  'Nag-time out ang upload ko, Dex! ⏳', 'Nawala ang signal ng WiFi ko 😱', 'Ping ko 999 na, sobrang lag! 🐌', 'Hindi mag-sync ang Discord feed ko 💬',
];
const PC_COMPLAINT = [
  'Nag-freeze ang computer ko! 🥶', 'Biglang nag-blue screen, Dex! 💙', 'Ang init at ang ingay ng PC ko 🔥', 'Hindi nagbubukas ang app ko! 😵',
  'Ang bagal ng computer, nag-hang na naman 🐌', 'Ayaw mag-boot ng monitor ko!', 'Ayaw mag-type ng keyboard ko ⌨️', 'Puno na ang storage ko, nagka-error 💽',
];
/** Mga reklamong may kinalaman sa trabaho ng bawat empleyado. */
const ROLE_COMPLAINT: Record<TeamId, Record<TicketKind, string[]>> = {
  aria: { net: ['Hindi mag-load ang AI Studio ko, Dex! ✍️'], pc: ['Nag-crash ang editor ko, nawala ang draft! 😭'] },
  blaze: { net: ['Hindi maka-connect ang Discord at Telegram ko! 💬'], pc: ['Nag-freeze ang scheduler ko 🗓️'] },
  nova: { net: ['Ayaw mag-send ng invites ko, offline daw! 📡'], pc: ['Ang bagal ng radar scan sa computer ko 🔎'] },
  cipher: { net: ['Walang data sa analytics, naputol ang feed! 📊'], pc: ['Ang init ng PC ko habang nagko-compute ng reports 🔥'] },
  sec: { net: ['Hindi mag-sync ang kalendaryo ko, Dex! 📅'], pc: ['Nag-hang ang printer at ang laptop ko 🖨️'] },
  boss: { net: ['Dex, ayaw mag-load ng dashboard ko! 📊'], pc: ['Dex, bakit ang bagal ng computer ko? 😤'] },
};
const IT_COMING = [
  'Papunta na ako, hintayin mo ako diyan! 🏃', 'On the way na! 🛠️', 'May ticket ako, pupunta na! 🎫', 'Ako na bahala, saglit lang! 🧰',
  'Natanggap ko ang ticket, papunta na! 📲', 'Tatakbo na ako diyan! ⏱️', 'Sandali lang, kukunin ko ang toolbox 🧰',
];
const IT_ARRIVE: Record<TicketKind, string[]> = {
  net: ['Titingnan ko muna ang router mo… 📡', 'Chine-check ko ang cable at WiFi signal 🔌', 'Pa-ping muna natin ang server… 🛰️', 'Titingnan ko kung maluwag ang LAN cable 🔌', 'Ire-restart ko ang router…', 'Susubukan ko ang ibang channel ng WiFi 📶'],
  pc: ['Titingnan ko ang computer mo, saglit lang 🖥️', 'Buksan natin ang task manager…', 'Chine-check ko ang RAM at temperatura 🌡️', 'Titingnan ko kung may sirang driver…', 'Pa-reboot muna natin sa safe mode…', 'Lilinisin ko muna ang cooling fan 🌀'],
};
const IT_FIXING: Record<TicketKind, string[]> = {
  net: ['Pinapalitan ko ang ethernet cable 🔌', 'Nire-reset ang router… 📡', 'In-update ko ang network driver ⬆️', 'Inaayos ko ang DNS settings 🌐', 'Inayos ko ang IP conflict ⚙️', 'Nilipat ko sa mas malakas na channel 📶', 'Pinapalitan ko ang maluwag na RJ45 connector 🔧'],
  pc: ['Nililinis ko ang cache at temp files 🧹', 'Ina-update ko ang driver ⬆️', 'Nire-reinstall ko ang app 🔄', 'Nililinis ko ang disk para lumuwag 💽', 'Nilinis ko ang fan, nabara ng alikabok 🌀', 'Nire-reboot ko ang system ⚙️', 'Pinalitan ko ang cable ng monitor 🖥️'],
};
const IT_CAUSE: Record<TicketKind, string[]> = {
  net: ['maluwag lang pala ang cable', 'nag-overload ang router kanina', 'nag-conflict ang IP address', 'sobrang crowded ng WiFi channel', 'luma na ang network driver'],
  pc: ['puno na pala ang cache', 'nabara ng alikabok ang fan', 'sira ang lumang driver', 'may lumang process na nakabara', 'kulang na sa free storage'],
};
const IT_DONE = [
  'Ayos na! Subukan mo ngayon ✅', 'Tapos na, mabilis na ang takbo! ⚡', 'Naayos ko na, balik na sa trabaho! 💪', 'Fixed! Wala nang problema ✔️',
  'Ok na lahat, may log na ako nito 📝', 'Balik na sa normal, balitaan mo ako kung may problema ulit 👍',
];
const IT_CAUSE_INTRO = ['Ang sanhi:', 'Alam mo ba kung bakit?', 'Napansin ko lang:', 'Sa totoo lang,'];
const WAIT_LINES = ['Hintay lang ako dito… ⏳', 'Ang galing mo mag-ayos, Dex!', 'Sana ma-ayos agad 🤞', 'Nanonood lang ako, hehe 👀', 'Mamaya na lang ako bibitaw sa task ko 😅'];
const THANKS = ['Salamat, Dex! Ang bilis mo! 🙌', 'Panalo ka talaga, Dex! 🏆', 'Gumagana na! Maraming salamat! 😍', 'Wow, ang bilis! Thank you! 🙏', 'Ayos! Balik na ako sa trabaho 💪', 'Salamat po, Dex, ikaw na talaga! 👏', 'Dex, hero ka! 🦸'];
const IT_BYE = ['Sige, tawag lang ulit! 🎫', 'Next ticket na tayo! 🏃', 'Balik muna ako sa server room 🖥️', 'Doon naman ako sa susunod 🛠️', 'Kung may problema ulit, i-ticket mo lang! 🎫'];
const IT_FINISH = ['Tapos na ang round ko, balik na sa server room! 🖥️', 'Lahat ng ticket ay solved ✅ Monitor mode na ulit ako.', 'Wala nang pending na ticket 🎉', 'Okay na ang network ng buong office! 📶'];
const IT_NO_ONE = ['Walang ticket ngayon, pahinga muna ako 😌', 'Wala pang nagrereklamo, ayos! ✅'];

const pick = <T,>(arr: T[]): T => pickFresh(arr);
const rand = (min: number, max: number) => min + Math.random() * (max - min);
const shuffle = <T,>(arr: T[]): T[] => [...arr].sort(() => Math.random() - 0.5);

/* ------------------------------------------------------------------ *
 * Energy at routine ng mga AI employee (parang totoong tao)
 * Nauubos ang energy habang nagtatrabaho → kapag mababa na, kusang pipili (random, hindi pareho sa huli)
 * ng kape ☕, laro sa arcade 🎮 o idlip sa sofa 😴 → kapag puno na ulit ang energy, balik trabaho.
 * ------------------------------------------------------------------ */
export type Doing = 'work' | 'coffee' | 'game' | 'rest';
export interface Routine { energy: number; doing: Doing }
/** Energy at ginagawa ni Argus (may dagdag na "kain"; nasa desk lang niya ang kape/laro/kain, ang idlip ay sa sofa ng HQ niya). */
export interface BreakRoutine { energy: number; doing: ReelDoing }
/**
 * HINDI kasama sa pangunahing energy system: si Boss (Code Solo), Ms. Mira, Dex at Argus.
 * (Ang energy at routine ng hasEnergy ay para lang sa mga AI employee sa AGENTS: Aria, Blaze, Nova, Cipher.)
 * Si Argus ay may sarili pa ring rotation (kape, laro, idlip, kain) sa ibaba; hiwalay ito dahil hindi siya AgentId.
 */
export const NO_ENERGY_MEMBERS: readonly MemberId[] = ['boss', 'sec', 'it', 'argus'];
export const hasEnergy = (id: MemberId): id is AgentId => !NO_ENERGY_MEMBERS.includes(id);
const BREAK_PLACE: Record<Exclude<Doing, 'work'>, Place> = { coffee: 'bar', game: 'play', rest: 'rest' };
/** Ddagdag na energy kada segundo habang nagpapahinga (ang idlip ang pinakamabisa, ang laro ang pinakamabagal pero masaya). */
const RECOVER: Record<Exclude<Doing, 'work'>, number> = { coffee: 1.9, game: 1.4, rest: 2.3 };
const MIN_BREAK_MS: Record<Exclude<Doing, 'work'>, number> = { coffee: 22000, game: 28000, rest: 32000 };
const MAX_AWAY = 2; // hindi hihigit sa dalawang bot ang sabay na nagbe-break, para hindi mawalan ng tao ang office
const BREAK_GO: Record<Exclude<Doing, 'work'>, string[]> = {
  coffee: ['Naubos na ang energy ko… kape muna! ☕', 'Kailangan ko ng caffeine, saglit lang ☕', 'Antok na ako, kape muna sa mini bar ☕'],
  game: ['Pagod na ang utak ko, laro muna sandali! 🎮', 'Break time! Arcade muna ako 🕹️', 'Mag-recharge muna ako sa games 🎮'],
  rest: ['Pagod na ako… idlip muna sa sofa 😴', 'Hihiga muna ako sandali 🛋️', 'Pahinga muna, saglit lang! 💤'],
};
const BREAK_MID: Record<Exclude<Doing, 'work'>, string[]> = {
  coffee: ['Ang sarap ng kape! ☕', 'Unti-unti nang bumabalik ang lakas ko', 'Isa pang higop 😌'],
  game: ['Level up! ⭐', 'Isa pang round! 🔥', 'Ang saya, gumaganda ang mood ko 😄'],
  rest: ['Zzz… 💤', 'Zzz… zzz… 😴', 'Zzz… 💤💤'],
};
const BREAK_BACK = ['Recharged na! Balik trabaho 💪', 'Fully charged na ako! ⚡', 'Ayos na, tuloy ang trabaho! 🚀', 'Ang gaan na ng pakiramdam, balik na ako! ✨'];
const LOW_ENERGY = ['Medyo pagod na ako… 🥱', 'Humihina na ang energy ko 🔋', 'Kailangan ko na ng break soon 😮‍💨'];

interface RoutineState { energy: number; drain: number; floor: number; doing: Doing; last: Doing | null; start: number; mid: boolean; warned: boolean }
const rollDrain = () => rand(0.45, 0.9); // energy na nawawala kada segundo (iba-iba bawat tao at bawat ikot)
const rollFloor = () => rand(20, 36); // sa anong energy siya hihinto at magbe-break
function initRoutine(): Record<AgentId, RoutineState> {
  const o = {} as Record<AgentId, RoutineState>;
  AGENTS.forEach((a) => { o[a.id] = { energy: rand(55, 100), drain: rollDrain(), floor: rollFloor(), doing: 'work', last: null, start: 0, mid: false, warned: false }; });
  return o;
}
function pickBreak(s: RoutineState): Exclude<Doing, 'work'> {
  // shuffle na may bigat; hindi pareho sa huling ginawa; kapag sobrang baba ng energy, mas malamang na idlip
  const w: Record<Exclude<Doing, 'work'>, number> = { coffee: 3, game: 2, rest: s.energy < 14 ? 6 : 2.5 };
  const kinds = (Object.keys(w) as Exclude<Doing, 'work'>[]).filter((k) => k !== s.last);
  let r = Math.random() * kinds.reduce((n, k) => n + w[k], 0);
  for (const k of kinds) { r -= w[k]; if (r <= 0) return k; }
  return kinds[0];
}

/* ------------------------------------------------------------------ *
 * Utos ni Boss: "Kausapin si Boss" (tawag = meeting kasama ang team, mensahe = babasahin niya sa desk)
 * ------------------------------------------------------------------ */
export interface BossCmd {
  id: string;
  text: string;
  mode: CommandMode;
  /** true = na-save na sa Shared Brain (mababasa na ng totoong bots) */
  applied: boolean;
  /** true = sa browser lang na-save (walang Supabase), hindi pa mababasa ng totoong bots */
  local?: boolean;
  /** dahilan kung hindi na-apply */
  error?: string;
}
export type CmdStep = 'queued' | 'active' | 'done';
const CMD_ACK: Record<AgentId, string[]> = {
  aria: ['Sige, Boss! Isasama ko ito sa susunod kong caption. ✍️', 'Copy, Boss! Susundin ko ito sa bawat draft. ✍️'],
  blaze: ['Copy, Boss! Susundin ko ito sa pag-publish. 🚀', 'Naintindihan, Boss! Kasama na ito sa schedule ko. 🗓️'],
  nova: ['Naintindihan, Boss! Gagamitin ko ito sa mga invite at reply. 📡', 'Sige, Boss! Ilalapat ko ito sa community. 💬'],
  cipher: ['Noted, Boss! Babantayan ko kung nasusunod ng lahat. 🛡️', 'Naka-record, Boss. Susubaybayan ko ang epekto. 📈'],
};
const CMD_DEX = ['Naka-sync na sa server, Boss. 🖥️', 'Na-update ko na ang server, Boss! ✅'];
const CMD_ARGUS = ['Babantayan ko rin po ito, Boss. 👁️', 'Naka-bantay na ako sa utos na iyan. 👁️'];

/* ------------------------------------------------------------------ *
 * Simulation hook
 * ------------------------------------------------------------------ */
const ALL_OFFICE: Record<MemberId, Place> = { boss: 'office', sec: 'office', aria: 'office', blaze: 'office', nova: 'office', cipher: 'office', it: 'office', argus: 'office' };

const TOPIC: Record<AgentId, string> = {
  aria: 'content',
  blaze: 'scheduling',
  nova: 'invites at growth',
  cipher: 'safety at reports',
};
const SPARKS = ['May maganda akong idea! 💡', 'Eureka! Ilalagay ko sa Shared Brain! ✨', 'Sandali, may naisip akong magandang idea! 💡', 'Aha! Isusulat ko ito sa hologram! ✍️', 'Boom! May bago akong plano! 🚀', 'Teka lang, may pumasok sa isip ko! 🧠'];
const nameOf = (id: string) => AGENTS.find((a) => a.id === id)?.name ?? id;
const memberName = (id: MemberId): string => (id === 'boss' ? BOSS.name : id === 'sec' ? SECRETARY.name : id === 'it' ? IT_STAFF.name : id === 'argus' ? ARGUS.name : nameOf(id));
/** Tantiyang oras (ms) ng paglalakad ni Dex sa pagitan ng dalawang pwesto (kasama ang mga hallway). */
function walkMs(a: XY, b: XY): number {
  const units = Math.abs(a.x - b.x) * 0.8 + Math.abs(a.y - b.y) * 0.52 + 6;
  return Math.round((units / 11) * 1000 * 1.25) + 800;
}

export function useOfficeSim(paused: Record<string, boolean>) {
  const [places, setPlaces] = useState<Record<MemberId, Place>>(ALL_OFFICE);
  const [speech, setSpeech] = useState<Partial<Record<MemberId, string>>>({});
  const [phase, setPhase] = useState<Phase>('work');
  const [ideas, setIdeas] = useState<Idea[]>([]);
  /** mga idea na nasa Shared Brain pa at hindi pa nababasa ng secretary */
  const [inbox, setInbox] = useState<Idea[]>([]);
  /** buod ng secretary para sa boss */
  const [report, setReport] = useState<IdeaReport | null>(null);
  /** aling kainan ang kasalukuyang nagaganap (null kapag hindi kainan) */
  const [meal, setMeal] = useState<Meal | null>(null);
  /** kaninong office pumupunta si Dex (null kapag nasa Server Room siya) */
  const [itTarget, setItTarget] = useState<TeamId | null>(null);
  /** sino ang may sira ang internet/computer ngayon (pula ang monitor niya hanggang maayos) */
  const [broken, setBroken] = useState<TeamId | null>(null);
  /** Boss kausap si Reel / Fixo (wala sila sa MemberId): bubble sa 3D office */
  const [callout, setCallout] = useState<{ who: 'reel' | 'fixo'; text: string; n: number } | null>(null);
  /** mga huling IT ticket na inayos ni Dex */
  const [tickets, setTickets] = useState<Ticket[]>([]);
  const pausedRef = useRef(paused);
  pausedRef.current = paused;
  const speechRef = useRef<Partial<Record<MemberId, string>>>({});
  speechRef.current = speech;
  const phaseRef = useRef<Phase>('work');
  phaseRef.current = phase;
  const placesRef = useRef(places);
  placesRef.current = places;
  /** energy at ginagawa ng bawat AI employee (para sa energy bar sa name tag) */
  const [routine, setRoutine] = useState<Record<AgentId, Routine>>(() => {
    const o = {} as Record<AgentId, Routine>;
    AGENTS.forEach((a) => { o[a.id] = { energy: 100, doing: 'work' }; });
    return o;
  });
  /** energy at ginagawa ni Argus (Watchdog) */
  const [argusRoutine, setArgusRoutine] = useState<BreakRoutine>({ energy: 100, doing: 'work' });
  const queue = useRef<'brainstorm' | 'coffee' | 'meal' | 'arcade' | 'service' | null>(null);
  /** mga utos ni Boss na naghihintay (isa-isang ipapatupad ng simulation) */
  const cmdRef = useRef<BossCmd[]>([]);
  /** kalagayan ng bawat utos (naka-pila / ginagawa / tapos) para sa panel */
  const [cmdSteps, setCmdSteps] = useState<Record<string, CmdStep>>({});
  /** nagsasalita si Boss sa 3D office habang nakikipag-chat sa kanya (live na sagot) */
  const bossHold = useRef(0); // hanggang kailan hindi dapat sapawan ng random na chatter ang sinasabi ni Boss
  const bossSay = useCallback((text: string, ms = 5200) => {
    bossHold.current = Date.now() + ms + 1200;
    setSpeech((p) => ({ ...p, boss: text }));
    window.setTimeout(() => {
      setSpeech((p) => {
        if (p.boss !== text) return p;
        const n = { ...p };
        delete n.boss;
        return n;
      });
    }, ms);
  }, []);
  const sendCommand = useCallback((c: BossCmd) => {
    cmdRef.current.push(c);
    setCmdSteps((p) => ({ ...p, [c.id]: 'queued' }));
  }, []);

  /** mga gagawin ni Boss pagkatapos ng tawag (meeting, kausapin ang mga tao) */
  // nakatago sa localStorage (pendingPlans): hindi nawawala kung nag-unmount ang office bago ito natapos
  const runAfterCall = useCallback((plan: AfterCallPlan) => {
    queuePlan(plan);
  }, []);

  const trigger = useCallback((kind: 'brainstorm' | 'coffee' | 'meal' | 'arcade' | 'service') => {
    queue.current = kind;
  }, []);

  useEffect(() => {
    const token = { stop: false };
    setPlaces(ALL_OFFICE);
    setSpeech({});
    setPhase('work');
    setInbox([]);
    setReport(null);
    setMeal(null);
    setItTarget(null);
    setBroken(null);

    const sleep = (ms: number) => new Promise<void>((res) => window.setTimeout(res, ms));
    const say = async (id: MemberId, text: string, ms = 3200) => {
      if (token.stop) return;
      setSpeech((p) => ({ ...p, [id]: text }));
      await sleep(ms);
      if (token.stop) return;
      setSpeech((p) => {
        if (p[id] !== text) return p;
        const n = { ...p };
        delete n[id];
        return n;
      });
    };
    const team = () => AGENTS.map((a) => a.id).filter((id) => !pausedRef.current[id]);
    const moveAll = (ids: MemberId[], place: Place) =>
      setPlaces((p) => {
        const n = { ...p };
        ids.forEach((i) => (n[i] = place));
        return n;
      });

    /**
     * Idea pipeline:
     * 1. may magagandang idea ang ilang empleyado → ilalagay sa hologram ng Shared Brain
     * 2. binabasa at sinusummarize ng secretary ang mga idea
     * 3. ipinapaalam ng secretary sa boss ang buod
     * 4. nagpapatawag ng meeting ang secretary → pinag-uusapan ang mga plano
     */
    const brainstorm = async () => {
      const members = team();
      setPhase('ideas');
      setReport(null);
      setInbox([]);
      if (members.length === 0) {
        await say('sec', 'Walang aktibong agent ngayon, Boss. Sa susunod na lang po ang meeting. 🗂️', 3000);
        setPhase('work');
        return;
      }

      // 1) mga empleyadong may magandang idea → Shared Brain
      const contributors = shuffle(members).slice(0, Math.min(members.length, 2 + Math.floor(Math.random() * 3)));
      await Promise.all(contributors.map((id) => say(id, pick(SPARKS), 2000)));
      if (token.stop) return;
      moveAll(contributors, 'drop');
      await sleep(4800);
      const proposed: Idea[] = [];
      const lessons = await fetchLessons();
      for (const id of contributors) {
        if (token.stop) return;
        // may totoong natutunan ba na bagay sa bot na ito? (kung wala, kathang-isip na idea na lang)
        let li = lessons.findIndex((l) => LESSON_BOT[l.category] === id);
        if (li < 0 && lessons.length) li = 0;
        const lesson = li >= 0 ? lessons.splice(li, 1)[0] : undefined;
        const text = lesson ? `📚 ${lesson.title}` : pick(IDEAS[id]);
        const idea: Idea = { id: `${Date.now()}-${id}`, by: id, text, verdict: lesson ? 'Naka-save na sa Shared Brain ✅' : pick(VERDICTS), at: Date.now(), real: Boolean(lesson) };
        proposed.push(idea);
        setInbox((prev) => [...prev, idea]);
        await say(id, text, 3400);
      }
      if (token.stop) return;
      moveAll(contributors, 'office');

      // 2) binabasa at sinusummarize ng secretary
      await say('sec', 'May mga bagong idea sa Shared Brain. Babasahin ko po. 📖', 2400);
      if (token.stop) return;
      moveAll(['sec'], 'drop');
      await sleep(4800);
      await say('sec', 'Binabasa ko ang mga idea sa hologram… 📖', 3000);
      const parts = proposed.map((i) => `${nameOf(i.by)} (${TOPIC[i.by]})`);
      const summary = `Buod: ${proposed.length} idea — ${parts.join(', ')}.`;
      await say('sec', summary, 4200);
      if (token.stop) return;
      setReport({ summary, count: proposed.length, at: Date.now() });
      setInbox([]);

      // 3) ipinapaalam sa boss
      moveAll(['sec'], 'brief');
      await sleep(4800);
      await say('sec', `Boss, ${proposed.length} magagandang idea po mula sa team. ${parts.join(', ')}.`, 5200);
      await say('boss', 'Magaling, Mira! Ipatawag mo ang meeting para mapag-usapan natin ang plano. 📣', 3400);

      // 4) nagpapatawag ng meeting ang secretary
      await say('sec', 'Opo, Boss! Team, may meeting po sa Shared Brain — ngayon na! 📅', 2800);
      if (token.stop) return;
      setPhase('meeting');
      const everyone: MemberId[] = ['boss', 'sec', ...members, 'argus'];
      moveAll(everyone, 'lab');
      await sleep(4800);
      await say('boss', 'Simulan na natin. Mira, paki-note ang mga plano. 📝', 2600);
      if (Math.random() < 0.6) await say('argus', pick(ARGUS_MEETING), 3400);
      for (const i of proposed) {
        if (token.stop) return;
        await say(i.by, i.text, 3600);
        const others = (['boss', 'argus', ...members] as MemberId[]).filter((m) => m !== i.by);
        await say(pick(others), pick(REACTIONS), 1700);
      }
      if (token.stop) return;
      await say('boss', `Napakagandang session! ${proposed.length} idea${proposed.length > 1 ? 's' : ''} ang aprubado ko. ✅`, 3200);
      await say('sec', 'Naitala ko na po ang plano at i-schedule ko ang follow-up. 🗓️', 3000);
      setIdeas((prev) => [...[...proposed].reverse(), ...prev].slice(0, 12));
      proposed.filter((i) => !i.real).forEach((i) => void db.log('success', 'team', `Shared Brain: ${i.by} proposed \"${i.text}\" — summarized by ${SECRETARY.name}, approved by ${BOSS.name}`).catch(() => undefined));
      await say('boss', 'Balik na sa kanya-kanyang office, team! 👏', 2200);
      moveAll(everyone, 'office');
      await sleep(4800);
      setPhase('work');
    };

    const coffee = async () => {
      const members = team();
      setPhase('coffee');
      await say('sec', 'Coffee break na po, Boss at team! ☕ Naka-schedule na.', 2400);
      const all: MemberId[] = ['boss', 'sec', ...members];
      moveAll(all, 'bar');
      await sleep(4800);
      for (let round = 0; round < 4; round++) {
        if (token.stop) return;
        const speaker = pick(all);
        await say(speaker, pick(JOKES), 3800);
        await say(pick(all.filter((m) => m !== speaker)), pick(LAUGHS), 1600);
      }
      await say('boss', 'Okay, relax na! Balik na tayo sa trabaho! 💪', 2200);
      moveAll(all, 'office');
      await sleep(4800);
      setPhase('work');
    };

    /**
     * Kainan (almusal / tanghalian / hapunan):
     * 1. ibinabalita ng secretary kay boss na oras na ng kain
     * 2. lahat (kasama si Dex ng IT) ay pupunta sa Canteen at uupo
     * 3. kumakain at nagkukwentuhan
     * 4. bumabalik sa kanya-kanyang pwesto
     */
    const eat = async (kind: Meal) => {
      const members = team();
      const info = MEAL_INFO[kind];
      setPhase('meal');
      setMeal(kind);
      markMealDone(new Date(), kind);
      await say('sec', MEAL_CALL[kind], 3600);
      if (token.stop) return;
      await say('boss', MEAL_BOSS[kind], 3000);
      if (token.stop) return;
      const everyone: MemberId[] = ['boss', 'sec', ...members, 'it'];
      void say('argus', 'Ako muna ang magbabantay habang kumakain kayo 👁️', 3200);
      await say('it', `Naka-auto ang servers, kain muna ako! ${info.emoji}`, 1800);
      moveAll(everyone, 'dine');
      await sleep(8400);
      for (let round = 0; round < 4; round++) {
        if (token.stop) return;
        const speaker = pick(everyone);
        await say(speaker, round < 2 ? pick(MEAL_DISHES[kind]) : pick(MEAL_TALK[kind]), 3800);
        const other = pick(everyone.filter((m) => m !== speaker));
        await say(other, pick(round < 2 ? FOOD_REPLY : LAUGHS), 1700);
      }
      if (token.stop) return;
      await say('boss', MEAL_THANKS[kind], 2800);
      void db.log('info', 'team', `${info.label}: kumain ang buong team sa Canteen (${info.time})`).catch(() => undefined);
      moveAll(everyone, 'office');
      await sleep(8400);
      setMeal(null);
      setPhase('work');
    };

    /**
     * Arcade break: ang ilang empleyado (minsan kasama ang boss, si Mira at si Dex) ay nagre-relax sa Arcade room.
     */
    const arcade = async () => {
      const members = team();
      setPhase('arcade');
      await say('sec', pick(ARCADE_CALL), 3200);
      await say('boss', pick(ARCADE_BOSS), 2800);
      if (token.stop) return;
      const pool: MemberId[] = shuffle<MemberId>(['boss', 'sec', ...members, 'it']);
      const players = pool.slice(0, Math.min(pool.length, 4 + Math.floor(Math.random() * 3)));
      moveAll(players, 'play');
      void say('argus', 'Naka-duty pa rin ako, enjoy kayo! 🕹️', 3000);
      await sleep(7600);
      for (let round = 0; round < 4; round++) {
        if (token.stop) return;
        const a = pick(players);
        await say(a, round === 0 ? pick(ARCADE_SPARKS) : pick(ARCADE_WIN), 2800);
        const b = pick(players.filter((m) => m !== a));
        await say(b, pick(round % 2 ? LAUGHS : ARCADE_SPARKS), 2000);
      }
      if (token.stop) return;
      await say('boss', 'Okay, relax na ang utak! Balik na tayo sa trabaho! 💪', 2400);
      moveAll(players, 'office');
      await sleep(7600);
      setPhase('work');
    };

    /**
     * IT service round: nagre-reklamo ang empleyado (internet o computer) → pumupunta si Dex sa office niya →
     * sinusuri at inaayos → nagpapasalamat ang empleyado → susunod na office. Random ang problema, sanhi at usapan.
     * all = true: bawat empleyado (manual na button); false: random na ilan lang (awtomatiko).
     */
    const service = async (all: boolean) => {
      const staff: TeamId[] = [...team(), 'sec', 'boss'];
      let targets = shuffle(staff);
      if (!all) targets = targets.slice(0, Math.min(targets.length, 3 + Math.floor(Math.random() * 2)));
      setPhase('service');
      if (targets.length === 0) {
        await say('it', pick(IT_NO_ONE), 2600);
        setPhase('work');
        return;
      }
      let dexAt: XY = spotFor('it', 'office');
      let mixed = Math.random() < 0.5;
      for (const who of targets) {
        if (token.stop) return;
        // salitan ang internet at computer para hindi laging pareho ang problema
        mixed = !mixed;
        const kind: TicketKind = Math.random() < 0.8 ? (mixed ? 'net' : 'pc') : mixed ? 'pc' : 'net';
        const complaint = Math.random() < 0.4 ? pick(ROLE_COMPLAINT[who][kind]) : pick(kind === 'net' ? NET_COMPLAINT : PC_COMPLAINT);
        const cause = pick(IT_CAUSE[kind]);

        // 1) nagre-reklamo ang empleyado, sumasagot si Dex
        setBroken(who);
        await say(who, complaint, 3400);
        if (token.stop) return;
        await say('it', pick(IT_COMING), 2200);
        if (token.stop) return;

        // 2) naglalakad si Dex papunta sa office ng empleyado
        setItTarget(who);
        moveAll(['it'], 'fix');
        const there = spotFor(who, 'office');
        await sleep(walkMs(dexAt, there));
        dexAt = there;
        if (token.stop) return;

        // 3) sinusuri at inaayos
        await say('it', pick(IT_ARRIVE[kind]), 2800);
        if (token.stop) return;
        const fixLines = 1 + Math.floor(Math.random() * 2);
        for (let i = 0; i < fixLines; i++) {
          await say('it', pick(IT_FIXING[kind]), 2800);
          if (token.stop) return;
          if (i === 0 && Math.random() < 0.5) await say(who, pick(WAIT_LINES), 2200);
          if (token.stop) return;
        }

        // 4) tapos na
        setBroken(null);
        await say('it', pick(IT_DONE), 2600);
        if (Math.random() < 0.55) {
          await say('it', `${pick(IT_CAUSE_INTRO)} ${cause}. 🔍`, 3000);
        }
        if (token.stop) return;
        await say(who, pick(THANKS), 2400);
        const ticket: Ticket = { id: `${Date.now()}-${who}`, who, kind, issue: complaint, cause, at: Date.now() };
        setTickets((prev) => [ticket, ...prev].slice(0, 8));
        void db.log('success', 'team', `IT Support: inayos ni ${IT_STAFF.name} ang ${kind === 'net' ? 'internet' : 'computer'} ni ${memberName(who)} (sanhi: ${cause})`).catch(() => undefined);
        if (Math.random() < 0.4) await say('it', pick(IT_BYE), 2200);
      }
      if (token.stop) return;

      // 5) balik sa Server Room
      moveAll(['it'], 'office');
      setItTarget(null);
      await sleep(walkMs(dexAt, spotFor('it', 'office')));
      await say('it', pick(IT_FINISH), 3000);
      setPhase('work');
    };

    /**
     * Utos ni Boss:
     * tawag    → ipinapatawag ni Mira ang team sa meeting table, inaanunsyo ni Boss, sumasagot ang bawat isa
     * mensahe  → binabasa ni Boss sa desk niya, inaanunsyo sa team, sumasagot sila mula sa kanya-kanyang desk
     * Kapag hindi na-save sa Shared Brain (applied = false), sinasabi ito ni Mira nang totoo at hindi sumasagot na "sinusunod" ang team.
     */
    const runCommand = async (c: BossCmd) => {
      const members = team();
      const sleeping = AGENTS.filter((a) => pausedRef.current[a.id]).map((a) => a.name);
      const short = c.text.length > 90 ? `${c.text.slice(0, 87)}…` : c.text;
      const everyone: MemberId[] = ['boss', 'sec', ...members, 'argus'];
      setCmdSteps((p) => ({ ...p, [c.id]: 'active' }));
      if (c.mode === 'call') {
        setPhase('meeting');
        await say('boss', 'Mira, ipatawag mo ang buong team — may bago akong utos! 📣', 3000);
        if (token.stop) return;
        await say('sec', 'Opo, Boss! Team, may meeting po sa Shared Brain — ngayon na! 📅', 2800);
        if (token.stop) return;
        moveAll(everyone, 'lab');
        await sleep(4800);
      } else {
        await say('boss', 'May dumating na mensahe… babasahin ko. 📩', 2600);
      }
      if (token.stop) return;
      await say('boss', `Bagong utos: “${short}”`, 5600);
      if (token.stop) return;
      if (c.applied) {
        await say('sec', c.local
          ? 'Naitala ko po sa simulation ng office (sa browser na ito lang). Para masunod ng totoong bots, kailangan ng Supabase. 🗂️'
          : 'Naitala ko na po sa Shared Brain at naka-broadcast na sa lahat ng bot. 🗂️', 3600);
        if (sleeping.length) await say('sec', `Naka-pause si ${sleeping.join(', ')} — malalaman nila ito kapag nag-resume sila.`, 3400);
        for (const id of members) {
          if (token.stop) return;
          await say(id, pick(CMD_ACK[id]), 3000);
        }
        if (token.stop) return;
        await say('it', pick(CMD_DEX), 2400);
        await say('argus', pick(CMD_ARGUS), 2400);
        if (token.stop) return;
        await say('boss', 'Salamat, team! Ipatupad na natin. 💪', 2600);
        void db.log('success', 'team', `Boss command (${c.mode === 'call' ? 'tawag' : 'mensahe'}): "${short}" — ${c.local ? 'naka-save sa browser (local)' : 'naka-save sa Shared Brain'}`).catch(() => undefined);
      } else {
        await say('sec', 'Boss, hindi po ito na-save sa server — hindi pa ito masusunod ng totoong bots. ⚠️', 3600);
        await say('boss', 'Ayusin natin ang koneksyon, tapos ulitin mo ang utos. 🔧', 2800);
        void db.log('warning', 'team', `Boss command HINDI na-save: ${c.error ?? 'unknown'}`).catch(() => undefined);
      }
      if (c.mode === 'call') {
        moveAll(everyone, 'office');
        await sleep(4800);
        setPhase('work');
      }
      setCmdSteps((p) => ({ ...p, [c.id]: 'done' }));
    };

    /**
     * Pagkatapos ng tawag: ginagawa ni Boss ang sinabi ng owner.
     * kausapin → lumalapit siya sa bawat tao at sumasagot ito; meeting → ipinapatawag ni Mira ang team sa meeting table.
     * Sina Reel at Fixo ay hindi miyembro ng sim: sumasagot sila sa pamamagitan ng bubble sa ulo nila sa 3D office.
     */
    const AFTER_REPLY: Record<PersonKey, string[]> = {
      aria: ['Opo, Boss! Nakikinig po ako. ✍️', 'Handa na po ako, Boss! Ano po ang gagawin sa content? ✍️'],
      blaze: ['Copy, Boss! Ano po ang ipo-post natin? 🚀', 'Nandito na po ako, Boss! 🚀'],
      reel: ['Copy, Boss! Ihahanda ko na ang mga video. 🎬', 'Noted, Boss! Aayusin ko ang video queue. 🎬'],
      nova: ['Opo, Boss! Nakikinig po ako. 📡', 'Naiintindihan ko po, Boss! 💬'],
      cipher: ['Noted, Boss! Babantayan ko po ang lahat. 🛡️', 'Opo, Boss! Ano po ang kailangan ng report? 📈'],
      argus: ['Nandito po ako, Boss. Nakabantay pa rin. 👁️', 'Opo, Boss. Ano po ang babantayan ko? 👁️'],
      sec: ['Opo, Boss! Itatala ko po. 🗂️', 'Nandito na po ako, Boss! 📝'],
      it: ['Copy, Boss! Sabihin mo lang ang aayusin ko. 🖥️', 'Opo, Boss! Handa ang server. 🖥️'],
      fixo: ['Opo, Boss! Ayos na ako dito. 🧹', 'Noted, Boss! 🧹'],
    };
    const runAfterCall = async (plan: AfterCallPlan) => {
      const everyone: MemberId[] = ['boss', 'sec', ...team(), 'argus'];
      void db.log('info', 'team', `Boss: pagkatapos ng tawag — ${plan.meeting ? 'meeting' : ''}${plan.meeting && plan.people.length ? ' + ' : ''}${plan.people.length ? `kausapin ${plan.people.map((k) => PERSON_NAME[k]).join(', ')}` : ''}`).catch(() => undefined);
      for (const k of plan.people) {
        if (token.stop) return;
        const display = PERSON_NAME[k];
        await say('boss', `${display}, may sasabihin ako sa iyo. 📣`, 2600);
        if (k === 'reel' || k === 'fixo') {
          await say('boss', k === 'reel' ? 'Reel, ihanda mo ang mga video at i-update mo ako. 🎬' : 'Fixo, ikaw na ang bahala sa maintenance. 🧹', 3000);
          if (token.stop) return;
          setCallout({ who: k, text: pick(AFTER_REPLY[k]), n: Date.now() });
          await sleep(3600);
        } else {
          await say(k as MemberId, pick(AFTER_REPLY[k]), 3000);
        }
      }
      if (token.stop) return;
      if (plan.meeting) {
        setPhase('meeting');
        await say('boss', 'Mira, mag-set ka ng meeting at ipatawag mo ang team! 📣', 3000);
        if (token.stop) return;
        await say('sec', 'Opo, Boss! Meeting po sa Shared Brain — ngayon na! 📅', 2800);
        if (token.stop) return;
        moveAll(everyone, 'lab');
        await sleep(14000); // Reel and Fixo walk from far away: give them time to sit
        if (token.stop) return;
        moveAll(everyone, 'office');
        await sleep(4800);
        setPhase('work');
      }
    };

    void (async () => {
      let chatting = false;
      let lastWho: MemberId | null = null;
      // random ang susunod na gawain (may bigat), at hindi pwedeng pareho sa kakatapos lang
      const OPTIONS: { kind: 'brainstorm' | 'coffee' | 'arcade' | 'service'; weight: number }[] = [
        { kind: 'brainstorm', weight: 3 },
        { kind: 'service', weight: 3 },
        { kind: 'coffee', weight: 2 },
        { kind: 'arcade', weight: 1 },
      ];
      let lastKind: string | null = null;
      const nextKind = () => {
        const pool = OPTIONS.filter((o) => o.kind !== lastKind);
        let r = Math.random() * pool.reduce((n, o) => n + o.weight, 0);
        for (const o of pool) {
          r -= o.weight;
          if (r <= 0) return o.kind;
        }
        return pool[0].kind;
      };
      const dueMeal = (): Meal | null => {
        const now = new Date();
        const m = activeMeal(now);
        return m && !mealDone(now, m) ? m : null;
      };
      /** isang maikling usapan habang nagtatrabaho: sariling linya, o tanong at kaukulang sagot */
      const chatter = async () => {
        // habang nagsasalita si Boss sa owner, huwag siyang isali sa random na chatter (hindi mapapalitan ang caption niya)
        const bossBusy = Date.now() < bossHold.current;
        const pool = ['boss', 'sec', 'it', 'argus', ...team()].filter((m) => !(bossBusy && m === 'boss')) as MemberId[];
        const who = pick(pool.filter((m) => m !== lastWho));
        lastWho = who;
        const r = Math.random();
        if (r < 0.5) {
          await say(who, pick(WORK_POOL[who]), 3400);
        } else {
          const others = pool.filter((m) => m !== who);
          const other = pick(others);
          const chat = pick(CHATS);
          await say(who, chat.ask, 2800);
          if (token.stop) return;
          await say(other, pick(chat.reply), 2800);
          if (!token.stop && Math.random() < 0.35) await say(who, pick(CHAT_FOLLOWUP), 2200);
        }
      };
      await sleep(4000);
      while (!token.stop) {
        let waited = 0;
        const limit = rand(16000, 32000);
        let nextChatAt = rand(3000, 7000);
        while (!token.stop && waited < limit && !queue.current && cmdRef.current.length === 0 && !hasPlan() && !dueMeal()) {
          await sleep(500);
          waited += 500;
          // paminsan-minsan, may nag-uusap (random ang oras at tao)
          if (waited >= nextChatAt && !chatting) {
            nextChatAt = waited + rand(4500, 9500);
            chatting = true;
            void chatter().finally(() => {
              chatting = false;
            });
          }
        }
        if (token.stop) break;
        // hintayin munang matapos ang usapan para hindi magsabay sa meeting/kainan
        while (!token.stop && chatting) await sleep(300);
        if (token.stop) break;
        // utos ni Boss: nauuna sa lahat (hindi nawawala kahit may kainan; susunod na iyon pagkatapos)
        if (cmdRef.current.length) {
          const c = cmdRef.current.shift()!;
          await runCommand(c);
          continue;
        }
        const plan = takePlan();
        if (plan) {
          await runAfterCall(plan);
          continue;
        }
        const manual = queue.current;
        queue.current = null;
        const due = dueMeal();
        if (due && manual !== 'brainstorm' && manual !== 'coffee' && manual !== 'arcade' && manual !== 'service') {
          await eat(due);
          continue;
        }
        if (manual === 'meal') {
          await eat(mealForHour(new Date().getHours()));
          continue;
        }
        const next = manual ?? nextKind();
        lastKind = next;
        if (next === 'brainstorm') await brainstorm();
        else if (next === 'coffee') await coffee();
        else if (next === 'service') await service(manual === 'service');
        else await arcade();
      }
    })();

    return () => {
      token.stop = true;
    };
  }, []);

  /**
   * Routine ng mga AI employee: bawat segundo, nababawasan ang energy ng nagtatrabaho. Kapag mababa na →
   * kape / laro / idlip (shuffle) → kapag puno na ulit, balik sa desk. Sa meeting, kainan, kape at arcade ng buong team,
   * ang team event ang masusunod (at nakakabawi rin sila ng energy doon).
   */
  useEffect(() => {
    const st = initRoutine();
    const stop = { v: false };
    const sayLine = (id: MemberId, text: string, ms = 3200) => {
      setSpeech((p) => ({ ...p, [id]: text }));
      window.setTimeout(() => {
        if (stop.v) return;
        setSpeech((p) => {
          if (p[id] !== text) return p;
          const n = { ...p };
          delete n[id];
          return n;
        });
      }, ms);
    };
    const setPlace = (id: MemberId, place: Place) => setPlaces((p) => (p[id] === place ? p : { ...p, [id]: place }));
    // Argus (Watchdog): sariling energy at rotation, gamit ang parehong logic ni Reel (reelRoutine.ts)
    let ar: ReelRoutine = initReelRoutine();
    const publish = () => {
      const o = {} as Record<AgentId, Routine>;
      AGENTS.forEach((a) => { o[a.id] = { energy: Math.round(st[a.id].energy), doing: st[a.id].doing }; });
      setRoutine(o);
      setArgusRoutine({ energy: Math.round(ar.energy), doing: ar.doing });
    };
    const stepArgus = (ph: Phase) => {
      const prev = ar.doing;
      if (ph !== 'work') {
        // team event (meeting, kainan, kape...): ito muna ang masusunod; babalik siya sa desk at hindi nauubos ang energy
        if (prev !== 'work') {
          ar = { ...initReelRoutine(), energy: ar.energy, last: ar.last };
          if (placesRef.current.argus === 'rest') setPlace('argus', 'office');
        }
        return;
      }
      // 'working' = nauubos ang energy habang nagbabantay (parehong bilis ng ibang AI employee), kaya may break din siya paminsan-minsan
      ar = stepReel(ar, 1, 'working');
      if (ar.doing === prev) {
        if (ar.doing === 'rest' && n % 9 === 0 && !speechBusy('argus')) sayLine('argus', 'Zzz… 💤', 2200);
        return;
      }
      if (ar.doing === 'work') {
        if (prev === 'rest') setPlace('argus', 'office');
        if (!speechBusy('argus')) sayLine('argus', pick(ARGUS_BREAK_BACK), 2800);
      } else {
        if (ar.doing === 'rest') setPlace('argus', 'rest');
        if (!speechBusy('argus')) sayLine('argus', pick(ARGUS_BREAK_GO[ar.doing]), 3000);
      }
    };
    let n = 0;
    const timer = window.setInterval(() => {
      n++;
      const ph = phaseRef.current;
      const now = Date.now();
      AGENTS.forEach((a) => {
        const id = a.id;
        const s = st[id];
        if (pausedRef.current[id]) return;
        if (ph !== 'work') {
          // team event: nauuna ito sa personal na routine
          if (s.doing !== 'work') {
            s.doing = 'work';
            // balik muna sa desk; ang team event na ang maglilipat sa kanya ulit (lahat ng event ay may unang usapan bago gumalaw ang team)
            if (['bar', 'play', 'rest'].includes(placesRef.current[id])) setPlace(id, 'office');
          }
          if (ph === 'coffee' || ph === 'meal') s.energy = Math.min(100, s.energy + 1.6);
          else if (ph === 'arcade' && placesRef.current[id] === 'play') s.energy = Math.min(100, s.energy + 1.2);
          return;
        }
        if (s.doing === 'work') {
          s.energy = Math.max(0, s.energy - s.drain);
          if (!s.warned && s.energy <= s.floor + 10 && s.energy > s.floor && Math.random() < 0.5) {
            s.warned = true;
            if (!speechBusy(id)) sayLine(id, pick(LOW_ENERGY), 2800);
          }
          const away = AGENTS.filter((x) => st[x.id].doing !== 'work').length;
          if (s.energy <= s.floor && away < MAX_AWAY) {
            const kind = pickBreak(s);
            s.doing = kind;
            s.last = kind;
            s.start = now;
            s.mid = false;
            setPlace(id, BREAK_PLACE[kind]);
            sayLine(id, pick(BREAK_GO[kind]), 3000);
          }
        } else {
          const kind = s.doing;
          s.energy = Math.min(100, s.energy + RECOVER[kind]);
          if (!s.mid && now - s.start > 11000) { s.mid = true; sayLine(id, pick(BREAK_MID[kind]), 2600); }
          else if (kind === 'rest' && n % 7 === 0 && now - s.start > 8000) sayLine(id, pick(BREAK_MID.rest), 2200);
          if (s.energy >= 92 && now - s.start >= MIN_BREAK_MS[kind]) {
            s.doing = 'work';
            s.drain = rollDrain();
            s.floor = rollFloor();
            s.warned = false;
            setPlace(id, 'office');
            sayLine(id, pick(BREAK_BACK), 2800);
          }
        }
      });
      stepArgus(ph);
      publish();
    }, 1000);
    // hindi sasapawan ang usapan na nagaganap na (speech state ay nasa useState, kaya sa ref natin babasahin)
    const speechBusy = (id: MemberId) => Boolean(speechRef.current[id]);
    return () => {
      stop.v = true;
      window.clearInterval(timer);
    };
  }, []);

  return { places, speech, phase, meal, ideas, inbox, report, itTarget, broken, tickets, routine, argusRoutine, trigger, sendCommand, runAfterCall, callout, cmdSteps, bossSay };
}
