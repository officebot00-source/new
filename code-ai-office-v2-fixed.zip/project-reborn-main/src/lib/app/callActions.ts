// "Pagkatapos ng usapan": ang sinabi ng owner kay Code Solo habang nag-uusap (hal. "pagkatapos natin mag-usap,
// mag-set ka ng meeting at kausapin mo sina Reel, Cipher, Argus, Nova, Aria at Blaze") ay isinasagawa ni Boss
// pagbaba ng tawag (o pagsara ng chat). Walang AI na kailangan: simpleng pagkilala ng salita, kaya gumagana ito offline.
import type { VoiceLang } from './voice';

export type PersonKey = 'aria' | 'blaze' | 'reel' | 'nova' | 'cipher' | 'argus' | 'sec' | 'it' | 'fixo';
export interface AfterCallPlan { meeting: boolean; people: PersonKey[] }

export const PERSON_NAME: Record<PersonKey, string> = {
  aria: 'Aria', blaze: 'Blaze', reel: 'Reel', nova: 'Nova', cipher: 'Cipher', argus: 'Argus', sec: 'Ms. Mira', it: 'Dex', fixo: 'Fixo',
};
const PERSON_RE: [PersonKey, RegExp][] = [
  ['aria', /\baria\b/i], ['blaze', /\bblaze\b/i], ['reel', /\b(reel|riel)\b/i], ['nova', /\bnova\b/i], ['cipher', /\b(cipher|saifer|sayfer)\b/i],
  ['argus', /\bargus\b/i], ['sec', /\b(mira|ms\.? ?mira|secretary)\b/i], ['it', /\bdex\b/i], ['fixo', /\bfixo\b/i],
];
const EVERYONE = /(lahat|buong team|buong grupo|everyone|whole team|entire team|all of them|all the bots)/i;
const EVERYONE_LIST: PersonKey[] = ['aria', 'blaze', 'reel', 'nova', 'cipher', 'argus'];

// "pagkatapos / after ... usap / tawag / call"
const AFTER = /(pagkatapos|matapos|pag ?tapos|\btapos\b|nang matapos|kapag tapos|kapag natapos|pag natapos|after|once we('re| are) (done|finished)|when we('re| are) (done|finished)|(pag|kapag|pagka|pag-?)\s?(binaba|ibaba|inend|i-?end|nag-?end)|(before|when|once) i hang up|pagbaba)/i;
const TALK_END = /(usap|tawag|call|talk|chat|nag-?usap|mag-?usap|natin|namin|ito|this|binaba|ibaba|hang up|end)/i;
const MEETING = /(meeting|pulong|pulungin|magpulong|patawag|ipatawag|huddle|group call|mag-?set ka ng meeting|set (up )?a meeting|schedule a meeting|call (a|the) (team )?meeting)/i;
const TALK_TO = /(kausapin|kausap|kakausapin|makipag-?usap|makipag-?meeting|talk to|speak (to|with)|tell|sabihan|sabihin mo kay|tawagin|tawagan|utusan|atasan|pulungin|i-?brief|brief)/i;

/** Inaayos ang karaniwang pagkakamali ng speech-to-text at ng pag-type ("miting", "mag patawag", "mag set") bago kilalanin ang utos. */
const norm = (raw: string): string => raw.replace(/\s+/g, ' ').trim()
  .replace(/\b(miting|mitting|meetin|meting)\b/gi, 'meeting')
  .replace(/\bmag[ -]?pa[ -]?tawag\b/gi, 'magpatawag')
  .replace(/\bi[ -]?pa[ -]?tawag\b/gi, 'ipatawag')
  .replace(/\bpa[ -]?tawag\b/gi, 'patawag')
  .replace(/\bmag[ -]set\b/gi, 'magset');

/** Kinikilala kung may utos na gagawin pagkatapos ng usapan. null = wala. */
export function parseAfterCall(raw: string): AfterCallPlan | null {
  const t = norm(raw);
  if (t.length < 12 || !AFTER.test(t) || !TALK_END.test(t)) return null;
  const meeting = MEETING.test(t);
  let people = PERSON_RE.filter(([, re]) => re.test(t)).map(([k]) => k);
  if (!people.length && EVERYONE.test(t) && TALK_TO.test(t)) people = [...EVERYONE_LIST];
  if (!meeting && !people.length) return null;
  // "kausapin mo ang lahat" kasama ang pangalan: idagdag ang buong team
  if (people.length && EVERYONE.test(t) && TALK_TO.test(t)) people = [...new Set([...people, ...EVERYONE_LIST])];
  return { meeting, people };
}

// Utos na gagawin AGAD (walang "pagkatapos"): "magpatawag ka ng meeting sa buong team", "kausapin mo si Reel".
// Dati, ang ganito ay napupunta lang sa AI na sumasagot ng "sige" pero walang ginagawa.
const NOW_MEETING = /(magpatawag|mag-?pa-?tawag|ipatawag|patawagin|pulungin|mag-?set (ka |mo )?(na )?ng meeting|mag-?schedule (ka )?ng meeting|gawa (ka )?ng meeting|(set|call|schedule|start|hold) (up )?(a |the )?(team )?meeting|mag-?meeting (kayo|tayo|na))/i;
const IMPERATIVE = /\b(mo|ka|please|pls|po|na)\b/i;
const QUESTION = /(\?|\b(ano|bakit|paano|kailan|sino|what|why|how|when|who)\b)/i;

/** Kinikilala ang utos na gagawin ngayon din. null = wala (o may "pagkatapos", na hawak ng parseAfterCall). */
export function parseNowCall(raw: string): AfterCallPlan | null {
  const t = norm(raw);
  if (t.length < 8 || AFTER.test(t) || QUESTION.test(t)) return null;
  const meeting = NOW_MEETING.test(t);
  let people = PERSON_RE.filter(([, re]) => re.test(t)).map(([k]) => k);
  if (!meeting && !(TALK_TO.test(t) && IMPERATIVE.test(t))) return null;
  if (!meeting && !people.length && EVERYONE.test(t)) people = [...EVERYONE_LIST];
  if (people.length && EVERYONE.test(t) && TALK_TO.test(t)) people = [...new Set([...people, ...EVERYONE_LIST])];
  return meeting || people.length ? { meeting, people } : null;
}

/** Utos na naintindihan ng AI (kapag hindi ito nahuli ng mga pattern sa itaas): ligtas na nililinis bago gamitin. */
export interface BossAction extends AfterCallPlan { when: 'now' | 'after_call' }
export function sanitizeAction(raw: unknown): BossAction | null {
  const o = raw as { meeting?: unknown; people?: unknown; when?: unknown } | null;
  if (!o || typeof o !== 'object') return null;
  const people = (Array.isArray(o.people) ? o.people : []).map((x) => String(x).toLowerCase()).filter((k): k is PersonKey => Object.hasOwn(PERSON_NAME, k));
  const meeting = o.meeting === true;
  if (!meeting && !people.length) return null;
  return { meeting, people: [...new Set(people)], when: o.when === 'after_call' ? 'after_call' : 'now' };
}

/** Ang bahagi ng prompt ng AI para sa utos sa office (ginagamit ng server at ng browser mode). */
export const ACTION_PROMPT = `If the owner explicitly ORDERS you to do something in the office (call a team meeting, or talk to specific team members), either right now or after the call, set "action" to {"meeting": boolean, "people": [keys from aria|blaze|reel|nova|cipher|argus|sec|it|fixo], "when": "now" | "after_call"}. For the whole team use meeting true and people []. In your reply, in the owner's language, say that you are doing it now (or after the call). Never set "action" for questions or small talk; otherwise "action" is null.`;

/** Sagot ni Boss kapag gagawin na agad ang utos. */
export function nowConfirm(p: AfterCallPlan, l: VoiceLang): string {
  const names = list(p.people.map((k) => PERSON_NAME[k]), l);
  if (l === 'fil-PH') {
    if (p.meeting && p.people.length) return `Sige, boss! Ipapatawag ko na ang meeting at kakausapin ko sina ${names} ngayon din.`;
    if (p.meeting) return 'Sige, boss! Ipapatawag ko na ang buong team sa meeting ngayon din.';
    return `Sige, boss! Kakausapin ko na sina ${names} ngayon din.`;
  }
  if (p.meeting && p.people.length) return `On it, boss! Calling the meeting and talking to ${names} right now.`;
  if (p.meeting) return 'On it, boss! Calling the whole team to a meeting right now.';
  return `On it, boss! Talking to ${names} right now.`;
}

export function mergePlan(a: AfterCallPlan | null, b: AfterCallPlan): AfterCallPlan {
  return { meeting: (a?.meeting ?? false) || b.meeting, people: [...new Set([...(a?.people ?? []), ...b.people])] };
}
export const planIsEmpty = (p: AfterCallPlan | null): boolean => !p || (!p.meeting && p.people.length === 0);

const list = (names: string[], l: VoiceLang) => {
  if (names.length <= 1) return names.join('');
  const and = l === 'fil-PH' ? 'at' : 'and';
  return `${names.slice(0, -1).join(', ')} ${and} ${names[names.length - 1]}`;
};

/** Ang sagot ni Boss na kinukumpirma ang utos (binabasa nang malakas). */
export function planConfirm(p: AfterCallPlan, l: VoiceLang): string {
  const names = list(p.people.map((k) => PERSON_NAME[k]), l);
  if (l === 'fil-PH') {
    if (p.meeting && p.people.length) return `Sige, boss! Pagkatapos ng usapan natin, magse-set ako ng meeting at kakausapin ko sina ${names}.`;
    if (p.meeting) return 'Sige, boss! Pagkatapos ng usapan natin, magse-set ako ng meeting.';
    return `Sige, boss! Pagkatapos ng usapan natin, kakausapin ko sina ${names}.`;
  }
  if (p.meeting && p.people.length) return `Got it, boss! Once we're done talking, I'll set up a meeting and talk to ${names}.`;
  if (p.meeting) return "Got it, boss! Once we're done talking, I'll set up a meeting.";
  return `Got it, boss! Once we're done talking, I'll talk to ${names}.`;
}

export function planSummary(p: AfterCallPlan): string {
  const parts: string[] = [];
  if (p.meeting) parts.push('meeting');
  if (p.people.length) parts.push(`kausapin: ${p.people.map((k) => PERSON_NAME[k]).join(', ')}`);
  return parts.join(' + ');
}

// Paalam / tapos na ang usapan: kapag may nakabinbing plano, ibababa na ni Boss ang tawag at gagawin agad ang plano.
// (Hindi isinasama ang "after"/"pagkatapos" dahil iyon ay utos, hindi paalam.)
const GOODBYE = /^(?:(?:sige|okay|ok|oo|yun na|iyon na|yan na|ayun)[ ,.!]*)*(?:(?:yun|iyon|yan|ayun)\s+(?:lang|na)(?:\s+(?:muna|po|boss))*|tapos\s+na(?:\s+(?:tayo|ako|po|boss))*|paalam|bye|goodbye|babye|babush|ingat|salamat\s+boss|thank you(?: boss)?|thanks(?: boss)?|that'?s all|that is all|that'?s it|we'?re done|i'?m done|end call|hang up|ibaba mo na|ibababa ko na|babain ko na|baba ko na)(?:[ ,.!]+(?:boss|po|na|muna|sige|bye|ingat|salamat|thanks))*[ .!?]*$/i;
export const isGoodbye = (raw: string): boolean => {
  const t = raw.replace(/\s+/g, ' ').trim();
  return t.length > 0 && t.length <= 60 && GOODBYE.test(t);
};
