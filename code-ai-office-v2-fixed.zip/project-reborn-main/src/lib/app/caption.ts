// Shared rules for the AI Caption & Hashtag writer (pure: used by the server handler, the screen and the tests).

export type CaptionPlatform = 'facebook' | 'twitter' | 'instagram' | 'tiktok' | 'discord' | 'telegram';

export interface PlatformRule {
  label: string;
  /** Longest caption allowed (characters, hashtags not included unless `sharedLimit`). */
  maxCaption: number;
  /** Hashtag count the AI is asked for, and the most that are kept. */
  minTags: number;
  maxTags: number;
  /** True when caption + hashtags must fit the limit together (X). */
  sharedLimit?: boolean;
  style: string;
}

export const CAPTION_PLATFORMS: Record<CaptionPlatform, PlatformRule> = {
  facebook: { label: 'Facebook', maxCaption: 600, minTags: 3, maxTags: 5, style: 'story-driven, 2-4 short paragraphs, ends with a question or call to comment' },
  twitter: { label: 'X (Twitter)', maxCaption: 280, minTags: 1, maxTags: 2, sharedLimit: true, style: 'punchy one or two lines, hook first' },
  instagram: { label: 'Instagram', maxCaption: 1000, minTags: 8, maxTags: 15, style: 'visual, emoji-friendly, strong first line, line breaks' },
  tiktok: { label: 'TikTok', maxCaption: 150, minTags: 3, maxTags: 5, style: 'very short, trend-aware hook, casual' },
  discord: { label: 'Discord', maxCaption: 800, minTags: 0, maxTags: 3, style: 'community call-out, friendly, markdown bold allowed' },
  telegram: { label: 'Telegram', maxCaption: 500, minTags: 2, maxTags: 4, style: 'short channel broadcast, clear call to action' },
};

export const isCaptionPlatform = (v: unknown): v is CaptionPlatform =>
  typeof v === 'string' && Object.hasOwn(CAPTION_PLATFORMS, v);

export const TOPIC_MAX = 500;

/** Cleans AI hashtags: one word each, leading #, no duplicates, capped to the platform maximum. */
export function normalizeHashtags(raw: unknown, platform: CaptionPlatform): string[] {
  const list = Array.isArray(raw) ? raw : typeof raw === 'string' ? raw.split(/[\s,]+/) : [];
  const seen = new Set<string>();
  const out: string[] = [];
  for (const item of list) {
    if (typeof item !== 'string') continue;
    const word = item.replace(/^#+/, '').replace(/[^\p{L}\p{N}_]/gu, '');
    if (!word) continue;
    const key = word.toLowerCase();
    if (seen.has(key)) continue;
    seen.add(key);
    out.push(`#${word}`);
    if (out.length >= CAPTION_PLATFORMS[platform].maxTags) break;
  }
  return out;
}

/** Applies the platform's length limit. On X the caption and hashtags share 280 characters. */
export function fitToPlatform(caption: string, hashtags: string[], platform: CaptionPlatform): { caption: string; hashtags: string[] } {
  const rule = CAPTION_PLATFORMS[platform];
  let text = caption.trim();
  let tags = [...hashtags];
  if (rule.sharedLimit) {
    const total = () => text.length + (tags.length ? 1 + tags.join(' ').length : 0);
    while (tags.length && total() > rule.maxCaption) tags = tags.slice(0, -1);
    const room = rule.maxCaption - (tags.length ? 1 + tags.join(' ').length : 0);
    if (text.length > room) text = `${text.slice(0, Math.max(0, room - 1)).trimEnd()}…`;
  } else if (text.length > rule.maxCaption) {
    text = `${text.slice(0, rule.maxCaption - 1).trimEnd()}…`;
  }
  return { caption: text, hashtags: tags };
}
