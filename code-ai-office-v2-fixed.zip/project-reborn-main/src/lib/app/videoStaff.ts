// Reel — the office's Video Editor employee. Blaze only posts; Reel makes game clips, edits and enhances videos.
// Pure helpers (no network): the status is worked out from the real video jobs, never invented.
import type { VideoJob } from './video';

export interface StaffDef { id: 'reel'; name: string; role: string; color: string; glow: string; emoji: string }

export const REEL: StaffDef = {
  id: 'reel', name: 'Reel', role: 'Video Editor & Enhancer', color: '#fb923c', glow: 'rgba(251, 146, 60, 0.35)', emoji: '🎞️',
};

export type ReelState = 'working' | 'waiting' | 'idle' | 'problem';
export interface ReelStatus { state: ReelState; label: string; bubble: string; editing: number; waiting: number; failed: number; doneToday: number }

type JobLite = Pick<VideoJob, 'status' | 'task' | 'updated_at' | 'post'>;
const startOfToday = (now: Date): number => { const d = new Date(now); d.setHours(0, 0, 0, 0); return d.getTime(); };

export function reelStatus(jobs: JobLite[], now = new Date()): ReelStatus {
  const since = startOfToday(now);
  const editing = jobs.filter((j) => j.status === 'queued' || j.status === 'editing');
  const waiting = jobs.filter((j) => j.status === 'awaiting_approval').length;
  const failed = jobs.filter((j) => j.status === 'failed' && Date.parse(j.updated_at) >= since).length;
  const doneToday = jobs.filter((j) => (j.status === 'awaiting_approval' || j.status === 'edited' || j.status === 'posted' || j.status === 'done') && Date.parse(j.updated_at) >= since).length;
  const enhancing = editing.some((j) => j.task === 'enhance');
  const base = { editing: editing.length, waiting, failed, doneToday };
  if (editing.length) return { ...base, state: 'working', label: 'Nag-e-edit', bubble: enhancing ? 'Ina-enhance ko ang video mo, boss ✨' : 'Gumagawa ng video… 🎬' };
  if (waiting) return { ...base, state: 'waiting', label: 'Hinihintay ka', bubble: `May ${waiting} video na hinihintay ang approval mo 👀` };
  if (failed) return { ...base, state: 'problem', label: 'May pumalya', bubble: `May ${failed} video na pumalya ngayon — tingnan sa Video Studio` };
  return { ...base, state: 'idle', label: 'Handa', bubble: 'Wala pang trabaho. Bigyan mo ako ng video link, boss! 🎞️' };
}
