// Voice call kay Boss: ang boses mo (speech-to-text) at ang boses ni Boss (text-to-speech).
// Gumagamit ng built-in na Web Speech API ng browser — walang dagdag na server o bayad.
//  • Pakikinig: Chrome / Edge / Safari (hindi suportado ang Firefox). Kailangan ng https (o localhost) at pahintulot sa mikropono.
//  • Boses ni Boss: kung may Filipino na boses ang device mo, iyon ang gagamitin; kung wala, English (PH/US) na boses ang magbabasa.
export type VoiceLang = 'fil-PH' | 'en-US';

interface SRAlt { transcript: string }
interface SRResult { isFinal: boolean; 0: SRAlt }
interface SREvent { resultIndex: number; results: ArrayLike<SRResult> }
interface SRInstance {
  lang: string;
  continuous: boolean;
  interimResults: boolean;
  onresult: ((e: SREvent) => void) | null;
  onerror: ((e: { error: string }) => void) | null;
  onend: (() => void) | null;
  start(): void;
  stop(): void;
  abort(): void;
}
type SRCtor = new () => SRInstance;

const ctor = (): SRCtor | null => {
  if (typeof window === 'undefined') return null;
  const w = window as unknown as { SpeechRecognition?: SRCtor; webkitSpeechRecognition?: SRCtor };
  return w.SpeechRecognition ?? w.webkitSpeechRecognition ?? null;
};

export const sttSupported = (): boolean => ctor() !== null;
export const ttsSupported = (): boolean => typeof window !== 'undefined' && 'speechSynthesis' in window;

export interface Listener { stop: () => void }
export interface ListenHandlers {
  /** habang nagsasalita ka pa (live na teksto) */
  onInterim: (text: string) => void;
  /** tapos ka nang magsalita: ang buong sinabi mo */
  onFinal: (text: string) => void;
  /** natapos ang pakikinig (tahimik, tapos magsalita, o itinigil) */
  onEnd: () => void;
  /** 'not-allowed' = hindi pinayagan ang mikropono · 'no-speech' = walang narinig (normal) · atbp. */
  onError: (code: string) => void;
}

/** Nakikinig sa mikropono hanggang matapos ang isang pangungusap. Ibinabalik ang Listener, o null kung hindi suportado. */
export function startListening(lang: VoiceLang, h: ListenHandlers): Listener | null {
  const C = ctor();
  if (!C) return null;
  let rec: SRInstance;
  try { rec = new C(); } catch { return null; }
  rec.lang = lang;
  rec.continuous = false;
  rec.interimResults = true;
  let done = false;
  rec.onresult = (e) => {
    let interim = '';
    let final = '';
    for (let i = e.resultIndex; i < e.results.length; i++) {
      const r = e.results[i];
      if (r.isFinal) final += r[0].transcript;
      else interim += r[0].transcript;
    }
    if (final.trim() && !done) { done = true; h.onFinal(final.trim()); }
    else if (interim.trim()) h.onInterim(interim.trim());
  };
  rec.onerror = (e) => h.onError(e.error);
  rec.onend = () => h.onEnd();
  try { rec.start(); } catch { return null; }
  return { stop: () => { try { rec.abort(); } catch { /* ok lang */ } } };
}

/* ---------------- wika: Tagalog o English? ---------------- */
// Mga salitang halos Tagalog lang (hindi ginagamit sa English). Mga "function word" ang gamit para tumpak kahit Taglish.
const TL_WORDS = new Set((
  'ang ng mga sa na ako ikaw ka mo ko ito iyan iyon yan yun yung kayo tayo kami namin natin nila niya siya ay ' +
  'po opo oo hindi huwag wag gusto kailangan paano ano bakit saan sino kailan magkano kumusta kamusta musta salamat ' +
  'sige lang naman pa din rin ba daw raw mayroon meron wala gawin gawing sabihin ayusin pakiusap pakisabi paki ' +
  'pwede puwede dapat kasi pero kung para tungkol ngayon bukas kahapon mamaya muna talaga sobra ' +
  'marami konti kaunti mas pinaka lahat bawat isa dalawa tatlo ipatupad ipakita sabihin ulit nga nang kay kina ' +
  'dito doon diyan dyan ayoko gusto ko ganito ganyan ganun ganoon iba bago luma maayos mabuti magaling'
).split(/\s+/).filter(Boolean));

// Mga salitang English lang (hindi kasama ang mga hiram sa Taglish gaya ng "post", "team", "update").
const EN_WORDS = new Set((
  'the is are was were be been a an and of to you your yours what how why when where who which can could please ' +
  'tell me my mine i it its this that these those with for on in at we us our do does did have has had will would ' +
  'should not from about they them their there here just really very much more some any need want like know think ' +
  'let get got give make made say said going gonna wanna thanks thank okay today tomorrow yesterday ' +
  'doing done working work today now then than but or if so because also still again all every each one two three'
).split(/\s+/).filter(Boolean));

/**
 * Hinuhulaan kung anong wika ang sinabi/isinulat ng tao.
 * 'fil-PH' = Tagalog (pati Taglish na mas marami ang Tagalog) · 'en-US' = English · null = hindi sigurado (hal. "ok", "yes").
 */
export function detectLang(text: string): VoiceLang | null {
  const words = text.toLowerCase().replace(/[^a-z\u00f1\s'-]/g, ' ').split(/\s+/).filter(Boolean);
  let tl = 0;
  let en = 0;
  for (const raw of words) {
    const w = raw.replace(/^['-]+|['-]+$/g, '');
    if (!w) continue;
    if (TL_WORDS.has(w)) tl++;
    else if (EN_WORDS.has(w)) en++;
    // mga panlaping Tagalog gaya ng "mag-", "nag-", "i-", "pa-" (hal. "i-post", "mag-reply")
    else if (/^(mag|nag|pag|ipa|ipag|maka|naka|pina|ma|na|i|pa)-/.test(raw)) tl++;
  }
  if (tl + en === 0) return null;
  return tl >= en ? 'fil-PH' : 'en-US';
}

/** Narinig ba ng mikropono ang boses ni Boss mismo? (halos parehong mga salita ng huling sagot niya) */
export function isEcho(heard: string, bossLast: string): boolean {
  const words = (t: string) => t.toLowerCase().replace(/[^a-z\u00f1\s'-]/g, ' ').split(/\s+/).filter((w) => w.length > 1);
  const h = words(heard);
  if (h.length < 4) return false;
  const b = new Set(words(bossLast));
  return h.filter((w) => b.has(w)).length / h.length >= 0.7;
}

/* ---------------- boses ni Boss ---------------- */
let cachedVoices: SpeechSynthesisVoice[] = [];
if (ttsSupported()) {
  const load = () => { cachedVoices = window.speechSynthesis.getVoices(); };
  load();
  window.speechSynthesis.addEventListener?.('voiceschanged', load);
}

const allVoices = (): SpeechSynthesisVoice[] =>
  cachedVoices.length ? cachedVoices : ttsSupported() ? window.speechSynthesis.getVoices() : [];

const norm = (l: string) => l.replace('_', '-');
const isFil = (v: SpeechSynthesisVoice) => /^(fil|tl)(-|$)/i.test(norm(v.lang));

/** Mas mataas = mas natural ang boses (Google / Microsoft Online / Natural / Neural / Enhanced). */
const quality = (v: SpeechSynthesisVoice): number => {
  let q = 0;
  if (/natural|neural|online|premium|enhanced|wavenet/i.test(v.name)) q += 3;
  if (/google/i.test(v.name)) q += 2;
  if (/microsoft/i.test(v.name)) q += 1;
  if (!v.localService) q += 1; // ang mga cloud voice ay kadalasang mas malinaw
  return q;
};

function pickVoice(lang: VoiceLang): SpeechSynthesisVoice | null {
  const v = allVoices();
  const best = (list: SpeechSynthesisVoice[]) => [...list].sort((a, b) => quality(b) - quality(a))[0] ?? null;
  if (lang === 'fil-PH') {
    // Tagalog ay dapat basahin ng Filipino na boses; kapag wala, English (PH) ang pinakamalapit na pagbigkas
    return best(v.filter(isFil)) ?? best(v.filter((x) => /^en-PH/i.test(norm(x.lang)))) ?? best(v.filter((x) => /^en-US/i.test(norm(x.lang)))) ?? best(v.filter((x) => /^en/i.test(norm(x.lang))));
  }
  return best(v.filter((x) => /^en-US/i.test(norm(x.lang)))) ?? best(v.filter((x) => /^en-(GB|AU|PH)/i.test(norm(x.lang)))) ?? best(v.filter((x) => /^en/i.test(norm(x.lang))));
}

/** May totoong boses ba sa device para sa wikang ito? (Kung wala sa Filipino, mali ang bigkas ng Tagalog.) */
export function hasNativeVoice(lang: VoiceLang): boolean {
  if (!ttsSupported()) return false;
  const v = allVoices();
  if (!v.length) return true; // hindi pa na-load ang listahan: huwag munang magbabala
  return lang === 'fil-PH' ? v.some(isFil) : v.some((x) => /^en/i.test(norm(x.lang)));
}

/** Tinatanggal ang emoji at palamuti, at inaayos ang mga simbolo para natural ang basa ng boses. */
export const forSpeech = (t: string, lang: VoiceLang = 'fil-PH'): string =>
  t
    .replace(/[\p{Extended_Pictographic}\uFE0F\u200D]/gu, '')
    .replace(/&/g, lang === 'fil-PH' ? ' at ' : ' and ')
    .replace(/(\d)\s*%/g, lang === 'fil-PH' ? '$1 porsyento' : '$1 percent')
    .replace(/[\u2026]/g, '.')
    .replace(/\s*[\u2014\u2013]\s*/g, ', ')
    .replace(/[\u201C\u201D"*_#`~^|\\<>[\]{}]/g, '')
    .replace(/\s+([,.!?])/g, '$1')
    .replace(/\s+/g, ' ')
    .trim();

/** Hinahati sa pangungusap: mas natural ang pahinga, at hindi pinuputol ng browser ang mahabang teksto. */
const sentences = (t: string): string[] =>
  (t.match(/[^.!?]+[.!?]*/g) ?? [t]).map((x) => x.trim()).filter((x) => /[\p{L}\p{N}]/u.test(x));

let speechToken = 0; // tumataas kapag may bagong salita o pinigilan, para huminto ang lumang pila

export const cancelSpeech = () => {
  speechToken++;
  if (ttsSupported()) window.speechSynthesis.cancel();
};

function speakChunk(text: string, lang: VoiceLang, voice: SpeechSynthesisVoice | null): Promise<void> {
  return new Promise((resolve) => {
    const u = new SpeechSynthesisUtterance(text);
    if (voice) { u.voice = voice; u.lang = voice.lang; } else u.lang = lang;
    // mas mabagal nang kaunti ang Tagalog para malinaw; natural ang tono (hindi pinalalim)
    u.rate = lang === 'fil-PH' ? 0.95 : 1;
    u.pitch = 0.95;
    u.volume = 1;
    let finished = false;
    const end = () => { if (finished) return; finished = true; window.clearTimeout(guard); resolve(); };
    // may mga browser na hindi nagpapadala ng "end" — huwag hayaang mag-hang ang tawag
    const guard = window.setTimeout(end, Math.max(4000, text.length * 130 + 2500));
    u.onend = end;
    u.onerror = end;
    try { window.speechSynthesis.speak(u); } catch { end(); }
  });
}

/** Binabasa nang malakas ang teksto sa tamang wika. Natatapos ang Promise kapag tapos na (o napigilan). Hindi nagt-throw. */
export async function speak(text: string, lang: VoiceLang): Promise<void> {
  const t = forSpeech(text, lang);
  if (!t || !ttsSupported()) return;
  window.speechSynthesis.cancel();
  const my = ++speechToken;
  const voice = pickVoice(lang);
  for (const part of sentences(t)) {
    if (my !== speechToken) return; // napigilan o may bagong salita
    await speakChunk(part, lang, voice);
  }
}
