// Game videos: the bot picks a saved game and plans a short vertical promo clip for it. PURE helpers only
// (no network, no database), so the browser, the server bot and the tests share them.
import { MAX_AUTO_PER_DAY, MAX_PENDING_REVIEW, type VideoJob, type VideoSettings } from './video';

export interface GameLite {
  id: string;
  title: string;
  genre?: string;
  description?: string;
  promo_link?: string;
  banner_image?: string;
  active?: boolean;
}

export interface GameVideoPlan {
  title_text: string;
  overlay_text: string;
  post_title: string;
  caption: string;
  tags: string[];
  duration_sec: number;
}

/** Wording that rotates with `variant`, so "gawa ulit" never gives the same clip twice in a row. */
const TAGLINES = ['Laruin na ngayon!', 'Handa ka na ba?', 'Subukan mo — libre ang tumingin!', 'Sino ang mananalo ngayon?', 'Bagong laro, bagong saya!'];
const HOOKS = ['🎮 Handa ka na ba sa susunod mong paborito?', '🔥 Ito na ang laro na hinihintay mo!', '⚡ Isang tap lang, laro na!', '🏆 Subukan kung gaano ka kagaling!', '✨ Bagong laro sa library natin!'];
const CTAS = ['Play now — link sa caption', 'I-click ang link at laro na!', 'Libre — subukan na ngayon', 'Laro na — nasa link sa baba', 'Tara, laro tayo!'];

const slug = (t: string) => t.toLowerCase().normalize('NFKD').replace(/[^a-z0-9]+/g, '').slice(0, 30);
const firstSentence = (t: string, max: number) => {
  const clean = t.replace(/\s+/g, ' ').trim();
  const m = clean.match(/^.*?[.!?](\s|$)/);
  const s = (m ? m[0] : clean).trim();
  return s.length > max ? `${s.slice(0, max - 1).trimEnd()}…` : s;
};

export function planGameVideo(game: GameLite, variant = 0): GameVideoPlan {
  const v = Math.abs(Math.trunc(variant)) || 0;
  const title = game.title.trim() || 'Bagong laro';
  const genre = (game.genre ?? '').trim();
  const desc = firstSentence(game.description ?? '', 140);
  const tag = TAGLINES[v % TAGLINES.length]!;
  const hook = HOOKS[v % HOOKS.length]!;
  const cta = CTAS[v % CTAS.length]!;
  const tags = [...new Set(['#gaming', genre ? `#${slug(genre)}` : '', `#${slug(title)}`, '#laro'].filter((t) => t.length > 1))];
  return {
    title_text: title.slice(0, 60),
    overlay_text: [genre, tag].filter(Boolean).join(' • ').slice(0, 80),
    post_title: title.slice(0, 120),
    caption: [hook, desc].filter(Boolean).join('\n'),
    tags,
    duration_sec: 12,
  };
}

/** The overlay text is the tagline line of the clip; the call-to-action is chosen by variant too. */
export const ctaFor = (variant = 0): string => CTAS[Math.abs(Math.trunc(variant)) % CTAS.length]!;

/** Which active game is "due": never-used first, then the one used longest ago. Returns null when there is no active game. */
export function pickGame(games: GameLite[], jobs: Pick<VideoJob, 'game_id' | 'created_at'>[]): { game: GameLite; variant: number } | null {
  const active = games.filter((g) => g.active !== false && g.title.trim());
  if (!active.length) return null;
  const last = new Map<string, number>();
  const count = new Map<string, number>();
  for (const j of jobs) {
    if (!j.game_id) continue;
    last.set(j.game_id, Math.max(last.get(j.game_id) ?? 0, Date.parse(j.created_at) || 0));
    count.set(j.game_id, (count.get(j.game_id) ?? 0) + 1);
  }
  const sorted = [...active].sort((a, b) => (last.get(a.id) ?? 0) - (last.get(b.id) ?? 0) || a.title.localeCompare(b.title));
  const game = sorted[0]!;
  return { game, variant: count.get(game.id) ?? 0 };
}

/** Philippine date (UTC+8) as YYYY-MM-DD — "today" for the daily quota. */
export const manilaDay = (d: Date): string => new Date(d.getTime() + 8 * 3_600_000).toISOString().slice(0, 10);

/** Should the bot make another game video right now? Never while the boss has a pile of unreviewed videos. */
export function shouldAutoGenerate(settings: Pick<VideoSettings, 'auto_generate' | 'auto_per_day'>, jobs: Pick<VideoJob, 'game_id' | 'status' | 'created_at' | 'source'>[], now: Date): boolean {
  if (!settings.auto_generate) return false;
  const perDay = Math.min(MAX_AUTO_PER_DAY, Math.max(1, Math.trunc(settings.auto_per_day ?? 1)));
  const today = manilaDay(now);
  const mine = jobs.filter((j) => j.game_id);
  const madeToday = mine.filter((j) => j.source === 'worker' && manilaDay(new Date(j.created_at)) === today).length;
  if (madeToday >= perDay) return false;
  if (mine.filter((j) => j.status === 'awaiting_approval').length >= MAX_PENDING_REVIEW) return false;
  if (mine.some((j) => j.status === 'queued' || j.status === 'editing')) return false;
  return true;
}
