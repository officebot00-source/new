import { botFnUrl } from './supabase';
import { getPasscode, LOCK_EVENT, setPasscode } from './publish';
import type { DailySettings, DailyStatus } from './daily';

export interface DailyOverview { settings: DailySettings; status: DailyStatus; connected: string[] }
export interface DailyRunResult { ok: boolean; queued: number; failed: number; skipped?: string; items: { slot: string; game?: string; platforms?: string[]; note?: string }[]; error?: string }

async function call<T>(body: Record<string, unknown>): Promise<T> {
  let res: Response;
  try {
    res = await fetch(botFnUrl('daily-poster'), {
      method: 'POST', headers: { 'Content-Type': 'application/json', 'x-app-passcode': getPasscode() }, body: JSON.stringify(body),
    });
  } catch {
    throw new Error(navigator.onLine === false ? 'Walang internet connection.' : 'Hindi maabot ang daily poster. Subukan ulit mamaya.');
  }
  let data: unknown = null;
  try { data = await res.json(); } catch { /* not json */ }
  if (res.status === 401) { setPasscode(''); window.dispatchEvent(new Event(LOCK_EVENT)); throw new Error('Wrong or missing password.'); }
  if (!res.ok) throw new Error((data as { error?: string })?.error ?? `Request failed (${res.status})`);
  return data as T;
}

export const dailyApi = {
  overview: () => call<DailyOverview & { ok: boolean }>({ action: 'status' }),
  save: (settings: DailySettings) => call<{ settings: DailySettings }>({ action: 'settings_set', settings }).then((r) => r.settings),
  runNow: (slotId?: string) => call<DailyRunResult>({ action: 'run_now', slot_id: slotId }),
};
