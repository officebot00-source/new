import { useState } from 'react';
import { Check, Copy, Hash, Sparkles } from 'lucide-react';
import { CAPTION_PLATFORMS, TOPIC_MAX, type CaptionPlatform } from '@/lib/app/caption';
import { writeCaption } from '@/lib/app/publish';
import { Button, Card, Select, TextArea } from './ui-kit';

const PLATFORM_OPTIONS = (Object.keys(CAPTION_PLATFORMS) as CaptionPlatform[]).map((id) => ({ value: id, label: CAPTION_PLATFORMS[id].label }));
const TONE_OPTIONS = [
  { value: 'hype', label: 'Hype' },
  { value: 'casual', label: 'Casual' },
  { value: 'competitive', label: 'Competitive' },
  { value: 'fomo', label: 'FOMO / Limited time' },
  { value: 'informative', label: 'Informative' },
];

/** Admin tool: topic + platform → AI-written caption and hashtags (gamit ang AI key sa API Settings). */
export default function CaptionWriter() {
  const [topic, setTopic] = useState('');
  const [platform, setPlatform] = useState<CaptionPlatform>('facebook');
  const [tone, setTone] = useState('hype');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [result, setResult] = useState<{ caption: string; hashtags: string[]; platform: CaptionPlatform } | null>(null);
  const [copied, setCopied] = useState('');

  const generate = async () => {
    if (!topic.trim()) { setError('Lagyan muna ng paksa.'); return; }
    setBusy(true); setError('');
    try {
      const r = await writeCaption(topic.trim(), platform, tone);
      setResult({ caption: r.caption, hashtags: r.hashtags, platform: r.platform });
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Hindi nakagawa ng caption.');
    } finally {
      setBusy(false);
    }
  };

  const copy = async (what: string, text: string) => {
    try { await navigator.clipboard.writeText(text); setCopied(what); window.setTimeout(() => setCopied(''), 1500); }
    catch { setError('Hindi ma-copy. Piliin at kopyahin nang manual.'); }
  };

  const tags = result?.hashtags.join(' ') ?? '';
  const full = result ? [result.caption, tags].filter(Boolean).join('\n\n') : '';
  const rule = CAPTION_PLATFORMS[result?.platform ?? platform];

  return (
    <Card className="p-5">
      <div className="flex items-start gap-3">
        <div className="rounded-lg bg-emerald-500/10 p-2 text-emerald-400"><Hash className="h-4 w-4" /></div>
        <div>
          <h3 className="text-sm font-semibold text-white">AI Caption & Hashtag Writer</h3>
          <p className="mt-0.5 text-xs text-slate-400">Ilagay ang paksa at platform — gagawa ang AI ng caption at hashtags na bagay doon.</p>
        </div>
      </div>

      <div className="mt-4 grid grid-cols-1 gap-5 lg:grid-cols-2">
        <div className="space-y-4">
          <TextArea
            label={`Paksa (topic) — ${topic.length}/${TOPIC_MAX}`}
            value={topic}
            onChange={(v) => setTopic(v.slice(0, TOPIC_MAX))}
            rows={4}
            placeholder="Hal. Bagong season ng Video Karera, double rewards ngayong weekend"
          />
          <div className="grid grid-cols-2 gap-3">
            <Select label="Platform" value={platform} onChange={(v) => setPlatform(v as CaptionPlatform)} options={PLATFORM_OPTIONS} />
            <Select label="Tono" value={tone} onChange={setTone} options={TONE_OPTIONS} />
          </div>
          <p className="text-xs text-slate-500">
            {CAPTION_PLATFORMS[platform].label}: hanggang {CAPTION_PLATFORMS[platform].maxCaption} characters
            {CAPTION_PLATFORMS[platform].sharedLimit ? ' (kasama ang hashtags)' : ''}, {CAPTION_PLATFORMS[platform].minTags}–{CAPTION_PLATFORMS[platform].maxTags} hashtags.
          </p>
          <Button className="w-full" onClick={() => void generate()} disabled={busy}>
            <Sparkles className="h-4 w-4" /> {busy ? 'Gumagawa…' : result ? 'Gumawa ulit' : 'Gumawa ng caption'}
          </Button>
          {error && <p className="text-sm text-amber-400" role="alert">{error}</p>}
        </div>

        <div className="rounded-xl border border-white/[0.06] bg-white/[0.02] p-4">
          {result ? (
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-medium text-slate-400">Caption · {rule.label}</span>
                <span className="text-xs text-slate-500">{(rule.sharedLimit ? full.replace('\n\n', ' ') : result.caption).length}/{rule.maxCaption}</span>
              </div>
              <p className="whitespace-pre-wrap text-sm leading-relaxed text-white">{result.caption}</p>
              {tags && <p className="text-sm text-emerald-400">{tags}</p>}
              <div className="flex flex-wrap gap-2 pt-1">
                <Button variant="secondary" onClick={() => void copy('all', full)}>
                  {copied === 'all' ? <Check className="h-4 w-4" /> : <Copy className="h-4 w-4" />} Copy lahat
                </Button>
                <Button variant="ghost" onClick={() => void copy('caption', result.caption)}>
                  {copied === 'caption' ? 'Na-copy!' : 'Caption lang'}
                </Button>
                {tags && (
                  <Button variant="ghost" onClick={() => void copy('tags', tags)}>
                    {copied === 'tags' ? 'Na-copy!' : 'Hashtags lang'}
                  </Button>
                )}
              </div>
            </div>
          ) : (
            <div className="flex h-full min-h-32 flex-col items-center justify-center text-center">
              <Sparkles className="h-8 w-8 text-slate-600" />
              <p className="mt-2 text-sm text-slate-400">Wala pang caption</p>
              <p className="text-xs text-slate-500">Ilagay ang paksa, pumili ng platform, tapos pindutin ang "Gumawa ng caption".</p>
            </div>
          )}
        </div>
      </div>
    </Card>
  );
}
