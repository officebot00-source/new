import { useEffect, useMemo, useRef, useState } from 'react';
import * as THREE from 'three';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js';
import { BOT_STYLE, type BrainBot, type BrainEvent, type BrainRule } from '@/lib/app/brain';
import { useCountUp } from './DashboardLive';

/* 3D "Neural Orb": the same living brain as BrainMap (2D) but you can drag to orbit it.
   - core: glowing sphere inside two counter-rotating wire icosahedra, tilted rings with beads, shockwave pulses, rule counter
   - bots: glossy orbs on a ring around the brain, halo, orbiting satellite, share-of-lessons arc, ripples when "hot"
   - wires: glowing tubes bot -> brain; comets rush in when a bot just learned something, then the lesson is broadcast back out
   - starfield + depth fading on labels so it reads as real 3D
   Plain three.js (no extra deps), pauses when off-screen / tab hidden, renders on demand with reduced-motion,
   and calls onFail() if WebGL is unavailable or the context is lost so the parent can fall back to the 2D map. */

const COARSE =
  typeof window !== 'undefined' && ((window.matchMedia?.('(pointer: coarse)').matches ?? false) || window.innerWidth < 800);
const REDUCED = typeof window !== 'undefined' && !!window.matchMedia?.('(prefers-reduced-motion: reduce)').matches;

const ORDER = ['Cipher', 'Aria', 'Blaze', 'Nova', 'Echo'];
const RING_R = 11.5;
const VIOLET = new THREE.Color('#a78bfa');
const frac = (x: number) => x - Math.floor(x);

function botPos(name: string, idx: number, total: number) {
  const k = ORDER.indexOf(name);
  const i = k >= 0 ? k : ORDER.length + idx;
  const n = Math.max(ORDER.length, total);
  const a = (i / n) * Math.PI * 2 - Math.PI / 2;
  return new THREE.Vector3(Math.cos(a) * RING_R, Math.sin(i * 2.1) * 3.6, Math.sin(a) * RING_R);
}

function canvasTex(w: number, h: number, draw: (c: CanvasRenderingContext2D) => void) {
  const cv = document.createElement('canvas');
  cv.width = w;
  cv.height = h;
  const c = cv.getContext('2d')!;
  draw(c);
  const t = new THREE.CanvasTexture(cv);
  t.colorSpace = THREE.SRGBColorSpace;
  t.anisotropy = 4;
  return t;
}

function glowTexture() {
  return canvasTex(128, 128, (c) => {
    const g = c.createRadialGradient(64, 64, 0, 64, 64, 64);
    g.addColorStop(0, 'rgba(255,255,255,1)');
    g.addColorStop(0.35, 'rgba(255,255,255,0.35)');
    g.addColorStop(1, 'rgba(255,255,255,0)');
    c.fillStyle = g;
    c.fillRect(0, 0, 128, 128);
  });
}

function emojiTexture(emoji: string) {
  return canvasTex(128, 128, (c) => {
    c.font = '84px "Apple Color Emoji","Segoe UI Emoji","Noto Color Emoji",sans-serif';
    c.textAlign = 'center';
    c.textBaseline = 'middle';
    c.fillText(emoji, 64, 70);
  });
}

function labelTexture(name: string, count: number, color: string, hot: boolean) {
  return canvasTex(512, 192, (c) => {
    c.textAlign = 'center';
    c.textBaseline = 'middle';
    c.lineJoin = 'round';
    c.font = '700 70px system-ui, -apple-system, "Segoe UI", Roboto, sans-serif';
    c.strokeStyle = 'rgba(5,7,15,0.92)';
    c.lineWidth = 12;
    c.strokeText(name, 256, 66);
    c.fillStyle = hot ? color : '#e2e8f0';
    c.fillText(name, 256, 66);
    c.font = '500 42px system-ui, -apple-system, "Segoe UI", Roboto, sans-serif';
    const sub = `${count} ${count === 1 ? 'lesson' : 'lessons'}`;
    c.strokeText(sub, 256, 136);
    c.fillStyle = '#9fb0c8';
    c.fillText(sub, 256, 136);
  });
}

function coreTexture(n: number) {
  return canvasTex(256, 160, (c) => {
    c.textAlign = 'center';
    c.textBaseline = 'middle';
    c.lineJoin = 'round';
    c.font = '800 96px system-ui, -apple-system, "Segoe UI", Roboto, sans-serif';
    c.strokeStyle = 'rgba(46,16,101,0.85)';
    c.lineWidth = 14;
    c.strokeText(String(n), 128, 66);
    c.fillStyle = '#fff';
    c.fillText(String(n), 128, 66);
    c.font = '700 26px system-ui, -apple-system, "Segoe UI", Roboto, sans-serif';
    c.fillStyle = '#ede9fe';
    c.fillText('R U L E S', 128, 128);
  });
}

function arcGeometry(share: number) {
  const arc = Math.max(0.03, Math.min(1, share)) * Math.PI * 2;
  return new THREE.TorusGeometry(1, 0.05, 8, 56, arc);
}

interface BotObj {
  id: string;
  name: string;
  color: THREE.Color;
  hex: string;
  pos: THREE.Vector3;
  group: THREE.Group;
  bb: THREE.Group; // billboard (always faces the camera)
  body: THREE.Mesh<THREE.SphereGeometry, THREE.MeshStandardMaterial>;
  halo: THREE.Sprite;
  emoji: THREE.Sprite;
  label: THREE.Sprite;
  arc: THREE.Mesh<THREE.TorusGeometry, THREE.MeshBasicMaterial>;
  base: THREE.Mesh;
  ripples: THREE.Mesh<THREE.RingGeometry, THREE.MeshBasicMaterial>[];
  orb: THREE.Group;
  sat: THREE.Mesh;
  tube: THREE.Mesh<THREE.TubeGeometry, THREE.MeshBasicMaterial>;
  curve: THREE.QuadraticBezierCurve3;
  packets: THREE.Mesh<THREE.SphereGeometry, THREE.MeshBasicMaterial>[]; // [0] ambient, [1..3] comet, [4..5] broadcast
  r: number;
  targetR: number;
  count: number;
  share: number;
  labelKey: string;
  hotT: number;
  hoverT: number;
  phase: number;
}

interface NodeIn { bot: BrainBot }
interface Data {
  nodes: NodeIn[];
  hot: Set<string>;
  byBot: Record<string, number>;
  maxN: number;
  shown: number;
  version: number;
}

export default function BrainMap3D({
  bots, rules, events, onFail,
}: { bots: BrainBot[]; rules: BrainRule[]; events: BrainEvent[]; onFail?: () => void }) {
  const boxRef = useRef<HTMLDivElement>(null);
  const failRef = useRef(onFail);
  failRef.current = onFail;
  const [hoverId, setHoverId] = useState<string | null>(null);

  const active = rules.filter((r) => r.status === 'approved').length;
  const shown = Math.round(useCountUp(active, 1100));
  const byBot = useMemo(() => {
    const m: Record<string, number> = {};
    for (const r of rules) if (r.source_bot_id && r.status === 'approved') m[r.source_bot_id] = (m[r.source_bot_id] ?? 0) + 1;
    return m;
  }, [rules]);
  const hot = useMemo(() => {
    const cutoff = Date.now() - 120_000;
    return new Set(events.filter((e) => new Date(e.created_at).getTime() > cutoff && e.learned_by_bot_id).map((e) => e.learned_by_bot_id as string));
  }, [events]);
  const nodes = useMemo(() => bots.map((bot) => ({ bot })), [bots]);
  const maxN = Math.max(1, ...nodes.map((n) => byBot[n.bot.id] ?? 0));
  const hotCount = nodes.filter((n) => hot.has(n.bot.id)).length;

  const data = useRef<Data>({ nodes, hot, byBot, maxN, shown, version: 0 });
  useEffect(() => {
    const d = data.current;
    d.nodes = nodes;
    d.hot = hot;
    d.byBot = byBot;
    d.maxN = maxN;
    d.shown = shown;
    d.version++;
  }, [nodes, hot, byBot, maxN, shown]);

  const hoverRef = useRef<string | null>(null);

  useEffect(() => {
    const box = boxRef.current;
    if (!box) return;

    let renderer: THREE.WebGLRenderer;
    try {
      renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true, powerPreference: 'high-performance' });
      if (!renderer.getContext()) throw new Error('no webgl');
    } catch {
      failRef.current?.();
      return;
    }
    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, COARSE ? 1.5 : 2));
    renderer.setClearColor(0x000000, 0);
    const cv = renderer.domElement;
    cv.style.display = 'block';
    cv.style.width = '100%';
    cv.style.height = '100%';
    box.appendChild(cv);

    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(45, 1, 0.1, 200);
    const dir = new THREE.Vector3(0, 0.3, 1).normalize();
    camera.position.copy(dir).multiplyScalar(34);

    const controls = new OrbitControls(camera, cv);
    controls.enableDamping = true;
    controls.dampingFactor = 0.08;
    controls.enablePan = false;
    controls.enableZoom = false;
    controls.minPolarAngle = 0.55;
    controls.maxPolarAngle = 2.25;
    controls.autoRotate = !REDUCED;
    controls.autoRotateSpeed = COARSE ? 0.7 : 0.9;
    // phones: let a vertical swipe scroll the page, a horizontal drag orbits the brain
    if (COARSE) cv.style.touchAction = 'pan-y';
    let resumeTimer = 0;
    controls.addEventListener('start', () => {
      window.clearTimeout(resumeTimer);
      controls.autoRotate = false;
    });
    controls.addEventListener('end', () => {
      window.clearTimeout(resumeTimer);
      resumeTimer = window.setTimeout(() => { controls.autoRotate = !REDUCED; }, 2500);
    });

    /* ---------- shared resources ---------- */
    const glow = glowTexture();
    const sphereGeo = new THREE.SphereGeometry(1, 24, 24);
    const packetGeo = new THREE.SphereGeometry(0.2, 10, 10);
    const rippleGeo = new THREE.RingGeometry(0.94, 1, 56);
    const baseRingGeo = new THREE.TorusGeometry(1, 0.02, 6, 64);
    const garbage: { dispose(): void }[] = [glow, sphereGeo, packetGeo, rippleGeo, baseRingGeo];

    /* ---------- lights ---------- */
    scene.add(new THREE.AmbientLight(0xffffff, 0.75));
    const coreLight = new THREE.PointLight(0xa78bfa, 90, 60, 1.4);
    scene.add(coreLight);
    const keyLight = new THREE.DirectionalLight(0xffffff, 1.2);
    keyLight.position.set(6, 12, 10);
    scene.add(keyLight);

    /* ---------- starfield ---------- */
    const starGroup = new THREE.Group();
    scene.add(starGroup);
    const mkStars = (n: number, color: string, size: number) => {
      const pos = new Float32Array(n * 3);
      for (let i = 0; i < n; i++) {
        const r = 22 + Math.random() * 30;
        const th = Math.random() * Math.PI * 2;
        const ph = Math.acos(2 * Math.random() - 1);
        pos[i * 3] = r * Math.sin(ph) * Math.cos(th);
        pos[i * 3 + 1] = r * Math.cos(ph) * 0.7;
        pos[i * 3 + 2] = r * Math.sin(ph) * Math.sin(th);
      }
      const g = new THREE.BufferGeometry();
      g.setAttribute('position', new THREE.BufferAttribute(pos, 3));
      const m = new THREE.PointsMaterial({ color, size, map: glow, transparent: true, opacity: 0.85, blending: THREE.AdditiveBlending, depthWrite: false, sizeAttenuation: true });
      garbage.push(g, m);
      starGroup.add(new THREE.Points(g, m));
    };
    mkStars(COARSE ? 140 : 300, '#c4b5fd', 0.9);
    mkStars(COARSE ? 60 : 120, '#7dd3fc', 0.7);

    /* ---------- core ---------- */
    const core = new THREE.Group();
    scene.add(core);
    const innerMat = new THREE.MeshBasicMaterial({ color: '#8b5cf6' });
    const inner = new THREE.Mesh(sphereGeo, innerMat);
    inner.scale.setScalar(2.3);
    core.add(inner);
    const shellMat = new THREE.MeshBasicMaterial({ color: '#c4b5fd', transparent: true, opacity: 0.22, blending: THREE.AdditiveBlending, depthWrite: false, side: THREE.BackSide });
    const shell = new THREE.Mesh(sphereGeo, shellMat);
    shell.scale.setScalar(2.9);
    core.add(shell);
    const ico1Geo = new THREE.IcosahedronGeometry(3.3, 1);
    const ico2Geo = new THREE.IcosahedronGeometry(4.1, 0);
    const ico1Mat = new THREE.MeshBasicMaterial({ color: '#c4b5fd', wireframe: true, transparent: true, opacity: 0.55 });
    const ico2Mat = new THREE.MeshBasicMaterial({ color: '#818cf8', wireframe: true, transparent: true, opacity: 0.4 });
    const ico1 = new THREE.Mesh(ico1Geo, ico1Mat);
    const ico2 = new THREE.Mesh(ico2Geo, ico2Mat);
    core.add(ico1, ico2);
    const coreHaloMat = new THREE.SpriteMaterial({ map: glow, color: '#8b5cf6', transparent: true, opacity: 0.8, blending: THREE.AdditiveBlending, depthWrite: false });
    const coreHalo = new THREE.Sprite(coreHaloMat);
    coreHalo.scale.setScalar(16);
    core.add(coreHalo);
    garbage.push(innerMat, shellMat, ico1Geo, ico2Geo, ico1Mat, ico2Mat, coreHaloMat);

    let coreTex = coreTexture(0);
    let coreShown = -1;
    const coreLabelMat = new THREE.SpriteMaterial({ map: coreTex, transparent: true, depthTest: false });
    const coreLabel = new THREE.Sprite(coreLabelMat);
    coreLabel.scale.set(5.6, 3.5, 1);
    coreLabel.renderOrder = 20;
    core.add(coreLabel);

    const rings: { g: THREE.Group; speed: number }[] = [];
    [
      { r: 5.4, tilt: [1.25, 0.2], c: '#c4b5fd', s: 0.35 },
      { r: 6.6, tilt: [0.5, -0.6], c: '#818cf8', s: -0.28 },
      { r: 7.8, tilt: [1.0, 1.1], c: '#f0abfc', s: 0.2 },
    ].forEach((cfg) => {
      const g = new THREE.Group();
      g.rotation.x = cfg.tilt[0]!;
      g.rotation.z = cfg.tilt[1]!;
      const spin = new THREE.Group();
      const geo = new THREE.TorusGeometry(cfg.r, 0.035, 6, 96);
      const mat = new THREE.MeshBasicMaterial({ color: cfg.c, transparent: true, opacity: 0.5 });
      const bead = new THREE.Mesh(sphereGeo, new THREE.MeshBasicMaterial({ color: cfg.c }));
      bead.scale.setScalar(0.17);
      bead.position.set(cfg.r, 0, 0);
      spin.add(new THREE.Mesh(geo, mat), bead);
      g.add(spin);
      core.add(g);
      garbage.push(geo, mat, bead.material as THREE.Material);
      rings.push({ g: spin, speed: cfg.s });
    });

    const shockGeo = new THREE.RingGeometry(0.96, 1, 72);
    garbage.push(shockGeo);
    const shocks = [0, 0.5].map(() => {
      const m = new THREE.Mesh(shockGeo, new THREE.MeshBasicMaterial({ color: '#a78bfa', transparent: true, opacity: 0, side: THREE.DoubleSide, depthWrite: false }));
      m.rotation.x = -Math.PI / 2;
      garbage.push(m.material as THREE.Material);
      scene.add(m);
      return m;
    });

    /* ---------- bots ---------- */
    const botsGroup = new THREE.Group();
    scene.add(botsGroup);
    const bots3 = new Map<string, BotObj>();
    let meshLines: THREE.LineSegments | null = null;

    const createBot = (bot: BrainBot, idx: number, total: number): BotObj => {
      const st = BOT_STYLE[bot.name] ?? { color: '#94a3b8', emoji: '🤖' };
      const color = new THREE.Color(st.color);
      const pos = botPos(bot.name, idx, total);
      const group = new THREE.Group();
      group.position.copy(pos);

      const body = new THREE.Mesh(
        sphereGeo,
        new THREE.MeshStandardMaterial({ color: color.clone().multiplyScalar(0.45), emissive: color, emissiveIntensity: 0.35, roughness: 0.3, metalness: 0.25 }),
      );
      group.add(body);

      const halo = new THREE.Sprite(new THREE.SpriteMaterial({ map: glow, color, transparent: true, opacity: 0.55, blending: THREE.AdditiveBlending, depthWrite: false }));
      group.add(halo);

      const emoji = new THREE.Sprite(new THREE.SpriteMaterial({ map: emojiTexture(st.emoji), transparent: true, depthTest: false }));
      emoji.renderOrder = 15;
      group.add(emoji);

      const label = new THREE.Sprite(new THREE.SpriteMaterial({ map: labelTexture(bot.name, 0, st.color, false), transparent: true, depthTest: false }));
      label.scale.set(7.2, 2.7, 1);
      label.renderOrder = 16;
      group.add(label);

      const bb = new THREE.Group();
      group.add(bb);
      const arc = new THREE.Mesh(arcGeometry(0.03), new THREE.MeshBasicMaterial({ color, transparent: true, opacity: 0.95 }));
      arc.rotation.z = Math.PI / 2;
      const base = new THREE.Mesh(baseRingGeo, new THREE.MeshBasicMaterial({ color, transparent: true, opacity: 0.2 }));
      bb.add(arc, base);
      const ripples = [0, 1].map(() => {
        const m = new THREE.Mesh(rippleGeo, new THREE.MeshBasicMaterial({ color, transparent: true, opacity: 0, side: THREE.DoubleSide, depthWrite: false }));
        m.visible = false;
        bb.add(m);
        return m;
      });

      const orb = new THREE.Group();
      orb.rotation.x = 0.5 + idx * 0.45;
      orb.rotation.z = idx * 0.7;
      const sat = new THREE.Mesh(sphereGeo, new THREE.MeshBasicMaterial({ color }));
      sat.scale.setScalar(0.15);
      orb.add(sat);
      group.add(orb);

      // wire to the brain: gradient tube along a gentle curve
      const sgn = idx % 2 ? 1 : -1;
      const ctrl = pos.clone().multiplyScalar(0.5);
      ctrl.y += sgn * 3;
      ctrl.x += -pos.z * 0.16 * sgn;
      ctrl.z += pos.x * 0.16 * sgn;
      const curve = new THREE.QuadraticBezierCurve3(pos.clone(), ctrl, new THREE.Vector3(0, 0, 0));
      const SEG = 40, RAD = 6;
      const tubeGeo = new THREE.TubeGeometry(curve, SEG, 0.07, RAD, false);
      const cols = new Float32Array(tubeGeo.attributes.position!.count * 3);
      const tmp = new THREE.Color();
      for (let v = 0; v < tubeGeo.attributes.position!.count; v++) {
        tmp.copy(color).lerp(VIOLET, Math.floor(v / (RAD + 1)) / SEG);
        cols[v * 3] = tmp.r;
        cols[v * 3 + 1] = tmp.g;
        cols[v * 3 + 2] = tmp.b;
      }
      tubeGeo.setAttribute('color', new THREE.BufferAttribute(cols, 3));
      const tube = new THREE.Mesh(tubeGeo, new THREE.MeshBasicMaterial({ vertexColors: true, transparent: true, opacity: 0.3, blending: THREE.AdditiveBlending, depthWrite: false }));
      scene.add(tube);

      const packets = Array.from({ length: 6 }, (_, k) => {
        const m = new THREE.Mesh(packetGeo, new THREE.MeshBasicMaterial({ color: k >= 4 ? '#ddd6fe' : color, transparent: true, opacity: 0, blending: THREE.AdditiveBlending, depthWrite: false }));
        m.visible = false;
        scene.add(m);
        return m;
      });

      botsGroup.add(group);
      return {
        id: bot.id, name: bot.name, color, hex: st.color, pos, group, bb, body, halo, emoji, label, arc, base, ripples, orb, sat, tube, curve, packets,
        r: 1.6, targetR: 1.6, count: -1, share: -1, labelKey: '', hotT: 0, hoverT: 0, phase: idx * 1.7,
      };
    };

    const disposeBot = (b: BotObj) => {
      botsGroup.remove(b.group);
      scene.remove(b.tube);
      b.packets.forEach((p) => { scene.remove(p); p.material.dispose(); });
      b.tube.geometry.dispose();
      b.tube.material.dispose();
      b.arc.geometry.dispose();
      b.arc.material.dispose();
      (b.base.material as THREE.Material).dispose();
      b.ripples.forEach((m) => m.material.dispose());
      (b.sat.material as THREE.Material).dispose();
      b.body.material.dispose();
      (b.halo.material as THREE.SpriteMaterial).dispose();
      const em = b.emoji.material as THREE.SpriteMaterial;
      em.map?.dispose();
      em.dispose();
      const lm = b.label.material as THREE.SpriteMaterial;
      lm.map?.dispose();
      lm.dispose();
    };

    const rebuildMesh = () => {
      if (meshLines) {
        scene.remove(meshLines);
        meshLines.geometry.dispose();
        (meshLines.material as THREE.Material).dispose();
        meshLines = null;
      }
      const list = [...bots3.values()].sort((p, q) => Math.atan2(p.pos.z, p.pos.x) - Math.atan2(q.pos.z, q.pos.x));
      if (list.length < 3) return;
      const pts: number[] = [];
      list.forEach((b, i) => {
        const n = list[(i + 1) % list.length]!;
        pts.push(b.pos.x, b.pos.y, b.pos.z, n.pos.x, n.pos.y, n.pos.z);
      });
      const g = new THREE.BufferGeometry();
      g.setAttribute('position', new THREE.Float32BufferAttribute(pts, 3));
      meshLines = new THREE.LineSegments(g, new THREE.LineBasicMaterial({ color: '#94a3b8', transparent: true, opacity: 0.13 }));
      scene.add(meshLines);
    };

    let seenVersion = -1;
    const sync = () => {
      const d = data.current;
      let changed = false;
      const ids = new Set<string>();
      d.nodes.forEach((n, i) => {
        ids.add(n.bot.id);
        let b = bots3.get(n.bot.id);
        if (!b) {
          b = createBot(n.bot, i, d.nodes.length);
          bots3.set(n.bot.id, b);
          changed = true;
        }
        const count = d.byBot[n.bot.id] ?? 0;
        b.targetR = 1.45 + Math.min(1.1, Math.sqrt(count) * 0.3);
        const share = count / d.maxN;
        if (b.share !== share) {
          b.share = share;
          b.arc.geometry.dispose();
          b.arc.geometry = arcGeometry(share);
        }
        b.count = count;
      });
      for (const [id, b] of bots3) {
        if (!ids.has(id)) {
          disposeBot(b);
          bots3.delete(id);
          changed = true;
        }
      }
      if (changed) rebuildMesh();
    };

    /* ---------- sizing ---------- */
    const fit = () => {
      const w = Math.max(1, box.clientWidth), h = Math.max(1, box.clientHeight);
      renderer.setSize(w, h, false);
      camera.aspect = w / h;
      const need = 17.5 / (Math.tan(THREE.MathUtils.degToRad(camera.fov / 2)) * camera.aspect);
      const dist = THREE.MathUtils.clamp(Math.max(28, need), 28, 60);
      camera.position.setLength(dist);
      camera.updateProjectionMatrix();
      renderOnce();
    };

    /* ---------- picking (hover on desktop, tap on touch) ---------- */
    const ray = new THREE.Raycaster();
    const ndc = new THREE.Vector2();
    const pick = (e: PointerEvent) => {
      const r = cv.getBoundingClientRect();
      ndc.set(((e.clientX - r.left) / r.width) * 2 - 1, -((e.clientY - r.top) / r.height) * 2 + 1);
      ray.setFromCamera(ndc, camera);
      const hit = ray.intersectObjects([...bots3.values()].map((b) => b.body), false)[0];
      if (!hit) return null;
      for (const b of bots3.values()) if (b.body === hit.object) return b.id;
      return null;
    };
    const setHover = (id: string | null) => {
      if (hoverRef.current === id) return;
      hoverRef.current = id;
      setHoverId(id);
      cv.style.cursor = id ? 'pointer' : 'grab';
    };
    cv.style.cursor = 'grab';
    const onMove = (e: PointerEvent) => {
      if (e.pointerType === 'mouse' && e.buttons === 0) setHover(pick(e));
    };
    const onLeave = () => setHover(null);
    let downAt = { x: 0, y: 0, t: 0 };
    const onDown = (e: PointerEvent) => { downAt = { x: e.clientX, y: e.clientY, t: performance.now() }; };
    const onUp = (e: PointerEvent) => {
      if (e.pointerType === 'mouse') return;
      if (Math.hypot(e.clientX - downAt.x, e.clientY - downAt.y) > 8 || performance.now() - downAt.t > 400) return;
      const id = pick(e);
      setHover(id && id !== hoverRef.current ? id : null);
    };
    cv.addEventListener('pointermove', onMove);
    cv.addEventListener('pointerleave', onLeave);
    cv.addEventListener('pointerdown', onDown);
    cv.addEventListener('pointerup', onUp);

    /* ---------- frame ---------- */
    const clock = new THREE.Clock();
    let raf = 0;
    let visible = true;
    let last = 0;
    const tmpV = new THREE.Vector3();

    const renderOnce = () => {
      if (REDUCED) {
        sync();
        controls.update();
        renderer.render(scene, camera);
      }
    };

    const frame = (now: number) => {
      raf = requestAnimationFrame(frame);
      if (!visible || document.hidden) return;
      if (COARSE && now - last < 24) return;
      const dt = Math.min(0.1, clock.getDelta());
      last = now;
      const t = clock.elapsedTime;
      const d = data.current;
      if (seenVersion !== d.version) {
        seenVersion = d.version;
        sync();
      }
      controls.update();

      // core
      ico1.rotation.y += dt * 0.35;
      ico1.rotation.x += dt * 0.12;
      ico2.rotation.y -= dt * 0.22;
      ico2.rotation.z += dt * 0.1;
      const pulse = 1 + Math.sin(t * 2.2) * 0.04;
      inner.scale.setScalar(2.3 * pulse);
      coreHalo.scale.setScalar(15 + Math.sin(t * 1.6) * 1.6);
      coreLight.intensity = 80 + Math.sin(t * 2.2) * 12;
      rings.forEach((r) => { r.g.rotation.y += dt * r.speed; });
      shocks.forEach((m, i) => {
        const p = frac(t / 3.4 + i * 0.5);
        m.scale.setScalar(4 + p * 12);
        m.material.opacity = (1 - p) * 0.32;
      });
      if (coreShown !== d.shown) {
        coreShown = d.shown;
        coreTex.dispose();
        coreTex = coreTexture(d.shown);
        coreLabelMat.map = coreTex;
        coreLabelMat.needsUpdate = true;
      }
      starGroup.rotation.y += dt * 0.012;

      // bots
      const anyHot = d.hot.size > 0;
      const camDist = camera.position.length();
      const k = Math.min(1, dt * 3.2);
      for (const b of bots3.values()) {
        const isHot = d.hot.has(b.id);
        b.hotT += ((isHot ? 1 : 0) - b.hotT) * k;
        b.hoverT += ((hoverRef.current === b.id ? 1 : 0) - b.hoverT) * k;
        b.r += (b.targetR - b.r) * k;
        const s = b.r * (1 + 0.22 * b.hoverT + Math.sin(t * 3 + b.phase) * 0.07 * b.hotT);
        b.body.scale.setScalar(s);
        b.body.material.emissiveIntensity = 0.3 + 0.7 * b.hotT + 0.35 * b.hoverT;
        b.halo.scale.setScalar(s * (4.6 + Math.sin(t * 1.8 + b.phase) * 0.5 + b.hotT * 1.6));
        (b.halo.material as THREE.SpriteMaterial).opacity = 0.38 + 0.4 * b.hotT + 0.2 * b.hoverT;
        b.bb.quaternion.copy(camera.quaternion);
        b.bb.scale.setScalar(s + 0.55);
        b.orb.rotation.y = t * (0.6 + (b.phase % 1) * 0.6) + b.phase;
        b.sat.position.set(s + 1.25, 0, 0);

        // depth cue: things on the far side of the brain fade a little
        tmpV.copy(b.group.position);
        const dist = camera.position.distanceTo(tmpV);
        const fade = THREE.MathUtils.clamp(1 - (dist - (camDist - RING_R)) / (RING_R * 2.4), 0.4, 1);
        const emMat = b.emoji.material as THREE.SpriteMaterial;
        const lbMat = b.label.material as THREE.SpriteMaterial;
        emMat.opacity = fade;
        lbMat.opacity = fade;
        b.emoji.scale.setScalar(s * 1.35);
        b.label.position.set(0, -(s + 1.9), 0);

        const key = `${b.count}|${b.hotT > 0.5 ? 1 : 0}`;
        if (key !== b.labelKey) {
          b.labelKey = key;
          lbMat.map?.dispose();
          lbMat.map = labelTexture(b.name, Math.max(0, b.count), b.hex, b.hotT > 0.5);
          lbMat.needsUpdate = true;
        }

        // wire + packets
        b.tube.material.opacity = 0.3 + 0.55 * b.hotT + 0.2 * b.hoverT;
        const [amb, c1, c2, c3, bc1, bc2] = b.packets as [THREE.Mesh, THREE.Mesh, THREE.Mesh, THREE.Mesh, THREE.Mesh, THREE.Mesh];
        const place = (m: THREE.Mesh, u: number, sc: number, op: number) => {
          b.curve.getPoint(Math.min(1, Math.max(0, u)), m.position);
          m.scale.setScalar(sc);
          (m.material as THREE.MeshBasicMaterial).opacity = op;
          m.visible = op > 0.02;
        };
        place(amb, frac(t * 0.11 + b.phase), 1, 0.75);
        [c1, c2, c3].forEach((m, i) => place(m, frac(t * 0.75 - i * 0.05), 2.2 - i * 0.6, b.hotT * (1 - i * 0.28)));
        const bcOn = anyHot && !isHot ? 1 : 0;
        [bc1, bc2].forEach((m, i) => place(m, 1 - frac(t * 0.5 - 0.35 - i * 0.045), 1.9 - i * 0.5, bcOn * (0.95 - i * 0.35)));

        // ripples when hot
        b.ripples.forEach((m, i) => {
          if (b.hotT < 0.05) { m.visible = false; return; }
          const p = frac(t / 1.4 + i * 0.5);
          m.visible = true;
          m.scale.setScalar(1.15 + p * 1.9);
          m.material.opacity = (1 - p) * 0.8 * b.hotT;
        });
      }
      renderer.render(scene, camera);
    };

    /* ---------- lifecycle ---------- */
    sync();
    const ro = new ResizeObserver(fit);
    ro.observe(box);
    fit();
    const io = new IntersectionObserver(([e]) => { visible = !!e?.isIntersecting; });
    io.observe(box);
    const onCtxLost = (e: Event) => {
      e.preventDefault();
      failRef.current?.();
    };
    cv.addEventListener('webglcontextlost', onCtxLost);
    let slow = 0;
    if (REDUCED) {
      // reduced motion: no animation loop, just redraw when the person orbits or the data changes
      controls.addEventListener('change', () => renderer.render(scene, camera));
      slow = window.setInterval(() => {
        if (seenVersion !== data.current.version) {
          seenVersion = data.current.version;
          renderOnce();
        }
      }, 1500);
    } else raf = requestAnimationFrame(frame);
    renderOnce();

    return () => {
      cancelAnimationFrame(raf);
      window.clearTimeout(resumeTimer);
      window.clearInterval(slow);
      ro.disconnect();
      io.disconnect();
      cv.removeEventListener('webglcontextlost', onCtxLost);
      cv.removeEventListener('pointermove', onMove);
      cv.removeEventListener('pointerleave', onLeave);
      cv.removeEventListener('pointerdown', onDown);
      cv.removeEventListener('pointerup', onUp);
      controls.dispose();
      for (const b of bots3.values()) disposeBot(b);
      bots3.clear();
      if (meshLines) {
        meshLines.geometry.dispose();
        (meshLines.material as THREE.Material).dispose();
      }
      shocks.forEach((m) => m.material.dispose());
      coreTex.dispose();
      coreLabelMat.dispose();
      garbage.forEach((g) => g.dispose());
      renderer.dispose();
      if (cv.parentElement === box) box.removeChild(cv);
    };
  }, []);

  const picked = hoverId ? nodes.find((n) => n.bot.id === hoverId)?.bot : undefined;
  const st = picked ? BOT_STYLE[picked.name] ?? { color: '#94a3b8', emoji: '🤖' } : undefined;

  return (
    <div className="bm-wrap">
      <div className="bm3-stage">
        <div ref={boxRef} className="bm3-canvas" aria-label="Interactive 3D Shared Brain map" role="img" />
        {picked && st && (
          <div className="bm3-info" style={{ borderColor: `${st.color}66` }}>
            <span className="bm3-info-emoji" style={{ background: `${st.color}26` }}>{st.emoji}</span>
            <div className="min-w-0">
              <p className="truncate text-sm font-bold" style={{ color: st.color }}>{picked.name}</p>
              <p className="truncate text-[11px] text-slate-400">{picked.role} · {picked.platform}</p>
              <p className="text-[11px] text-slate-300">{byBot[picked.id] ?? 0} lessons · {hot.has(picked.id) ? 'natututo ngayon' : picked.status}</p>
            </div>
          </div>
        )}
        <p className="bm3-hint">Hawakan at i-drag para iikot · pindutin ang bot para sa detalye</p>
      </div>
      <div className="bm-legend">
        <span className="bm-pill"><i className="bm-dot" style={{ background: '#a78bfa' }} />{active} active rules</span>
        <span className="bm-pill"><i className="bm-dot" style={{ background: '#38bdf8' }} />{nodes.length} bots connected</span>
        <span className={`bm-pill ${hotCount ? 'bm-pill-hot' : ''}`}>
          <i className={`bm-dot ${hotCount ? 'bm-dot-live' : ''}`} style={{ background: hotCount ? '#34d399' : '#64748b' }} />
          {hotCount ? `${hotCount} bot${hotCount === 1 ? '' : 's'} learning now` : 'Tahimik ang utak ngayon'}
        </span>
      </div>
    </div>
  );
}
