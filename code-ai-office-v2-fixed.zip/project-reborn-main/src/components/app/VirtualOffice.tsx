import { memo, useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Bot, Clock, Coffee, Gamepad2, Lightbulb, Moon, Pause, Play, Sun, Utensils, Wrench, X } from 'lucide-react';
import BossCommandPanel from './BossCommandPanel';
import type { AgentId } from '@/lib/app/agents';
import { AGENTS } from '@/lib/app/agents';
import type { AgentActivity } from '@/lib/app/useAgentActivity';
import Office3D from './Office3D';
import ReelStatusBar from './ReelStatusBar';
import { useReelStatus } from '@/lib/app/useReelJobs';
import { ARGUS, BOSS, IT_STAFF, MEAL_INFO, SECRETARY, useOfficeSim, type Idea, type IdeaReport, type Meal, type Phase, type Ticket } from '@/lib/app/office';

function statusMeta(status: string): { label: string; dot: string; text: string } {
  switch (status) {
    case 'posting':
      return { label: 'Posting', dot: 'bg-emerald-400', text: 'text-emerald-300' };
    case 'typing':
      return { label: 'Typing', dot: 'bg-sky-400', text: 'text-sky-300' };
    case 'thinking':
      return { label: 'Thinking', dot: 'bg-amber-400', text: 'text-amber-300' };
    case 'paused':
      return { label: 'Paused', dot: 'bg-slate-500', text: 'text-slate-400' };
    default:
      return { label: 'Idle / Resting', dot: 'bg-slate-500', text: 'text-slate-400' };
  }
}

function LiveClock() {
  const [now, setNow] = useState(() => new Date());
  useEffect(() => {
    const t = window.setInterval(() => setNow(new Date()), 1000);
    return () => window.clearInterval(t);
  }, []);
  return <>{now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })}</>;
}

const IdeaBoard = memo(function IdeaBoard({ ideas, inbox, report, phase, meal, tickets }: { ideas: Idea[]; inbox: Idea[]; report: IdeaReport | null; phase: Phase; meal: Meal | null; tickets: Ticket[] }) {
  const nameOf = (id: string) => (id === 'boss' ? BOSS.name : id === 'sec' ? SECRETARY.name : AGENTS.find((a) => a.id === id)?.name ?? id);
  const colorOf = (id: string) => AGENTS.find((a) => a.id === id)?.color ?? '#94a3b8';
  return (
    <div className="relative z-20 border-t border-white/[0.06] bg-[#0d1117]/80 px-4 py-3 sm:px-5">
      <div className="mb-2 flex flex-wrap items-center justify-between gap-x-3 gap-y-1">
        <h4 className="flex flex-wrap items-center gap-x-2 gap-y-0.5 text-xs font-semibold text-white">
          <Lightbulb className="h-3.5 w-3.5 text-violet-300" />
          Shared Brain Board
          <span className="font-normal text-slate-500">· natutunan ng bots → buod ni {SECRETARY.name} → aprubado ni {BOSS.name}</span>
        </h4>
        <span className="text-[11px] text-slate-500">
          {phase === 'work'
            ? 'Everyone is working'
            : phase === 'ideas'
              ? `${SECRETARY.name} ang nangongolekta ng idea…`
              : phase === 'meeting'
                ? 'Meeting sa Shared Brain…'
                : phase === 'meal' && meal
                  ? `${MEAL_INFO[meal].emoji} ${MEAL_INFO[meal].label} sa Canteen…`
                  : phase === 'arcade'
                    ? '🕹️ Arcade break — nagre-relax ang team…'
                    : phase === 'service'
                      ? `🛠️ ${IT_STAFF.name} ang umiikot — nag-aayos ng internet at computer…`
                      : 'Coffee break…'}
        </span>
      </div>
      {(inbox.length > 0 || report) && (
        <div className="mb-2 space-y-1.5">
          {inbox.length > 0 && (
            <p className="rounded-lg border border-violet-400/20 bg-violet-500/10 px-3 py-2 text-xs text-violet-200">
              📥 {inbox.length} idea{inbox.length > 1 ? 's' : ''} sa Shared Brain — hindi pa nababasa ni {SECRETARY.name}
            </p>
          )}
          {report && (
            <p className="rounded-lg border border-pink-400/25 bg-pink-500/10 px-3 py-2 text-xs text-pink-100">
              🗂️ <span className="font-semibold" style={{ color: SECRETARY.color }}>{SECRETARY.name}</span>: {report.summary}
              <span className="text-pink-200/70"> · iniulat kay {BOSS.name}, nagpatawag ng meeting</span>
            </p>
          )}
        </div>
      )}
      {tickets.length > 0 && (
        <div className="mb-2 rounded-lg border border-cyan-400/20 bg-cyan-500/10 px-3 py-2">
          <p className="mb-1 flex items-center gap-1.5 text-[11px] font-semibold text-cyan-200">
            <Wrench className="h-3 w-3" /> IT Tickets · inayos ni {IT_STAFF.name}
          </p>
          <ul className="space-y-0.5 text-[11px] text-cyan-100/90">
            {tickets.slice(0, 4).map((t) => (
              <li key={t.id}>
                ✅ <span className="font-semibold">{nameOf(t.who)}</span> — {t.kind === 'net' ? '📶 internet' : '🖥️ computer'}
                <span className="text-cyan-200/60"> · sanhi: {t.cause}</span>
              </li>
            ))}
          </ul>
        </div>
      )}
      {ideas.length === 0 ? (
        <p className="py-2 text-xs text-slate-500">Wala pang idea. Pindutin ang “Brainstorm” o hintayin ang next team meeting.</p>
      ) : (
        <ul className="grid gap-1.5 sm:grid-cols-2">
          {ideas.slice(0, 6).map((i) => (
            <li key={i.id} className="rounded-lg border border-white/[0.05] bg-white/[0.03] px-3 py-2 text-xs">
              <span className="font-semibold" style={{ color: colorOf(i.by) }}>{nameOf(i.by)}</span>
              <span className="text-slate-300"> — {i.text}</span>
              <p className="mt-0.5 text-[11px] text-amber-300/90">🗂️ {SECRETARY.name}: naitala sa plano · 👑 {BOSS.name}: {i.verdict}</p>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
});

/* ---------- main component ---------- */

export default function VirtualOffice({
  activity,
  isNight,
  paused,
  onPauseToggle,
}: {
  activity: Record<AgentId, AgentActivity>;
  isNight: boolean;
  paused: Record<string, boolean>;
  onPauseToggle: (id: AgentId) => void;
}) {
  const [selected, setSelected] = useState<AgentId | null>(null);
  const [drawerOpen, setDrawerOpen] = useState(false);
  const [bossOpen, setBossOpen] = useState(false);

  useEffect(() => {
    if (selected && !AGENTS.find((a) => a.id === selected)) setSelected(null);
  }, [selected]);

  const openDrawer = (id: AgentId) => {
    setSelected(id);
    setDrawerOpen(true);
  };

  const sim = useOfficeSim(paused);
  const reel = useReelStatus();

  return (
    <div className="surface relative overflow-hidden rounded-2xl bg-gradient-to-b from-[#0e1420] to-[#0b0e14] sm:rounded-xl">
      {/* ambience tint: two static layers that cross-fade with opacity (cheap), and only on larger screens */}
      <div
        className="pointer-events-none absolute inset-0 z-10 hidden transition-opacity duration-[2500ms] sm:block"
        style={{ opacity: isNight ? 0 : 1, background: 'linear-gradient(180deg, rgba(251,191,36,0.07), rgba(11,14,20,0.2))' }}
      />
      <div
        className="pointer-events-none absolute inset-0 z-10 hidden transition-opacity duration-[2500ms] sm:block"
        style={{ opacity: isNight ? 1 : 0, background: 'linear-gradient(180deg, rgba(30,58,138,0.12), rgba(11,14,20,0.55))' }}
      />

      {/* header */}
      <div className="relative z-20 flex flex-col gap-3 border-b border-white/[0.06] px-4 py-3 sm:px-5 lg:flex-row lg:items-center lg:justify-between">
        <div className="flex min-w-0 items-center gap-2.5">
          <span className="shrink-0 rounded-lg bg-emerald-500/15 p-2 text-emerald-400">
            <Bot className="h-4 w-4" />
          </span>
          <div className="min-w-0">
            <h3 className="text-sm font-semibold text-white">24/7 Virtual AI Office Headquarters</h3>
            <p className="text-[11px] text-slate-500 sm:hidden">Tap a bot para makita ang detalye nito</p>
            <p className="hidden text-[11px] text-slate-500 sm:block">Click a bot to inspect it · {BOSS.name} the Boss · 🗂️ {SECRETARY.name} ang secretary · 🛠️ Fixo ang maintenance · 🖥️ {IT_STAFF.name} ang IT · 👁️ {ARGUS.name} ang Watchdog</p>
            <p className="hidden text-[11px] text-slate-500 sm:block">
              🍽️ Kainan: {MEAL_INFO.breakfast.time} almusal · {MEAL_INFO.lunch.time} tanghalian · {MEAL_INFO.dinner.time} hapunan
            </p>
          </div>
        </div>
        <div className="grid grid-cols-2 gap-2 sm:flex sm:flex-wrap sm:items-center sm:gap-3 lg:justify-end">
          <button
            type="button"
            onClick={() => setBossOpen(true)}
            className="col-span-2 flex min-h-[44px] items-center justify-center gap-1.5 sm:col-span-1 sm:min-h-[36px] rounded-full border border-amber-400/40 bg-amber-500/15 px-3 py-1 text-xs font-semibold text-amber-200 transition-colors hover:bg-amber-500/25"
          >
            <span aria-hidden>📞</span> Tawagan si Boss
          </button>
          <button
            type="button"
            onClick={() => sim.trigger('brainstorm')}
            disabled={sim.phase !== 'work'}
            className="flex min-h-[44px] items-center justify-center gap-1.5 sm:min-h-[36px] rounded-full border border-violet-400/30 bg-violet-500/10 px-3 py-1 text-xs font-medium text-violet-300 transition-colors hover:bg-violet-500/20 disabled:opacity-40"
          >
            <Lightbulb className="h-3.5 w-3.5" /> Brainstorm
          </button>
          <button
            type="button"
            onClick={() => sim.trigger('coffee')}
            disabled={sim.phase !== 'work'}
            className="flex min-h-[44px] items-center justify-center gap-1.5 sm:min-h-[36px] rounded-full border border-orange-400/30 bg-orange-500/10 px-3 py-1 text-xs font-medium text-orange-300 transition-colors hover:bg-orange-500/20 disabled:opacity-40"
          >
            <Coffee className="h-3.5 w-3.5" /> Coffee Break
          </button>
          <button
            type="button"
            onClick={() => sim.trigger('meal')}
            disabled={sim.phase !== 'work'}
            className="flex min-h-[44px] items-center justify-center gap-1.5 sm:min-h-[36px] rounded-full border border-amber-400/30 bg-amber-500/10 px-3 py-1 text-xs font-medium text-amber-300 transition-colors hover:bg-amber-500/20 disabled:opacity-40"
          >
            <Utensils className="h-3.5 w-3.5" /> Kainan
          </button>
          <button
            type="button"
            onClick={() => sim.trigger('arcade')}
            disabled={sim.phase !== 'work'}
            className="flex min-h-[44px] items-center justify-center gap-1.5 sm:min-h-[36px] rounded-full border border-fuchsia-400/30 bg-fuchsia-500/10 px-3 py-1 text-xs font-medium text-fuchsia-300 transition-colors hover:bg-fuchsia-500/20 disabled:opacity-40"
          >
            <Gamepad2 className="h-3.5 w-3.5" /> Arcade
          </button>
          <button
            type="button"
            onClick={() => sim.trigger('service')}
            disabled={sim.phase !== 'work'}
            className="flex min-h-[44px] items-center justify-center gap-1.5 sm:min-h-[36px] rounded-full border border-cyan-400/30 bg-cyan-500/10 px-3 py-1 text-xs font-medium text-cyan-300 transition-colors hover:bg-cyan-500/20 disabled:opacity-40"
          >
            <Wrench className="h-3.5 w-3.5" /> IT Support
          </button>
          <motion.div
            key={isNight ? 'night' : 'day'}
            initial={{ opacity: 0, rotate: -30 }}
            animate={{ opacity: 1, rotate: 0 }}
            className={`flex min-h-[44px] items-center justify-center gap-1.5 rounded-full border px-3 py-1 text-xs font-medium sm:min-h-0 ${
              isNight
                ? 'border-indigo-500/30 bg-indigo-500/10 text-indigo-300'
                : 'border-amber-500/30 bg-amber-500/10 text-amber-300'
            }`}
          >
            {isNight ? <Moon className="h-3.5 w-3.5" /> : <Sun className="h-3.5 w-3.5" />}
            {isNight ? 'Night Shift' : 'Day Shift'}
          </motion.div>
          <div className="col-span-2 flex min-h-[44px] items-center justify-center gap-1.5 rounded-full border border-white/[0.08] bg-white/[0.04] px-3 py-1 font-mono sm:col-span-1 text-xs text-white sm:min-h-0">
            <Clock className="h-3.5 w-3.5 text-slate-400" />
            <LiveClock />
          </div>
        </div>
      </div>

      {/* office floor */}
      <div className="relative h-[min(66svh,520px)] min-h-[360px] w-full sm:aspect-[1100/820] sm:h-auto sm:min-h-[340px]">
        <Office3D
          activity={activity}
          places={sim.places}
          speech={sim.speech}
          phase={sim.phase}
          itTarget={sim.itTarget}
          broken={sim.broken}
          routine={sim.routine}
          argus={sim.argusRoutine}
          reel={reel}
          callout={sim.callout}
          isNight={isNight}
          onSelect={openDrawer}
          onBossClick={() => sim.trigger('brainstorm')}
          onBossTalk={() => setBossOpen(true)}
        />
      </div>

      <ReelStatusBar />

      <IdeaBoard ideas={sim.ideas} inbox={sim.inbox} report={sim.report} phase={sim.phase} meal={sim.meal} tickets={sim.tickets} />

      <BossCommandPanel open={bossOpen} onClose={() => setBossOpen(false)} steps={sim.cmdSteps} onSend={sim.sendCommand} onBossSay={sim.bossSay} onAfterCall={sim.runAfterCall}
        statusText={AGENTS.map((a) => `${a.name} (${a.role}): ${paused[a.id] ? 'paused' : activity[a.id].status}, ${activity[a.id].bubble}, ${activity[a.id].actions} actions today`).join('\n') + `\nOffice phase: ${sim.phase}`}
      />

      {/* inspector drawer */}
      <AnimatePresence>
        {drawerOpen && selected && (
          <>
            <motion.div
              className="fixed inset-0 z-[60] bg-black/60"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setDrawerOpen(false)}
            />
            <motion.div
              className="fixed right-0 top-0 z-[70] flex w-full max-w-sm flex-col border-l border-white/[0.08] bg-[#141821] shadow-2xl"
              style={{ height: 'calc(100dvh / var(--ui-zoom, 1))', paddingTop: 'env(safe-area-inset-top)', paddingBottom: 'env(safe-area-inset-bottom)', paddingRight: 'env(safe-area-inset-right)' }}
              initial={{ x: '100%' }}
              animate={{ x: 0 }}
              exit={{ x: '100%' }}
              transition={{ type: 'spring', stiffness: 300, damping: 30 }}
            >
              {(() => {
                const agent = AGENTS.find((a) => a.id === selected)!;
                const act = activity[selected];
                const meta = statusMeta(act.status);
                return (
                  <>
                    <div className="flex items-start justify-between border-b border-white/[0.06] px-5 py-4">
                      <div className="flex min-w-0 items-center gap-3">
                        <span
                          className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl text-lg font-bold"
                          style={{ backgroundColor: `${agent.color}22`, color: agent.color }}
                        >
                          {agent.name[0]}
                        </span>
                        <div>
                          <h4 className="font-semibold text-white">{agent.name}</h4>
                          <p className="text-xs text-slate-400">{agent.role}</p>
                        </div>
                      </div>
                      <button
                        type="button"
                        onClick={() => setDrawerOpen(false)}
                        className="flex h-11 w-11 shrink-0 items-center justify-center rounded-lg text-slate-400 hover:bg-white/[0.06] hover:text-white"
                        aria-label="Close inspector"
                      >
                        <X className="h-4 w-4" />
                      </button>
                    </div>

                    <div className="flex-1 space-y-4 overflow-y-auto p-5">
                      <div className="flex items-center gap-2 rounded-lg bg-white/[0.04] px-3 py-2.5">
                        <span className={`h-2 w-2 rounded-full ${meta.dot} ${act.status !== 'idle' ? 'animate-pulse' : ''}`} />
                        <span className={`text-sm font-medium ${meta.text}`}>{meta.label}</span>
                      </div>

                      <div>
                        <p className="mb-1.5 text-xs font-medium text-slate-400">Current Task</p>
                        <p className="rounded-lg bg-white/[0.03] px-3 py-2.5 text-sm leading-relaxed text-slate-200">
                          {act.bubble}
                        </p>
                      </div>

                      <div>
                        <p className="mb-1.5 text-xs font-medium text-slate-400">Completed Actions Today</p>
                        <p className="text-3xl font-bold text-white">{act.actions}</p>
                      </div>

                      <div>
                        <p className="mb-1.5 text-xs font-medium text-slate-400">Task Queue</p>
                        <ul className="space-y-1.5 text-xs text-slate-400">
                          {agent.sources.map((s) => (
                            <li key={s} className="flex items-center gap-2 rounded-lg bg-white/[0.03] px-3 py-2">
                              <span className="h-1 w-1 rounded-full" style={{ backgroundColor: agent.color }} />
                              Listening to <span className="font-mono text-slate-300">{s}</span> events
                            </li>
                          ))}
                        </ul>
                      </div>
                    </div>

                    <div className="border-t border-white/[0.06] p-5">
                      <button
                        type="button"
                        onClick={() => onPauseToggle(agent.id)}
                        className={`flex min-h-[48px] w-full items-center justify-center gap-2 rounded-lg px-4 py-2.5 text-sm font-semibold transition-colors ${
                          paused[agent.id]
                            ? 'bg-emerald-500 text-emerald-950 hover:bg-emerald-400'
                            : 'bg-white/[0.08] text-slate-200 hover:bg-white/[0.14]'
                        }`}
                      >
                        {paused[agent.id] ? <Play className="h-4 w-4" /> : <Pause className="h-4 w-4" />}
                        {paused[agent.id] ? 'Resume Agent' : 'Pause Agent'}
                      </button>
                    </div>
                  </>
                );
              })()}
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </div>
  );
}
