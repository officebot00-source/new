import { useEffect, useRef, useState } from 'react';
import { Copy, FlaskConical, Save, Send, Sparkles, Wand2, Zap } from 'lucide-react';
import type { Game, Platform, Tone } from '@/lib/app/types';
import { PLATFORMS, TONES } from '@/lib/app/types';
import { db, type SavedCopyRow } from '@/lib/app/db';
import { generatePost } from '@/lib/app/generator';
import { canPublishLive, publishNow } from '@/lib/app/publish';
import { createExperiment, newCampaignId, newVariant, trackingUrl, type VariantKey } from '@/lib/app/ab';
import { Button, Card, EmptyState, PageHero, Select, TextArea, Toggle } from './ui-kit';
import PhonePreview from './PhonePreview';
import { getPasscode, LOCK_EVENT, serverCapabilities, setPasscode } from '@/lib/app/publish';
import { botApiHost, botFnUrl } from '@/lib/app/supabase';
import { ALL_GAMES, applyGameLinks, buildAllGamesPost, linkedGames } from '@/lib/app/studioLinks';

type Copy2 = { content: string; hashtags: string };

async function generateWithApi(
  game: Game,
  platform: Platform,
  tone: Tone
): Promise<{ content: string; hashtags: string } | 'no_key'> {
  const url = botFnUrl('generate-post');
  const res = await fetch(url, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'x-app-passcode': getPasscode(),
    },
    body: JSON.stringify({
      game: {
        title: game.title,
        genre: game.genre,
        description: game.description,
        promo_link: game.promo_link,
      },
      platform,
      tone,
    }),
  });
  if (res.status === 401) {
    setPasscode('');
    window.dispatchEvent(new Event(LOCK_EVENT));
    throw new Error('Wrong or missing password.');
  }
  if (res.status === 503) return 'no_key';
  if (!res.ok) {
    const e = await res.json().catch(() => null);
    throw new Error(e?.error ? `AI: ${e.error}` : `AI request failed (${res.status})`);
  }
  const data = await res.json();
  if (typeof data.content !== 'string' || typeof data.hashtags !== 'string') {
    throw new Error('AI response was not in the expected format');
  }
  return { content: data.content, hashtags: data.hashtags };
}

function toLocalInput(d: Date) {
  const pad = (n: number) => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}`;
}

// Device backup of the Save button: if the server refuses or is offline, the edit is still kept here and re-synced later.
const LOCAL_KEY = 'studio_copy_backup';
const WHEN_KEY = 'studio_schedule_when';
type LocalCopies = Record<string, { content: string; hashtags: string }>;
const readLocal = (): LocalCopies => { try { return JSON.parse(localStorage.getItem(LOCAL_KEY) ?? '{}') as LocalCopies; } catch { return {}; } };
const writeLocal = (key: string, v: { content: string; hashtags: string } | null) => {
  try {
    const all = readLocal();
    if (v) all[key] = v; else delete all[key];
    localStorage.setItem(LOCAL_KEY, JSON.stringify(all));
  } catch { /* storage full / blocked — nothing else to do */ }
};
const copyKey = (g: string, c: string, h: string) => `${g}\u0000${c}\u0000${h}`;
type SaveState = 'idle' | 'saving' | 'saved' | 'local';

export default function ContentStudio({ onQueued }: { onQueued: () => void }) {
  const [games, setGames] = useState<Game[]>([]);
  const [gameId, setGameId] = useState('');
  const [tone, setTone] = useState<Tone>('hype');
  const [platforms, setPlatforms] = useState<Platform[]>(['twitter']);
  const [content, setContent] = useState('');
  const [hashtags, setHashtags] = useState('');
  const [when, setWhen] = useState(() => {
    // the chosen schedule time is remembered — only reused while it is still in the future
    try {
      const v = localStorage.getItem(WHEN_KEY);
      if (v && new Date(v).getTime() > Date.now() + 60_000) return v;
    } catch { /* ignore */ }
    return toLocalInput(new Date(Date.now() + 3600_000));
  });
  useEffect(() => { try { localStorage.setItem(WHEN_KEY, when); } catch { /* ignore */ } }, [when]);
  const [generating, setGenerating] = useState(false);
  const [msg, setMsg] = useState('');
  const [abOn, setAbOn] = useState(false);
  const [ab, setAb] = useState<Record<VariantKey, Copy2> | null>(null);
  const [previewKey, setPreviewKey] = useState<VariantKey>('a');
  const [campaignId, setCampaignId] = useState('');

  useEffect(() => {
    db.listGames()
      .then((g) => {
        setGames(g);
        if (g.length > 0) setGameId((prev) => prev || g[0].id);
      })
      .catch((err) => setMsg(err instanceof Error ? err.message : 'Failed to load games'));
  }, []);

  const allMode = gameId === ALL_GAMES;
  const activeGames = games.filter((g) => g.active !== false);
  // In "All Games" mode a virtual game represents every saved game
  const game: Game | undefined = allMode
    ? {
        id: ALL_GAMES,
        title: 'All Games',
        genre: '',
        description: '',
        promo_link: linkedGames(activeGames)[0]?.promo_link ?? '',
        banner_image: '',
        active: true,
        created_at: '',
      }
    : games.find((g) => g.id === gameId);
  const linkTargets: Game[] = allMode ? activeGames : game ? [game] : [];
  const [savedNote, setSavedNote] = useState('');
  // saved copies live in the database (Supabase) so they are the same on every device
  const [saved, setSaved] = useState<Record<string, SavedCopyRow>>({});
  const [savedLoaded, setSavedLoaded] = useState(false);

  useEffect(() => {
    db.listSavedCopies()
      .then((rows) => setSaved(Object.fromEntries(rows.map((r) => [r.copy_key, r]))))
      .catch((err) => setMsg(err instanceof Error ? err.message : 'Failed to load saved copies'))
      .finally(() => setSavedLoaded(true));
  }, []);

  const savedRef = useRef(saved);
  savedRef.current = saved;
  const baselineRef = useRef('');
  const chainRef = useRef<Promise<unknown>>(Promise.resolve());
  const [saveState, setSaveState] = useState<SaveState>('idle');

  /** Finds out WHY the server refused: old server code, or something else. */
  const diagnose = async (m: string) => {
    const onLovable = /lovable\.app$/i.test(botApiHost);
    try {
      const caps = await serverCapabilities();
      setSavedNote(caps.tables.includes('studio_saved_copy')
        ? `Na-save sa device. Bago na ang server code (${botApiHost}) pero tinanggihan pa rin ang Save: ${m}`
        : `Na-save sa device. Lumang bersyon ng server code ang sumasagot sa ${botApiHost} — walang "studio_saved_copy" doon.`);
    } catch (e) {
      const em = e instanceof Error ? e.message : '';
      setSavedNote(/not allowed|unknown|403|400/i.test(em)
        ? `Na-save sa device. LUMANG bersyon ng server code ang sumasagot sa ${botApiHost}. ${onLovable
            ? 'Ang app na ito ay nakaturo sa Lovable site — hindi sapat ang redeploy sa Netlify/GitHub. Sa Lovable, pindutin ang Publish → Update para magamit ang bagong admin-db.'
            : 'I-deploy ang bagong code sa site na iyon.'}`
        : `Na-save sa device. Hindi maabot ang server (${botApiHost}): ${em}`);
    }
  };

  /** Writes one copy to the database. Calls are queued one after another so a fast second edit can never insert a duplicate row. */
  const persist = (key: string, c: string, h: string): Promise<boolean> => {
    const run = async (): Promise<boolean> => {
      setSaveState('saving');
      try {
        const id = await db.saveSavedCopy(key, c, h, savedRef.current[key]?.id);
        setSaved((prev) => ({ ...prev, [key]: { id, copy_key: key, content: c, hashtags: h } }));
        savedRef.current = { ...savedRef.current, [key]: { id, copy_key: key, content: c, hashtags: h } };
        writeLocal(key, null);
        setSaveState('saved');
        setSavedNote('');
        return true;
      } catch (err) {
        writeLocal(key, { content: c, hashtags: h });
        setSaveState('local');
        const m = err instanceof Error ? err.message : '';
        setSavedNote(`Na-save sa device na ito, pero hindi pa nakarating sa server. (${m || 'Could not save'}) Sinusuri ang server…`);
        void diagnose(m);
        return false;
      }
    };
    const p = chainRef.current.then(run, run);
    chainRef.current = p;
    return p;
  };

  // Load the copy whenever the game changes: the user's saved wording if there is one, otherwise a ready-made copy.
  // Game links ALWAYS come from the Games button, so nothing has to be edited by hand.
  useEffect(() => {
    if (!savedLoaded || !gameId) return;
    const local = readLocal()[gameId];
    const s0 = local ?? saved[gameId];
    let c = '';
    let h = '';
    if (s0) {
      c = applyGameLinks(s0.content, linkTargets);
      h = s0.hashtags;
      setSavedNote(local ? 'Na-restore ang huling edit mo (hindi pa naka-sync sa server).' : 'Saved copy loaded — links refreshed from your Games.');
      baselineRef.current = local ? '' : copyKey(gameId, c, h); // unsynced local edits get pushed to the server by the auto-save
    } else if (allMode) {
      const r = buildAllGamesPost(activeGames);
      c = r.content;
      h = r.hashtags;
      setSavedNote('Auto: lahat ng laro + ang link ng bawat isa galing sa Games button.');
      baselineRef.current = copyKey(gameId, c, h);
    } else if (game) {
      const r = generatePost(game, platforms[0], tone);
      c = applyGameLinks(r.content, [game]);
      h = r.hashtags;
      setSavedNote('');
      baselineRef.current = copyKey(gameId, c, h);
    }
    setContent(c);
    setHashtags(h);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [gameId, games.length, savedLoaded]);

  // The Save button still works, but it is no longer needed: every edit is saved by itself ~1 second after you stop typing.
  const saveDraft = async () => {
    if (!gameId) return;
    const c = showAb ? ab![previewKey].content : content;
    const h = showAb ? ab![previewKey].hashtags : hashtags;
    baselineRef.current = copyKey(gameId, c, h);
    await persist(gameId, c, h);
  };
  const forgetDraft = async () => {
    writeLocal(gameId, null);
    const row = gameId ? saved[gameId] : undefined;
    if (!row) {
      setSavedNote('Walang saved copy dito.');
      return;
    }
    try {
      await db.deleteSavedCopy(row.id);
      setSaved((prev) => {
        const { [gameId]: _drop, ...rest } = prev;
        return rest;
      });
      setSavedNote('Saved copy cleared.');
    } catch (err) {
      setSavedNote(err instanceof Error ? err.message : 'Could not clear.');
    }
  };

  const togglePlatform = (p: Platform) => {
    setPlatforms((prev) => (prev.includes(p) ? prev.filter((x) => x !== p) : [...prev, p]));
  };

  const showAb = abOn && ab !== null;
  const curContent = showAb ? ab![previewKey].content : content;
  const curTags = showAb ? ab![previewKey].hashtags : hashtags;
  const hasCopy = showAb || content !== '';
  // AUTO-SAVE: edits to the post copy are saved on their own (debounced), so there is nothing to press and nothing to lose.
  useEffect(() => {
    if (!savedLoaded || !gameId || showAb || !content.trim()) return undefined;
    const k = copyKey(gameId, content, hashtags);
    if (k === baselineRef.current) return undefined;
    setSaveState('saving');
    const t = window.setTimeout(() => {
      baselineRef.current = k;
      void persist(gameId, content, hashtags);
    }, 1000);
    return () => window.clearTimeout(t);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [gameId, content, hashtags, savedLoaded, showAb]);

  const editVariant = (k: VariantKey, patch: Partial<Copy2>) =>
    setAb((prev) => (prev ? { ...prev, [k]: { ...prev[k], ...patch } } : prev));
  const previewPlatform = platforms[0] === 'discord' ? 'discord' : platforms[0] === 'telegram' ? 'telegram' : 'facebook';
  const previewLink = showAb && campaignId ? trackingUrl(campaignId, previewKey) : game?.promo_link ?? '';

  const generateAb = async () => {
    if (!game) return;
    const id = newCampaignId();
    setCampaignId(id);
    setGenerating(true);
    setMsg('');
    await db.log('info', 'ai-studio', `Drafting Variant A & B hooks for ${game.title}...`);
    await new Promise((r) => setTimeout(r, 700));
    const mk = (k: VariantKey, t: Tone): Copy2 => {
      const g = generatePost(game, platforms[0], t);
      const url = trackingUrl(id, k);
      const base = allMode ? buildAllGamesPost(activeGames).content : g.content;
      const text = game.promo_link && base.includes(game.promo_link) ? base.replace(game.promo_link, url) : `${base}\n${url}`;
      return { content: text, hashtags: g.hashtags };
    };
    setAb({ a: mk('a', 'fomo'), b: mk('b', 'competitive') });
    setPreviewKey('a');
    await db.log('success', 'ai-studio', `Aria drafted Variant A (Hype/FOMO) and Variant B (Competitive/Curiosity) for ${game.title}`);
    setGenerating(false);
  };

  const generate = async () => {
    if (!game) {
      setMsg('Add a game profile first.');
      return;
    }
    if (platforms.length === 0) {
      setMsg('Pick at least one platform.');
      return;
    }
    if (abOn) {
      await generateAb();
      return;
    }
    setGenerating(true);
    setMsg('');
    let result: { content: string; hashtags: string };
    if (allMode) {
      // Automatic: every saved game + every link, no picking, no editing
      const savedAll = saved[ALL_GAMES];
      result = savedAll
        ? { content: applyGameLinks(savedAll.content, activeGames), hashtags: savedAll.hashtags }
        : buildAllGamesPost(activeGames);
      await db.log('success', 'ai-studio', `Aria drafted one post covering all ${activeGames.length} saved games (links included)`);
      setContent(result.content);
      setHashtags(result.hashtags);
      setGenerating(false);
      return;
    }
    const savedOne = saved[gameId];
    if (savedOne) {
      // your saved wording wins — links are refreshed from the Games button. (Press "Clear saved" for a brand-new AI copy.)
      setContent(applyGameLinks(savedOne.content, linkTargets));
      setHashtags(savedOne.hashtags);
      setSavedNote('Gamit ang saved copy mo (links galing sa Games). Pindutin ang "Clear saved" kung gusto mo ng bagong AI copy.');
      setGenerating(false);
      return;
    }
    try {
      const apiResult = await generateWithApi(game, platforms[0], tone);
      if (apiResult === 'no_key') {
        await new Promise((r) => setTimeout(r, 600));
        result = generatePost(game, platforms[0], tone);
        await db.log(
          'warning',
          'ai-studio',
          'No Gemini/OpenAI key configured yet — used the built-in template generator instead'
        );
        setMsg('Using built-in templates. Add your Gemini or OpenAI key (see API Settings) for real AI posts.');
      } else {
        result = apiResult;
        await db.log('success', 'ai-studio', `AI (Gemini) generated a ${tone} post for ${game.title}`);
      }
    } catch (err) {
      result = generatePost(game, platforms[0], tone);
      await db.log(
        'error',
        'ai-studio',
        `AI request failed — fell back to templates (${err instanceof Error ? err.message : 'unknown error'})`
      );
      setMsg('The AI service could not be reached, so a template post was used instead.');
    }
    setContent(applyGameLinks(result.content, linkTargets));
    setHashtags(result.hashtags);
    setGenerating(false);
  };

  /** Saves the post(s) and, when asked to post now (or the time is already here), publishes them live right away. */
  const queue = async (postNow = false) => {
    if (!game || !hasCopy) return;
    const scheduledAt = postNow ? new Date() : new Date(when);
    if (Number.isNaN(scheduledAt.getTime())) {
      setMsg('Pick a valid date and time.');
      return;
    }
    if (platforms.length === 0) {
      setMsg('Pick at least one platform.');
      return;
    }
    const goLive = postNow || scheduledAt.getTime() <= Date.now() + 60_000;
    const base = { game_id: allMode ? null : game.id, game_title: game.title, platforms, tone, status: 'scheduled' as const };
    try {
      const ids: string[] = [];
      if (showAb) {
        for (const k of ['a', 'b'] as VariantKey[]) {
          // Variant B goes out 30 minutes after A, unless it is a "post now" command (then both go out now).
          const at = new Date(scheduledAt.getTime() + (k === 'b' && !postNow ? 30 * 60_000 : 0));
          ids.push(await db.savePost({ ...base, content: ab![k].content, hashtags: ab![k].hashtags, scheduled_at: at.toISOString() }));
        }
        createExperiment(
          campaignId || newCampaignId(), game.title, game.promo_link,
          newVariant('a', 'Hype & FOMO', ab!.a.content, ab!.a.hashtags),
          newVariant('b', 'Competitive / Curiosity', ab!.b.content, ab!.b.hashtags)
        );
        await db.log('success', 'auto-poster', `Aria handed A/B test for ${game.title} to Blaze — publishing Variant A & B (tracking /go/${campaignId}/a|b)`);
        setAb(null);
      } else {
        ids.push(await db.savePost({ ...base, content: applyGameLinks(content, linkTargets), hashtags, scheduled_at: scheduledAt.toISOString() }));
        await db.log('success', 'auto-poster', `Aria handed "${game.title}" post to Blaze — ${goLive ? 'publishing now' : `queued for ${scheduledAt.toLocaleString()}`}`);
        setContent('');
        setHashtags('');
      }
      if (goLive && canPublishLive) {
        setMsg('Blaze is posting live…');
        const { results } = await publishNow(ids.filter(Boolean));
        const ok = results.filter((r) => r.status === 'published');
        const bad = results.filter((r) => r.status === 'failed');
        const link = ok.flatMap((r) => r.sent ?? []).find((x) => x.url)?.url;
        setMsg(
          bad.length
            ? `Failed: ${bad.flatMap((r) => r.errors ?? []).join('; ')}`
            : `Posted live to ${[...new Set(ok.flatMap((r) => (r.sent ?? []).map((x) => x.platform)))].join(', ')}!${link ? ` ${link}` : ''}`
        );
      } else if (goLive) {
        setMsg('Saved, but this build is in simulation mode — nothing was posted for real (needs Supabase).');
      } else {
        setMsg('Approved! Blaze has the post in the queue and will publish it at the scheduled time.');
      }
      onQueued();
    } catch (err) {
      setMsg(err instanceof Error ? err.message : 'Failed to queue post');
    }
  };

  if (games.length === 0) {
    return (
      <Card>
        <EmptyState
          icon={<Wand2 className="h-10 w-10" />}
          title="No game profiles yet"
          subtitle="Add a game in Game Profiles first — the AI needs something to promote."
        />
      </Card>
    );
  }

  return (
    <div className="space-y-5">
    <PageHero
      icon={Sparkles} accent="violet" title="AI Content Studio"
      subtitle="Gumawa ng captions, hooks at hashtags na bagay sa bawat platform, i-preview sa phone, at i-schedule o i-post agad."
      chip={canPublishLive ? { label: 'Live — nagpo-post sa totoong accounts', tone: 'live' } : { label: 'Simulation mode', tone: 'warn' }}
      stats={[
        { label: 'Active na laro', value: activeGames.length },
        { label: 'Lahat ng laro', value: games.length },
      ]}
    />
    <div className="grid grid-cols-1 gap-5 lg:grid-cols-5">
      <Card className="p-5 lg:col-span-2">
        <h3 className="text-sm font-semibold text-white">Generator</h3>
        <p className="mt-0.5 text-xs text-slate-400">Pumili ng laro at tone, tapos pindutin ang Generate.</p>

        <div className="mt-4 space-y-4">
          <Select
            label="Game"
            value={gameId}
            onChange={setGameId}
            options={[{ value: ALL_GAMES, label: '⭐ All Games (auto — every saved game + links)' }, ...games.map((g) => ({ value: g.id, label: g.title }))]}
          />

          <Button
            variant={allMode ? 'primary' : 'secondary'}
            className="w-full"
            onClick={() => { setGameId(ALL_GAMES); }}
          >
            <Sparkles className="h-4 w-4" /> All Games ({activeGames.length}) — auto post lahat
          </Button>

          <div>
            <span className="mb-1.5 block text-xs font-medium text-slate-400">Tone</span>
            <div className="grid grid-cols-2 gap-2">
              {TONES.map((t) => (
                <button
                  key={t.id}
                  type="button"
                  onClick={() => setTone(t.id)}
                  className={`rounded-lg border px-3 py-2 text-left text-xs transition-colors ${
                    tone === t.id
                      ? 'border-emerald-500/60 bg-emerald-500/10 text-emerald-300'
                      : 'border-white/[0.08] bg-white/[0.03] text-slate-400 hover:border-white/[0.2]'
                  }`}
                >
                  <span className="block font-semibold">{t.label}</span>
                  <span className="mt-0.5 block text-[10px] leading-snug opacity-70">{t.hint}</span>
                </button>
              ))}
            </div>
          </div>

          <div>
            <span className="mb-1.5 block text-xs font-medium text-slate-400">Target Platforms</span>
            <div className="flex flex-wrap gap-2">
              {PLATFORMS.map((p) => (
                <button
                  key={p.id}
                  type="button"
                  onClick={() => togglePlatform(p.id)}
                  className={`rounded-full border px-3 py-1.5 text-xs transition-colors ${
                    platforms.includes(p.id)
                      ? 'border-emerald-500/60 bg-emerald-500/10 text-emerald-300'
                      : 'border-white/[0.08] bg-white/[0.03] text-slate-400 hover:border-white/[0.2]'
                  }`}
                >
                  {p.label}
                </button>
              ))}
            </div>
          </div>

          <div className="flex items-center gap-2 rounded-lg border border-white/[0.08] bg-white/[0.03] px-3 py-2.5">
            <FlaskConical className="h-4 w-4 text-fuchsia-400" />
            <div className="flex-1"><Toggle checked={abOn} onChange={(v) => { setAbOn(v); setPreviewKey('a'); }} label="Enable A/B Split Test" /></div>
          </div>

          <Button className="w-full" onClick={generate} disabled={generating}>
            {generating ? <Sparkles className="h-4 w-4 animate-spin" /> : <Wand2 className="h-4 w-4" />}
            {generating ? 'Generating…' : 'Generate Post'}
          </Button>
        </div>
      </Card>

      <Card className="p-5 lg:col-span-3">
        <h3 className="text-sm font-semibold text-white">Preview &amp; Schedule</h3>
        <p className="mt-0.5 text-xs text-slate-400">Edit the copy — the phone updates live — then approve and hand it to Blaze.</p>

        {hasCopy ? (
          <div className="mt-4 grid grid-cols-1 gap-6 xl:grid-cols-[1fr_320px]">
            <div className="space-y-4">
              {showAb ? (
                <div className="grid grid-cols-1 gap-3 md:grid-cols-2">
                  {(['a', 'b'] as VariantKey[]).map((k) => (
                    <div key={k} className={`space-y-2 rounded-lg border p-3 ${previewKey === k ? 'border-emerald-500/50 bg-emerald-500/[0.04]' : 'border-white/[0.08]'}`}>
                      <button type="button" onClick={() => setPreviewKey(k)} className="flex w-full items-center justify-between text-xs font-semibold text-white">
                        <span>Variant {k.toUpperCase()} · {k === 'a' ? 'Hype / FOMO' : 'Competitive / Curiosity'}</span>
                        <span className="text-[10px] font-normal text-emerald-400">{previewKey === k ? 'in preview' : 'preview'}</span>
                      </button>
                      <TextArea label="Copy" value={ab![k].content} onChange={(v) => editVariant(k, { content: v })} rows={7} />
                      <TextArea label="Hashtags" value={ab![k].hashtags} onChange={(v) => editVariant(k, { hashtags: v })} rows={1} />
                      <p className="break-all font-mono text-[10px] text-slate-500">/go/{campaignId}/{k}</p>
                    </div>
                  ))}
                </div>
              ) : (
                <>
                  <TextArea label="Post Copy" value={content} onChange={setContent} rows={8} />
                  <TextArea label="Hashtags" value={hashtags} onChange={setHashtags} rows={1} />
                </>
              )}

              <label className="block">
                <span className="mb-1.5 block text-xs font-medium text-slate-400">Schedule For</span>
                <input
                  type="datetime-local"
                  value={when}
                  onChange={(e) => setWhen(e.target.value)}
                  className="w-full rounded-lg border border-white/[0.08] bg-white/[0.03] px-3 py-2 text-sm text-white outline-none [color-scheme:dark] focus:border-emerald-500/50"
                />
              </label>
              <div className="flex flex-wrap gap-2">
                <Button onClick={() => void saveDraft()}>
                  <Save className="h-4 w-4" /> Save
                </Button>
                <Button variant="secondary" onClick={() => navigator.clipboard?.writeText(`${curContent}\n${curTags}`)}>
                  <Copy className="h-4 w-4" /> Copy
                </Button>
                <Button variant="secondary" onClick={() => void forgetDraft()}>Clear saved</Button>
              </div>
              <p className={`text-xs ${saveState === 'local' ? 'text-amber-400' : 'text-emerald-400'}`}>
                {saveState === 'saving' ? 'Nagse-save…' : saveState === 'saved' ? 'Saved ✓ — automatic, hindi mo na kailangang pindutin ang Save.' : saveState === 'local' ? 'Naka-save sa device (hindi pa sa server).' : 'Auto-save ON — kusang sine-save ang bawat edit.'}
              </p>
              {savedNote && <p className={`text-xs ${saveState === 'local' ? 'text-amber-400' : 'text-slate-400'}`}>{savedNote}</p>}
            </div>

            <div className="space-y-3">
              <PhonePreview
                key={previewPlatform}
                initialPlatform={previewPlatform}
                title={game?.title ?? ''}
                content={curContent}
                hashtags={curTags}
                link={previewLink}
                banner={game?.banner_image ?? ''}
              />
              <Button className="w-full" onClick={() => void queue(true)}>
                <Zap className="h-4 w-4" /> Post Now (live)
              </Button>
              <Button variant="secondary" className="w-full" onClick={() => void queue(false)}>
                <Send className="h-4 w-4" /> Schedule for the time above
              </Button>
            </div>
          </div>
        ) : (
          <EmptyState
            icon={<Sparkles className="h-10 w-10" />}
            title="Nothing generated yet"
            subtitle="Pick a game, choose a tone, and hit Generate Post."
          />
        )}
        {msg && <p className="mt-3 text-sm text-amber-400">{msg}</p>}
      </Card>
    </div>
    </div>
  );
}
