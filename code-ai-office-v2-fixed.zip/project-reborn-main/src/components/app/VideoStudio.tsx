import { useCallback, useEffect, useState } from 'react';
import { Check, Clapperboard, Download, Pause, Play, RefreshCw, RotateCcw, Send, Sparkles, Wand2, X, Zap } from 'lucide-react';
import { db } from '@/lib/app/db';
import { PLATFORMS, type Game } from '@/lib/app/types';
import { ENHANCE_PRESETS, VIDEO_ASPECTS, STATUS_LABEL, type EnhancePreset, type VideoJobStatus } from '@/lib/app/video';
import { REEL } from '@/lib/app/videoStaff';
import { videoApi, type EditorStatus, type PublicVideoJob } from '@/lib/app/videoApi';
import { Badge, Button, Card, CardHeader, EmptyState, Input, Select, TextArea, Toggle } from './ui-kit';

const TONE: Record<VideoJobStatus, 'slate' | 'green' | 'amber' | 'red' | 'blue'> = {
  queued: 'slate', editing: 'blue', edited: 'amber', awaiting_approval: 'amber', posting: 'blue', posted: 'green', failed: 'red', paused: 'amber', rejected: 'slate', done: 'green',
};
const FLOW: VideoJobStatus[] = ['queued', 'editing', 'edited', 'posting', 'posted'];
const toSec = (v: string): number | undefined => (v.trim() === '' || Number.isNaN(Number(v)) ? undefined : Number(v));

/** Platform picker: big enough to tap on a phone, wraps instead of overflowing. */
function PlatformChips({ value, onToggle }: { value: string[]; onToggle: (id: string) => void }) {
  return (
    <div className="flex flex-wrap gap-2">
      {PLATFORMS.map((p) => (
        <button key={p.id} type="button" onClick={() => onToggle(p.id)} aria-pressed={value.includes(p.id)}
          className={`min-h-11 rounded-lg border px-4 py-1.5 text-xs transition-colors active:scale-[0.97] sm:min-h-10 sm:px-3.5 ${value.includes(p.id) ? 'border-emerald-500/50 bg-emerald-500/15 text-emerald-300' : 'border-white/[0.08] text-slate-400'}`}>
          {p.label}
        </button>
      ))}
    </div>
  );
}

/** Watch a finished video and save a copy to the phone (the file needs the password, so the app fetches it first). */
function WatchBox({ job }: { job: PublicVideoJob }) {
  const [src, setSrc] = useState('');
  const [loading, setLoading] = useState(false);
  const [err, setErr] = useState('');

  useEffect(() => () => { if (src.startsWith('blob:')) URL.revokeObjectURL(src); }, [src]);

  const watch = async () => {
    setLoading(true); setErr('');
    try { setSrc(await videoApi.preview(job.id)); } catch (e) { setErr((e as Error).message); } finally { setLoading(false); }
  };

  return (
    <div className="space-y-2">
      {src ? (
        <>
          <video src={src} controls playsInline className="aspect-[9/16] max-h-[60svh] w-full max-w-[220px] rounded-xl bg-black object-contain" />
          <a href={src} download={`${(job.post.title || 'video').replace(/[^\w-]+/g, '-').slice(0, 40)}-${job.id.slice(0, 6)}.mp4`}
            className="inline-flex min-h-11 w-full items-center justify-center gap-2 rounded-lg border border-white/[0.08] bg-white/[0.06] px-4 py-2 text-sm text-slate-200 active:bg-white/[0.12] sm:w-auto">
            <Download className="h-4 w-4" />I-download
          </a>
        </>
      ) : (
        <Button variant="secondary" className="w-full sm:w-auto" onClick={() => void watch()} disabled={loading}><Play className="h-4 w-4" />{loading ? 'Kinukuha…' : 'Panoorin'}</Button>
      )}
      {err && <p className="text-xs text-red-400">{err}</p>}
    </div>
  );
}

/** One finished video waiting for the boss: watch it, then approve (posts now, or just closes a download-only enhance) or reject (never posts). */
function ReviewItem({ job, busy, onApprove, onReject, onRedo }: {
  job: PublicVideoJob; busy: boolean; onApprove: () => void; onReject: (reason: string) => void; onRedo: () => void;
}) {
  const [rejecting, setRejecting] = useState(false);
  const [reason, setReason] = useState('');
  const enhance = job.task === 'enhance';
  const downloadOnly = enhance && job.post.platforms.length === 0;

  return (
    <li className="space-y-3 px-4 py-4 sm:px-5">
      <div className="flex flex-wrap items-center gap-2">
        <Badge tone="amber">{STATUS_LABEL.awaiting_approval}</Badge>
        {enhance && <Badge tone="blue">Enhanced ni {REEL.name}</Badge>}
        <span className="min-w-0 text-sm font-medium text-white">{job.post.title || job.id.slice(0, 8)}</span>
        <span className="text-xs text-slate-500">{downloadOnly ? 'download lang' : job.post.platforms.join(', ')}{job.dry_run ? ' · dry run' : ''}</span>
      </div>
      <div className="grid gap-4 sm:grid-cols-[220px_1fr]">
        <WatchBox job={job} />
        <div className="space-y-2 text-sm">
          {job.post.caption && <p className="whitespace-pre-wrap text-slate-300">{job.post.caption}</p>}
          {job.post.tags.length > 0 && <p className="text-xs text-emerald-300">{job.post.tags.join(' ')}</p>}
          {job.post.link && <p className="break-all text-xs text-slate-400">Link: {job.post.link}</p>}
          {enhance && job.spec.enhance && <p className="text-xs text-slate-400">Preset: {ENHANCE_PRESETS.find((p) => p.value === job.spec.enhance)?.label ?? job.spec.enhance}</p>}
          {job.warnings.slice(-2).map((w) => <p key={w} className="text-xs text-amber-300">{w}</p>)}
          <p className="text-xs text-slate-500">{downloadOnly ? 'Hindi ito ipo-post kahit saan. I-download mo lang kapag ayos na.' : "Walang ipo-post hangga't hindi mo pinipindot ang Approve."}</p>
        </div>
      </div>
      {rejecting ? (
        <div className="space-y-2">
          <Input label="Bakit? (optional)" value={reason} onChange={setReason} placeholder="Hal. panget ang text, ibang game muna" />
          <div className="flex flex-col gap-2 sm:flex-row sm:flex-wrap">
            <Button variant="secondary" className="w-full sm:w-auto" onClick={() => { onReject(reason); setRejecting(false); }} disabled={busy}><X className="h-4 w-4" />I-reject</Button>
            <Button variant="ghost" className="w-full sm:w-auto" onClick={() => setRejecting(false)}>Huwag</Button>
          </div>
        </div>
      ) : (
        <div className="flex flex-col gap-2 sm:flex-row sm:flex-wrap">
          <Button className="w-full sm:w-auto" onClick={onApprove} disabled={busy}><Check className="h-4 w-4" />{downloadOnly ? 'Tapos na, ayos na' : 'Approve & i-post'}</Button>
          <Button className="w-full sm:w-auto" variant="secondary" onClick={() => setRejecting(true)} disabled={busy}><X className="h-4 w-4" />Reject</Button>
          {job.game_id && <Button className="w-full sm:w-auto" variant="ghost" onClick={onRedo} disabled={busy}><RotateCcw className="h-4 w-4" />Gawa ulit (ibang wording)</Button>}
        </div>
      )}
    </li>
  );
}

export default function VideoStudio() {
  const [jobs, setJobs] = useState<PublicVideoJob[]>([]);
  const [status, setStatus] = useState<EditorStatus | null>(null);
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);
  const [url, setUrl] = useState('');
  const [aspect, setAspect] = useState('9:16');
  const [start, setStart] = useState('');
  const [end, setEnd] = useState('');
  const [overlay, setOverlay] = useState('');
  const [normalize, setNormalize] = useState(true);
  const [title, setTitle] = useState('');
  const [caption, setCaption] = useState('');
  const [tags, setTags] = useState('');
  const [platforms, setPlatforms] = useState<string[]>([]);
  const [needsApproval, setNeedsApproval] = useState(false);
  const [games, setGames] = useState<Game[]>([]);
  const [gameId, setGameId] = useState('auto');
  // "I-enhance ang video mo": the boss's own video link, assigned to Reel
  const [enhUrl, setEnhUrl] = useState('');
  const [enhPreset, setEnhPreset] = useState<EnhancePreset>('auto');
  const [enhAspect, setEnhAspect] = useState('original');
  const [enhTitle, setEnhTitle] = useState('');
  const [enhPlatforms, setEnhPlatforms] = useState<string[]>([]);
  const [enhMsg, setEnhMsg] = useState('');

  const refresh = useCallback(async () => {
    try { setJobs(await videoApi.list()); setError(''); } catch (e) { setError((e as Error).message); }
  }, []);

  useEffect(() => {
    void refresh();
    void videoApi.status().then(setStatus).catch(() => undefined);
    void db.listGames().then((g) => setGames(g.filter((x) => x.active))).catch(() => undefined);
    const t = window.setInterval(() => { if (!document.hidden) void refresh(); }, 4000); // live stages: poll like the other screens
    return () => window.clearInterval(t);
  }, [refresh]);

  const act = async (fn: () => Promise<unknown>) => {
    setBusy(true); setError('');
    try { await fn(); await refresh(); } catch (e) { setError((e as Error).message); } finally { setBusy(false); }
  };

  const submit = (realtime: boolean) => act(async () => {
    const edit: Parameters<typeof videoApi.enqueue>[0]['edit'] = { aspect, normalize_audio: normalize };
    const s = toSec(start), e = toSec(end);
    if (s !== undefined) edit.start_sec = s;
    if (e !== undefined) edit.end_sec = e;
    if (overlay.trim()) edit.overlay_text = overlay.trim();
    await videoApi.enqueue({
      input: url.trim(), edit, realtime, dry_run: status?.settings.dry_run ?? false, needs_approval: needsApproval,
      post: { title: title.trim(), caption: caption.trim(), tags: tags.split(/[\s,]+/).filter(Boolean), platforms },
    });
    setUrl('');
  });

  const setSetting = (patch: Partial<EditorStatus['settings']>) => act(async () => {
    const settings = await videoApi.setSettings(patch);
    setStatus((s) => (s ? { ...s, settings } : s));
  });

  const makeGameVideo = () => act(async () => {
    await videoApi.generateGame({ ...(gameId !== 'auto' ? { game_id: gameId } : {}), ...(platforms.length ? { platforms } : {}) });
  });
  const redo = (j: PublicVideoJob) => act(async () => {
    await videoApi.reject(j.id, 'Gawa ulit');
    await videoApi.generateGame({ ...(j.game_id ? { game_id: j.game_id } : {}), variant: (j.variant ?? 0) + 1, platforms: j.post.platforms });
  });
  const waiting = jobs.filter((j) => j.status === 'awaiting_approval');
  const sendToReel = () => act(async () => {
    setEnhMsg('');
    await videoApi.enhance({ input: enhUrl.trim(), preset: enhPreset, aspect: enhAspect, title: enhTitle.trim(), platforms: enhPlatforms, ...(status?.settings.dry_run ? { dry_run: true } : {}) });
    setEnhUrl(''); setEnhTitle('');
    setEnhMsg(`Naipasa na kay ${REEL.name}! Kapag tapos na siya, lalabas ito sa taas (Para sa approval mo).`);
  });
  const toggleEnh = (id: string) => setEnhPlatforms((p) => (p.includes(id) ? p.filter((x) => x !== id) : [...p, id]));

  const togglePlatform = (id: string) => setPlatforms((p) => (p.includes(id) ? p.filter((x) => x !== id) : [...p, id]));
  const ff = status?.editors.ffmpeg;
  const preset = ENHANCE_PRESETS.find((p) => p.value === enhPreset);

  return (
    <div className="mt-6 space-y-4">
      <Card>
        <CardHeader
          title="Para sa approval mo"
          subtitle="Si Reel ang gumagawa at nag-e-enhance ng video. Panoorin mo muna — ipo-post lang kapag in-approve mo."
          action={<Badge tone={waiting.length ? 'amber' : 'slate'}>{waiting.length} naghihintay</Badge>}
        />
        {waiting.length === 0 ? (
          <EmptyState icon={<Check className="h-6 w-6" />} title="Walang naghihintay sa'yo" subtitle="Pindutin ang &quot;Gumawa ng video&quot; sa baba, o i-on ang auto-gawa araw-araw." />
        ) : (
          <ul className="divide-y divide-white/[0.06]">
            {waiting.map((j) => (
              <ReviewItem key={j.id} job={j} busy={busy}
                onApprove={() => void act(() => videoApi.approve(j.id))}
                onReject={(reason) => void act(() => videoApi.reject(j.id, reason))}
                onRedo={() => void redo(j)} />
            ))}
          </ul>
        )}
      </Card>

      <Card>
        <CardHeader
          title="I-enhance ang video mo"
          subtitle="Ilagay ang link ng video na ginawa mo. Ipapa-enhance ito kay Reel, ang video editor — mapapanood mo muna bago ang kahit ano."
          action={<Badge tone="blue">{REEL.emoji} Assigned: {REEL.name}</Badge>}
        />
        <div className="grid gap-4 p-4 sm:p-5 md:grid-cols-2">
          <div className="space-y-3">
            <Input label="Link ng video mo (public https)" type="url" inputMode="url" value={enhUrl} onChange={setEnhUrl} placeholder="https://…/video-ko.mp4" />
            <Select label="Ano ang ie-enhance?" value={enhPreset} onChange={(v) => setEnhPreset(v as EnhancePreset)} options={ENHANCE_PRESETS.map((p) => ({ value: p.value, label: p.label }))} />
            {preset && <p className="text-xs leading-relaxed text-slate-400">{preset.hint}</p>}
            <Select label="Laki ng video" value={enhAspect} onChange={setEnhAspect} options={VIDEO_ASPECTS.map((a) => ({ value: a.value, label: a.label }))} />
          </div>
          <div className="space-y-3">
            <Input label="Pamagat (optional)" value={enhTitle} onChange={setEnhTitle} placeholder="Hal. Gallop Racer promo" />
            <div>
              <span className="mb-1.5 block text-xs font-medium text-slate-400">I-post pagkatapos? (blank = i-download lang, walang ipo-post)</span>
              <PlatformChips value={enhPlatforms} onToggle={toggleEnh} />
            </div>
            <p className="text-xs leading-relaxed text-slate-500">Direktang link ng video file (.mp4) ang gumagana. Hindi pwede ang private link o link na nangangailangan ng login.</p>
          </div>
        </div>
        <div className="flex flex-col gap-2 border-t border-white/[0.06] px-4 py-4 sm:px-5">
          <Button className="w-full sm:w-auto sm:self-start" onClick={() => void sendToReel()} disabled={busy || !enhUrl.trim()}><Wand2 className="h-4 w-4" />Ipa-enhance kay {REEL.name}</Button>
          {enhMsg && <p className="text-xs text-emerald-300">{enhMsg}</p>}
          {error && <p className="text-sm text-red-400">{error}</p>}
        </div>
      </Card>

      <Card>
        <CardHeader title="Reel: gumawa ng video mula sa game" subtitle="Kukunin ang banner, title at description ng game. 12 segundong vertical video (9:16)." action={<Sparkles className="h-5 w-5 text-emerald-400" />} />
        <div className="grid gap-4 p-4 sm:p-5 md:grid-cols-2">
          <Select label="Game" value={gameId} onChange={setGameId}
            options={[{ value: 'auto', label: 'Bahala si Reel (iikot)' }, ...games.map((g) => ({ value: g.id, label: g.title }))]} />
          <div>
            <span className="mb-1.5 block text-xs font-medium text-slate-400">Saan i-po-post kapag approved (blank = lahat ng connected)</span>
            <PlatformChips value={platforms} onToggle={togglePlatform} />
          </div>
        </div>
        <div className="flex flex-col gap-3 border-t border-white/[0.06] px-4 py-4 sm:flex-row sm:flex-wrap sm:items-center sm:px-5">
          <Button className="w-full sm:w-auto" onClick={() => void makeGameVideo()} disabled={busy}><Sparkles className="h-4 w-4" />Gumawa ng video</Button>
          <div className="flex flex-col gap-1 sm:ml-auto sm:flex-row sm:flex-wrap sm:items-center sm:gap-4">
            <Toggle checked={status?.settings.auto_generate ?? false} onChange={(v) => void setSetting({ auto_generate: v })} label="Auto-gumawa araw-araw" />
            {status?.settings.auto_generate && (
              <Select label="Ilan kada araw" value={String(status.settings.auto_per_day ?? 1)} onChange={(v) => void setSetting({ auto_per_day: Number(v) })}
                options={[1, 2, 3, 4, 5].map((n) => ({ value: String(n), label: String(n) }))} />
            )}
          </div>
        </div>
        <p className="px-5 pb-4 text-xs text-slate-400">
          Hindi hihigit sa 3 video ang maghihintay sa approval mo. {status?.connected_platforms ? `Connected: ${status.connected_platforms.join(', ') || 'wala pa — i-connect sa API Settings'}.` : ''}
        </p>
      </Card>

      <Card>
        <CardHeader
          title="Video Editor + Real-Time Auto-Poster"
          subtitle="I-edit ang video (trim, 9:16 / 16:9, text, audio) at i-post agad sa Facebook, X, Discord, Telegram."
          action={<Clapperboard className="h-5 w-5 text-emerald-400" />}
        />
        <div className="grid gap-4 p-4 sm:p-5 md:grid-cols-2">
          <div className="space-y-3">
            <Input label="Video URL (public https)" type="url" inputMode="url" value={url} onChange={setUrl} placeholder="https://…/clip.mp4" />
            <div className="grid grid-cols-2 gap-3 sm:grid-cols-3">
              <Select label="Aspect ratio" value={aspect} onChange={setAspect} options={VIDEO_ASPECTS.map((a) => ({ value: a.value, label: a.label }))} className="col-span-2 sm:col-span-1" />
              <Input label="Start (sec)" inputMode="decimal" value={start} onChange={setStart} placeholder="0" />
              <Input label="End (sec)" inputMode="decimal" value={end} onChange={setEnd} placeholder="30" />
            </div>
            <Input label="Text on video (optional)" value={overlay} onChange={setOverlay} placeholder="NEW UPDATE OUT NOW" />
            <Toggle checked={normalize} onChange={setNormalize} label="Normalize audio volume" />
            <Toggle checked={needsApproval} onChange={setNeedsApproval} label="Hintayin ang approval ko bago i-post" />
          </div>
          <div className="space-y-3">
            <Input label="Post title" value={title} onChange={setTitle} placeholder="Game name / headline" />
            <TextArea label="Caption (blank = AI writes one if a key is saved)" value={caption} onChange={setCaption} rows={3} />
            <Input label="Tags" value={tags} onChange={setTags} placeholder="#gaming #karera" />
            <PlatformChips value={platforms} onToggle={togglePlatform} />
          </div>
        </div>
        <div className="flex flex-col gap-3 border-t border-white/[0.06] px-4 py-4 sm:flex-row sm:flex-wrap sm:items-center sm:px-5">
          <Button className="w-full sm:w-auto" onClick={() => void submit(true)} disabled={busy || !url.trim() || !platforms.length}><Zap className="h-4 w-4" />Edit &amp; Post Now</Button>
          <Button className="w-full sm:w-auto" variant="secondary" onClick={() => void submit(false)} disabled={busy || !url.trim() || !platforms.length}><Send className="h-4 w-4" />Edit only (post later)</Button>
          <div className="flex flex-col gap-1 sm:ml-auto sm:flex-row sm:flex-wrap sm:gap-4">
            <Toggle checked={status?.settings.realtime_enabled ?? true} onChange={(v) => void setSetting({ realtime_enabled: v })} label="Real-time auto-post" />
            <Toggle checked={status?.settings.dry_run ?? false} onChange={(v) => void setSetting({ dry_run: v })} label="Dry run (walang totoong post)" />
          </div>
        </div>
        {status && (
          <p className="px-5 pb-4 text-xs text-slate-400">
            Editor: {ff?.ok ? 'ffmpeg ready ✅' : `ffmpeg wala (${ff?.reason ?? 'unavailable'})`}
            {status.editors.cloud.ok ? ' · cloud editor ready' : ''}
            {!ff?.ok && !status.editors.cloud.ok ? ' — i-on ang Dry run o mag-install ng ffmpeg para makapag-edit.' : ''}
          </p>
        )}
        {error && <p className="px-5 pb-4 text-sm text-red-400">{error}</p>}
      </Card>

      <Card>
        <CardHeader title="Live video jobs" subtitle="Nag-a-update kada 4 segundo" action={<Button variant="ghost" aria-label="I-refresh" onClick={() => void refresh()}><RefreshCw className="h-4 w-4" /></Button>} />
        {jobs.length === 0 ? (
          <EmptyState icon={<Clapperboard className="h-6 w-6" />} title="Wala pang video job" subtitle="Mag-submit sa taas para magsimula." />
        ) : (
          <ul className="divide-y divide-white/[0.06]">
            {jobs.map((j) => (
              <li key={j.id} className="space-y-2 px-4 py-4 sm:px-5">
                <div className="flex flex-wrap items-center gap-2">
                  <Badge tone={TONE[j.status]}>{STATUS_LABEL[j.status]}</Badge>
                  <span className="text-sm font-medium text-white">{j.post.title || j.post.caption.slice(0, 50) || j.id.slice(0, 8)}</span>
                  <span className="text-xs text-slate-500">{j.spec.aspect} · {j.post.platforms.join(', ')}{j.dry_run ? ' · dry run' : ''}{j.editor ? ` · ${j.editor}` : ''}{j.assignee === 'reel' ? ` · ${REEL.name}` : ''}</span>
                  <span className="ml-auto flex flex-wrap gap-2">
                    {j.status === 'failed' && <Button variant="secondary" onClick={() => void act(() => videoApi.act('retry', j.id))} disabled={busy}><RotateCcw className="h-4 w-4" />Retry</Button>}
                    {j.status === 'edited' && !(j.needs_approval && !j.approved) && <Button onClick={() => void act(() => videoApi.act('post_now', j.id))} disabled={busy}><Send className="h-4 w-4" />Post now</Button>}
                    {['queued', 'editing', 'edited'].includes(j.status) && <Button variant="ghost" aria-label="I-pause" onClick={() => void act(() => videoApi.act('pause', j.id))} disabled={busy}><Pause className="h-4 w-4" /></Button>}
                    {j.status === 'paused' && <Button variant="ghost" onClick={() => void act(() => videoApi.act('resume', j.id))} disabled={busy}><Play className="h-4 w-4" />Resume</Button>}
                  </span>
                </div>
                <div className="flex gap-1" aria-label="stages">
                  {FLOW.map((s, i) => {
                    const at = j.status === 'failed' || j.status === 'paused' || j.status === 'rejected' ? -1 : FLOW.indexOf(j.status === 'awaiting_approval' ? 'edited' : j.status === 'done' ? 'posted' : j.status);
                    return <span key={s} className={`h-1.5 flex-1 rounded-full ${i <= at ? 'bg-emerald-400' : 'bg-white/[0.08]'}`} />;
                  })}
                </div>
                {j.rejected_reason && <p className="text-xs text-slate-400">Dahilan: {j.rejected_reason}</p>}
                {j.error && <p className="text-xs text-red-400">{j.error}{j.auto_retry ? ' — susubukan ulit ng bot.' : ''}</p>}
                {j.warnings.slice(-2).map((w) => <p key={w} className="text-xs text-amber-300">{w}</p>)}
                {j.results?.filter((r) => r.url).map((r) => <a key={r.platform} href={r.url} target="_blank" rel="noreferrer" className="mr-3 text-xs text-emerald-400 underline">{r.platform}</a>)}
                {j.status === 'done' && j.task === 'enhance' && <WatchBox job={j} />}
                <p className="text-[11px] text-slate-500">{j.stages[j.stages.length - 1]?.note}</p>
              </li>
            ))}
          </ul>
        )}
      </Card>
    </div>
  );
}
