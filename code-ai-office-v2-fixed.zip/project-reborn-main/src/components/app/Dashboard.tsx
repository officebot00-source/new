import { useEffect, useMemo, useRef, useState } from 'react';
import { CalendarClock, CheckCircle2, MousePointerClick, Send, TrendingUp, Zap } from 'lucide-react';
import type { LucideIcon } from 'lucide-react';
import type { BotLog, Game, Post } from '@/lib/app/types';
import { db, subscribeLogs } from '@/lib/app/db';
import { Card } from './ui-kit';
import ActivityConsole from './ActivityConsole';
import OfficeHub from './OfficeHub';
import AbExperiments from './AbExperiments';
import { Heartbeat, LiveActivityChart, LiveHero, LiveStatCard, LiveTicker, NextPostCountdown, logSeries } from './DashboardLive';

interface Stat {
  label: string;
  value: number;
  suffix?: string;
  decimals?: number;
  sub: string;
  icon: LucideIcon;
  accent: string;
  color: string;
  spark: number[];
}

function formatWhen(iso: string) {
  const d = new Date(iso);
  const today = new Date();
  const isToday = d.toDateString() === today.toDateString();
  return isToday
    ? `Today ${d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}`
    : d.toLocaleString([], { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' });
}

export default function Dashboard({ autoPilot, games }: { autoPilot: boolean; games: Game[] }) {
  const [posts, setPosts] = useState<Post[]>([]);
  const [logs, setLogs] = useState<BotLog[]>([]);
  const [inviteCount, setInviteCount] = useState(0);

  const sig = useRef({ posts: '', logs: '' });

  useEffect(() => {
    let mounted = true;
    let busy = false;
    let debounce = 0;
    const load = async () => {
      if (busy || document.hidden) return;
      busy = true;
      try {
        const [postData, logData] = await Promise.all([db.listPosts(), db.listLogs(60)]);
        if (!mounted) return;
        // only touch state when something really changed -> no needless re-render of the whole dashboard + 3D office
        const ps = JSON.stringify(postData.map((p) => [p.id, p.status, (p as { updated_at?: string }).updated_at ?? '']));
        const ls = logData.length ? `${logData.length}:${logData[0].id}` : '0';
        if (ps !== sig.current.posts) {
          sig.current.posts = ps;
          setPosts(postData);
        }
        if (ls !== sig.current.logs) {
          sig.current.logs = ls;
          setLogs(logData);
          setInviteCount(
            logData.filter((l) => l.source === 'auto-inviter' && l.message.startsWith('Sent invite')).length
          );
        }
      } catch (err) {
        console.error('Dashboard load failed', err);
      } finally {
        busy = false;
      }
    };
    void load();
    const t = window.setInterval(() => void load(), 15000);
    // Realtime: the server worker writes bot_logs; batch bursts of inserts into ONE reload.
    const unsubscribe = subscribeLogs(() => {
      window.clearTimeout(debounce);
      debounce = window.setTimeout(() => void load(), 800);
    });
    const onVisible = () => { if (!document.hidden) void load(); };
    document.addEventListener('visibilitychange', onVisible);
    return () => {
      mounted = false;
      window.clearInterval(t);
      window.clearTimeout(debounce);
      document.removeEventListener('visibilitychange', onVisible);
      unsubscribe();
    };
  }, []);

  const scheduled = posts.filter((p) => p.status === 'scheduled').length;
  const published = posts.filter((p) => p.status === 'published').length;
  const clickRate = published > 0 ? (published * 7.4) % 100 : 0;
  const activeGames = games.filter((g) => g.active).length;

  // sparklines + events/min are derived from the logs only when logs change (no extra timers on the page that holds the 3D office)
  const { sparks, eventsPerMin } = useMemo(() => {
    const now = Date.now();
    const n = 20;
    const all = logSeries(logs, now, n);
    return {
      eventsPerMin: logSeries(logs, now, 5).reduce((x, y) => x + y, 0) / 5,
      sparks: {
        all,
        scheduler: logSeries(logs, now, n, (l) => l.source === 'scheduler'),
        poster: logSeries(logs, now, n, (l) => l.source === 'auto-poster'),
        inviter: logSeries(logs, now, n, (l) => l.source === 'auto-inviter'),
      },
    };
  }, [logs]);

  const stats: Stat[] = [
    { label: 'Posts Scheduled', value: scheduled, sub: 'in the queue', icon: CalendarClock, accent: 'text-sky-400 bg-sky-500/10', color: '#38bdf8', spark: sparks.scheduler },
    { label: 'Posts Published', value: published, sub: 'all time', icon: CheckCircle2, accent: 'text-emerald-400 bg-emerald-500/10', color: '#34d399', spark: sparks.poster },
    { label: 'Auto-Invites Sent', value: inviteCount, sub: 'last 60 log events', icon: Send, accent: 'text-amber-400 bg-amber-500/10', color: '#fbbf24', spark: sparks.inviter },
    { label: 'Click / Engagement Rate', value: clickRate, suffix: '%', decimals: 1, sub: 'simulated', icon: MousePointerClick, accent: 'text-fuchsia-400 bg-fuchsia-500/10', color: '#e879f9', spark: sparks.all },
  ];

  const upcoming = posts
    .filter((p) => p.status === 'scheduled')
    .sort((a, b) => new Date(a.scheduled_at).getTime() - new Date(b.scheduled_at).getTime())
    .slice(0, 5);

  const nextPost = upcoming[0];

  return (
    <div className="space-y-6">
      <LiveHero autoPilot={autoPilot} eventsPerMin={eventsPerMin} activeGames={activeGames} />
      <OfficeHub logs={logs} autoPilot={autoPilot} />
      <div className="grid grid-cols-2 gap-3 sm:gap-4 xl:grid-cols-4">
        {stats.map((s, i) => (
          <LiveStatCard key={s.label} {...s} delay={i * 70} />
        ))}
      </div>

      <div className="grid grid-cols-1 gap-4 lg:grid-cols-3">
        <div className="lg:col-span-2">
          <LiveActivityChart logs={logs} />
        </div>

        <Card className="p-5">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-semibold text-white">Bot Engine</h3>
            <Zap className={`h-4 w-4 ${autoPilot ? 'text-emerald-400' : 'text-slate-500'}`} />
          </div>
          <div className="mt-4 space-y-3 text-sm">
            <Heartbeat active={autoPilot} />
            <div className="flex items-center justify-between rounded-lg bg-white/[0.03] px-3 py-2.5">
              <span className="text-slate-400">Auto-Pilot Mode</span>
              <span className={autoPilot ? 'font-medium text-emerald-400' : 'text-slate-500'}>
                {autoPilot ? 'Running' : 'Off'}
              </span>
            </div>
            <div className="flex items-center justify-between rounded-lg bg-white/[0.03] px-3 py-2.5">
              <span className="text-slate-400">Active Games</span>
              <span className="text-white">{activeGames}</span>
            </div>
            <div className="flex items-center justify-between rounded-lg bg-white/[0.03] px-3 py-2.5">
              <span className="text-slate-400">Worker Heartbeat</span>
              <span className="flex items-center gap-1.5 text-emerald-400">
                <span className="relative flex h-2 w-2">
                  <span className="dash-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400" />
                  <span className="relative inline-flex h-2 w-2 rounded-full bg-emerald-400" />
                </span>
                Live
              </span>
            </div>
          </div>
        </Card>
      </div>

      <div className="grid grid-cols-1 gap-4 lg:grid-cols-3">
        <Card className="p-5 lg:col-span-2">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-semibold text-white">Upcoming Scheduled Posts</h3>
            <TrendingUp className="h-4 w-4 text-slate-500" />
          </div>
          <div className="mt-3">
            <NextPostCountdown scheduledAt={nextPost?.scheduled_at ?? null} title={nextPost ? nextPost.content.split('\n')[0] : undefined} />
          </div>
          {upcoming.length === 0 ? (
            <p className="py-8 text-center text-sm text-slate-500">
              Nothing scheduled yet. Generate a post and queue it from the AI Studio or Scheduler.
            </p>
          ) : (
            <ul className="mt-3 divide-y divide-white/[0.05]">
              {upcoming.map((p, i) => (
                <li
                  key={p.id}
                  className="dash-row dash-slide-in flex flex-wrap items-center justify-between gap-x-4 gap-y-1 py-3 sm:flex-nowrap"
                  style={{ animationDelay: `${i * 60}ms` }}
                >
                  <div className="min-w-0">
                    <p className="truncate text-sm text-white">{p.content.split('\n')[0]}</p>
                    <p className="mt-0.5 text-xs text-slate-500">
                      {p.game_title} · {p.platforms.join(', ')}
                    </p>
                  </div>
                  <span className="shrink-0 text-xs font-medium text-slate-400">{formatWhen(p.scheduled_at)}</span>
                </li>
              ))}
            </ul>
          )}
        </Card>

        <Card className="p-5">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-semibold text-white">Live Feed</h3>
            <span className="text-[11px] text-slate-500">pinakabago</span>
          </div>
          <div className="mt-4">
            <LiveTicker logs={logs} />
          </div>
        </Card>
      </div>

      <AbExperiments />

      <ActivityConsole />
    </div>
  );
}
