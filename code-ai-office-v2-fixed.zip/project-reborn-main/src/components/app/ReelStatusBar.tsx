import { ChevronRight } from 'lucide-react';
import { useReelJobs } from '@/lib/app/useReelJobs';
import { REEL, reelStatus, type ReelState } from '@/lib/app/videoStaff';

/** App-wide event: any screen can ask the main app to open a tab. */
export const GOTO_TAB_EVENT = 'reborn:goto-tab';
export const gotoTab = (tab: string) => window.dispatchEvent(new CustomEvent(GOTO_TAB_EVENT, { detail: tab }));

const DOT: Record<ReelState, string> = { working: 'bg-sky-400', waiting: 'bg-amber-400', idle: 'bg-slate-500', problem: 'bg-red-400' };
const TEXT: Record<ReelState, string> = { working: 'text-sky-300', waiting: 'text-amber-300', idle: 'text-slate-400', problem: 'text-red-300' };

/** Reel, the video editor employee: his status comes from the real video jobs (no made-up activity). */
export default function ReelStatusBar() {
  const jobs = useReelJobs();

  const st = reelStatus(jobs ?? []);
  return (
    <div className="relative z-20 border-t border-white/[0.06] bg-[#0d1117]/80 px-4 py-3 sm:px-5">
      <div className="flex flex-wrap items-center gap-3">
        <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl text-xl" style={{ backgroundColor: `${REEL.color}22`, color: REEL.color }} aria-hidden>
          {REEL.emoji}
        </span>
        <div className="min-w-0 flex-1 basis-44">
          <p className="flex flex-wrap items-center gap-x-2 text-sm font-semibold text-white">
            {REEL.name}
            <span className="text-xs font-normal text-slate-400">{REEL.role}</span>
          </p>
          <p className="flex items-start gap-1.5 text-xs">
            <span className={`mt-1 h-2 w-2 shrink-0 rounded-full ${DOT[st.state]}`} />
            <span className={`shrink-0 whitespace-nowrap font-medium ${TEXT[st.state]}`}>{jobs === null ? 'Chine-check…' : st.label}</span>
            <span className="min-w-0 text-slate-400">· {jobs === null ? 'Binubuksan ang video desk' : st.bubble}</span>
          </p>
        </div>
        <button
          type="button"
          onClick={() => gotoTab('studio')}
          className="flex min-h-[44px] w-full items-center justify-center gap-1 rounded-full border border-orange-400/30 bg-orange-500/10 px-4 text-xs font-semibold text-orange-200 transition-colors active:bg-orange-500/20 sm:min-h-[36px] sm:w-auto"
        >
          Video Editor <ChevronRight className="h-3.5 w-3.5" />
        </button>
      </div>
    </div>
  );
}
