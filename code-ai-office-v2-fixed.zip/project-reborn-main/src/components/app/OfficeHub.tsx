import { useEffect, useState } from 'react';
import type { BotLog } from '@/lib/app/types';
import type { AgentId } from '@/lib/app/agents';
import { useAgentActivity } from '@/lib/app/useAgentActivity';
import VirtualOffice from './VirtualOffice';

const nightNow = () => {
  const h = new Date().getHours();
  return h >= 19 || h < 7;
};

export default function OfficeHub({ logs, autoPilot }: { logs: BotLog[]; autoPilot: boolean }) {
  // day/night only changes twice a day, so check it every 30s instead of re-rendering every second
  const [isNight, setIsNight] = useState(nightNow);
  const [paused, setPaused] = useState<Record<string, boolean>>({});

  useEffect(() => {
    const t = window.setInterval(() => setIsNight(nightNow()), 30_000);
    return () => window.clearInterval(t);
  }, []);

  const activity = useAgentActivity(logs, autoPilot, paused);

  const togglePause = (id: AgentId) => {
    setPaused((prev) => ({ ...prev, [id]: !prev[id] }));
  };

  return <VirtualOffice activity={activity} isNight={isNight} paused={paused} onPauseToggle={togglePause} />;
}
