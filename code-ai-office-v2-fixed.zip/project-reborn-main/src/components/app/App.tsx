import { useEffect, useState, type CSSProperties } from 'react';
import { Bot, Brain, Eye, Gamepad2, LayoutDashboard, LogOut, MoreHorizontal, Settings, Sparkles, CalendarClock, UserPlus } from 'lucide-react';
import type { Game } from '@/lib/app/types';
import { db } from '@/lib/app/db';
import { isSupabaseConfigured } from '@/lib/app/supabase';
import { LOCK_EVENT, setPasscode } from '@/lib/app/publish';
import { GOTO_TAB_EVENT } from '@/components/app/ReelStatusBar';
import Dashboard from '@/components/app/Dashboard';
import GameProfiles from '@/components/app/GameProfiles';
import ContentStudio from '@/components/app/ContentStudio';
import VideoStudio from '@/components/app/VideoStudio';
import CaptionWriter from '@/components/app/CaptionWriter';
import Scheduler from '@/components/app/Scheduler';
import InviteBot from '@/components/app/InviteBot';
import ApiSettings from '@/components/app/ApiSettings';
import SharedBrain from '@/components/app/SharedBrain';
import Watchdog from '@/components/app/Watchdog';
import ZoomControl from '@/components/app/ZoomControl';
import LockGate from '@/components/app/LockGate';
import { LiveStage, isLiveTab } from '@/components/app/LiveSkin';
import { supportsCssZoom, useUiZoom } from '@/lib/app/zoom';

type Tab = 'dashboard' | 'games' | 'studio' | 'scheduler' | 'invites' | 'brain' | 'watchdog' | 'settings';

const NAV: { id: Tab; label: string; short: string; icon: typeof LayoutDashboard }[] = [
  { id: 'dashboard', label: 'Dashboard', short: 'Office', icon: LayoutDashboard },
  { id: 'games', label: 'Game Profiles', short: 'Games', icon: Gamepad2 },
  { id: 'studio', label: 'AI Content Studio', short: 'Studio', icon: Sparkles },
  { id: 'scheduler', label: 'Scheduler', short: 'Queue', icon: CalendarClock },
  { id: 'invites', label: 'Auto-Invite Bot', short: 'Invites', icon: UserPlus },
  { id: 'brain', label: 'Shared Brain', short: 'Brain', icon: Brain },
  { id: 'watchdog', label: 'Watchdog (Argus)', short: 'Argus', icon: Eye },
  { id: 'settings', label: 'API Settings', short: 'API', icon: Settings },
];

/** Phone bottom bar: the four most used tabs + a "More" sheet for the rest (8 tiny icons were too small to tap). */
const PRIMARY: Tab[] = ['dashboard', 'studio', 'scheduler', 'games'];

export default function App() {
  return (
    <LockGate>
      <MainApp />
    </LockGate>
  );
}

function MainApp() {
  const [tab, setTab] = useState<Tab>('dashboard');
  const [games, setGames] = useState<Game[]>([]);
  const [autoPilot, setAutoPilot] = useState(false);
  const [bannerHidden, setBannerHidden] = useState(false);
  const [moreOpen, setMoreOpen] = useState(false);
  const { zoom, setZoom } = useUiZoom();
  const goTab = (t: Tab) => {
    setTab(t);
    setMoreOpen(false);
    window.scrollTo({ top: 0 });
  };
  // other screens (e.g. Reel's status bar in the office) can ask the app to open a tab
  useEffect(() => {
    const onGoto = (e: Event) => {
      const t = (e as CustomEvent<string>).detail;
      if (NAV.some((n) => n.id === t)) goTab(t as Tab);
    };
    window.addEventListener(GOTO_TAB_EVENT, onGoto);
    return () => window.removeEventListener(GOTO_TAB_EVENT, onGoto);
  }, []);
  // locking used to be a floating button that covered content on phones: it now lives in the header and the More menu
  const lockApp = () => {
    setPasscode('');
    setMoreOpen(false);
    window.dispatchEvent(new Event(LOCK_EVENT));
  };

  // the "More" sheet closes with the Escape key (hardware keyboards / Android back gesture handlers that send it)
  useEffect(() => {
    if (!moreOpen) return;
    const onKey = (e: KeyboardEvent) => { if (e.key === 'Escape') setMoreOpen(false); };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [moreOpen]);

  useEffect(() => {
    db.listGames()
      .then(setGames)
      .catch((err) => console.error('Failed to load games', err));
  }, [tab]);

  // Auto-Pilot lives in the database (bot_settings); the pg_cron worker reads it 24/7.
  useEffect(() => {
    db.getAutoPilot().then(setAutoPilot).catch((err) => console.error('Failed to load auto-pilot', err));
  }, []);

  const toggleAutoPilot = async (v: boolean) => {
    setAutoPilot(v);
    try {
      await db.setAutoPilot(v);
      await db.log(v ? 'success' : 'warning', 'system', v ? 'Auto-Pilot Mode ENABLED — the server worker now runs 24/7' : 'Auto-Pilot Mode disabled — server worker paused');
    } catch (err) {
      setAutoPilot(!v);
      console.error('Failed to save auto-pilot', err);
    }
  };

  return (
    <>
    <div
      className="app-zoom-root w-full bg-[#0b0e14] text-slate-200 antialiased"
      style={{
        ...(supportsCssZoom && zoom !== 1 ? { zoom } : null),
        '--ui-zoom': supportsCssZoom ? zoom : 1,
        minHeight: supportsCssZoom ? `calc(100svh / ${zoom})` : '100svh',
        paddingLeft: 'env(safe-area-inset-left)',
        paddingRight: 'env(safe-area-inset-right)',
      } as CSSProperties}
    >
      {!isSupabaseConfigured && !bannerHidden && (
        <div className="flex flex-wrap items-center justify-center gap-2 bg-amber-500/15 px-4 py-2 text-center text-xs text-amber-300">
          <span>
            Local mode: data is saved in this browser only. To sync with Supabase, add VITE_SUPABASE_URL and
            VITE_SUPABASE_ANON_KEY in Netlify, then redeploy.
          </span>
          <button type="button" onClick={() => setBannerHidden(true)} className="rounded border border-amber-300/30 px-2 py-0.5 hover:bg-amber-300/10">
            Hide
          </button>
        </div>
      )}
      {/* Header — solid colour on purpose: a blurred sticky bar makes Android Chrome flicker */}
      <header className="sticky top-0 z-20 border-b border-white/[0.06] bg-[#0b0e14]" style={{ paddingTop: 'env(safe-area-inset-top)' }}>
        <div className="mx-auto flex max-w-7xl items-center justify-between gap-3 px-4 py-3 sm:px-6">
          <div className="flex min-w-0 items-center gap-3">
            <span className="flex shrink-0 items-center justify-center rounded-xl bg-gradient-to-br from-emerald-400/25 to-sky-400/20 p-2 text-emerald-300 shadow-[0_0_18px_-4px_rgba(52,211,153,0.55)] ring-1 ring-emerald-400/25">
              <Bot className="h-5 w-5" />
            </span>
            <div className="min-w-0">
              <h1 className="truncate text-sm font-bold tracking-tight text-white sm:text-base">Code Ai Office</h1>
              <p className="truncate text-[11px] leading-snug text-slate-500">AI Social Auto-Post &amp; Auto-Invite</p>
            </div>
          </div>
          <div className="flex shrink-0 items-center gap-2">
            <span
              className={`flex items-center gap-1.5 rounded-full border px-2.5 py-1 text-[11px] font-semibold ${
                autoPilot ? 'border-emerald-400/30 bg-emerald-500/10 text-emerald-300' : 'border-white/[0.08] bg-white/[0.03] text-slate-400'
              }`}
            >
              <span className={`h-1.5 w-1.5 rounded-full ${autoPilot ? 'bg-emerald-400 shadow-[0_0_6px_rgba(52,211,153,0.9)]' : 'bg-slate-500'}`} />
              <span className="hidden min-[380px]:inline">{autoPilot ? 'Auto-Pilot ON' : 'Auto-Pilot OFF'}</span>
              <span className="min-[380px]:hidden">{autoPilot ? 'ON' : 'OFF'}</span>
            </span>
            {isSupabaseConfigured && (
              <button
                type="button"
                onClick={lockApp}
                aria-label="I-lock ang app"
                className="hidden h-10 w-10 items-center justify-center rounded-full border border-white/[0.08] text-slate-400 transition-colors hover:bg-white/[0.06] hover:text-white md:flex"
              >
                <LogOut className="h-4 w-4" />
              </button>
            )}
          </div>
        </div>
        <nav className="mx-auto hidden max-w-7xl flex-wrap gap-1 px-4 pb-2 sm:px-6 md:flex">
          {NAV.map((n) => {
            const Icon = n.icon;
            return (
              <button
                key={n.id}
                type="button"
                onClick={() => goTab(n.id)}
                className={`flex items-center gap-2 rounded-lg px-3 py-2 text-xs font-medium transition-colors ${
                  tab === n.id ? 'bg-emerald-500/15 text-emerald-300' : 'text-slate-400 hover:bg-white/[0.05] hover:text-white'
                }`}
              >
                <Icon className="h-3.5 w-3.5" />
                {n.label}
              </button>
            );
          })}
        </nav>
        <div className="h-px bg-gradient-to-r from-transparent via-emerald-400/30 to-transparent" />
      </header>

      <main className="mx-auto w-full max-w-7xl px-3 py-4 pb-[calc(5.5rem+env(safe-area-inset-bottom))] sm:px-6 sm:py-6 md:pb-28">
        <div key={tab} className="tab-fade">
          {tab === 'dashboard' && (
            <>
              <div className="mb-4 overflow-hidden rounded-2xl border border-white/[0.08] shadow-lg">
                <img
                  src="/banner.jpg"
                  alt="Code Ai Office"
                  width={1376}
                  height={768}
                  className="h-40 w-full object-cover object-center sm:h-56 lg:h-72"
                  loading="eager"
                />
              </div>
              <Dashboard autoPilot={autoPilot} games={games} />
            </>
          )}
          {isLiveTab(tab) && (
            <LiveStage tab={tab} autoPilot={autoPilot} games={games.length}>
            {tab === 'games' && <GameProfiles />}
            {tab === 'studio' && (
              <>
                <div className="mb-5"><CaptionWriter /></div>
                <ContentStudio onQueued={() => db.log('success', 'scheduler', 'New post added to the queue')} />
                <VideoStudio />
              </>
            )}
            {tab === 'scheduler' && <Scheduler autoPilot={autoPilot} onAutoPilotChange={toggleAutoPilot} />}
            {tab === 'invites' && <InviteBot />}
            {tab === 'brain' && <SharedBrain />}
            {tab === 'watchdog' && <Watchdog />}
            {tab === 'settings' && <ApiSettings />}
            </LiveStage>
          )}
        </div>
      </main>
    </div>

    {/* Phone bottom navigation (outside the zoomed wrapper so it never scales or jumps) */}
    <nav
      className="fixed inset-x-0 bottom-0 z-40 border-t border-white/[0.08] bg-[#0d1117] md:hidden"
      style={{ paddingBottom: 'env(safe-area-inset-bottom)' }}
      aria-label="Navigation"
    >
      <div className="mx-auto flex max-w-lg">
        {NAV.filter((n) => PRIMARY.includes(n.id)).map((n) => {
          const Icon = n.icon;
          const active = tab === n.id;
          return (
            <button
              key={n.id}
              type="button"
              onClick={() => goTab(n.id)}
              aria-current={active ? 'page' : undefined}
              className={`relative flex min-h-[56px] min-w-0 flex-1 flex-col items-center justify-center gap-0 text-[11px] font-medium transition-colors ${
                active ? 'text-emerald-300' : 'text-slate-500 active:text-slate-300'
              }`}
            >
              <span className={`flex h-7 w-14 items-center justify-center rounded-full transition-colors ${active ? 'bg-emerald-500/15' : ''}`}>
                <Icon className="h-5 w-5" />
              </span>
              <span className="max-w-full truncate px-0.5">{n.short}</span>
            </button>
          );
        })}
        <button
          type="button"
          onClick={() => setMoreOpen((v) => !v)}
          aria-haspopup="dialog"
          aria-expanded={moreOpen}
          className={`relative flex min-h-[56px] min-w-0 flex-1 flex-col items-center justify-center gap-0 text-[11px] font-medium transition-colors ${
            moreOpen || !PRIMARY.includes(tab) ? 'text-emerald-300' : 'text-slate-500 active:text-slate-300'
          }`}
        >
          <span className={`flex h-7 w-14 items-center justify-center rounded-full transition-colors ${moreOpen || !PRIMARY.includes(tab) ? 'bg-emerald-500/15' : ''}`}>
            <MoreHorizontal className="h-5 w-5" />
          </span>
          <span className="max-w-full truncate px-0.5">{!PRIMARY.includes(tab) ? (NAV.find((n) => n.id === tab)?.short ?? 'More') : 'More'}</span>
        </button>
      </div>
    </nav>

    {/* "More" bottom sheet (phones only) */}
    {moreOpen && (
      <div className="md:hidden">
        <div className="fixed inset-0 z-[55] bg-black/60" onClick={() => setMoreOpen(false)} aria-hidden="true" />
        <div
          role="dialog"
          aria-modal="true"
          aria-label="Iba pang menu"
          className="sheet-up fixed inset-x-0 z-[56] mx-auto max-h-[70svh] max-w-lg overflow-y-auto rounded-t-2xl border border-b-0 border-white/[0.1] bg-[#141821] p-3 shadow-2xl"
          style={{ bottom: 'calc(var(--nav-h, 56px) + env(safe-area-inset-bottom))' }}
        >
          <div className="mx-auto mb-3 h-1 w-10 rounded-full bg-white/[0.15]" />
          <div className="grid grid-cols-2 gap-2">
            {NAV.filter((n) => !PRIMARY.includes(n.id)).map((n) => {
              const Icon = n.icon;
              const active = tab === n.id;
              return (
                <button
                  key={n.id}
                  type="button"
                  onClick={() => goTab(n.id)}
                  aria-current={active ? 'page' : undefined}
                  className={`flex min-h-[56px] items-center gap-3 rounded-xl border px-3.5 text-left text-sm font-medium transition-colors ${
                    active ? 'border-emerald-400/30 bg-emerald-500/15 text-emerald-300' : 'border-white/[0.08] bg-white/[0.03] text-slate-200 active:bg-white/[0.08]'
                  }`}
                >
                  <Icon className="h-5 w-5 shrink-0" />
                  <span className="min-w-0 truncate">{n.label}</span>
                </button>
              );
            })}
            {isSupabaseConfigured && (
              <button
                type="button"
                onClick={lockApp}
                className="col-span-2 flex min-h-[56px] items-center gap-3 rounded-xl border border-white/[0.08] bg-white/[0.03] px-3.5 text-left text-sm font-medium text-slate-300 active:bg-white/[0.08]"
              >
                <LogOut className="h-5 w-5 shrink-0" />
                <span className="min-w-0 truncate">I-lock ang app</span>
              </button>
            )}
          </div>
        </div>
      </div>
    )}
    <ZoomControl zoom={zoom} onChange={setZoom} />
    </>
  );
}
