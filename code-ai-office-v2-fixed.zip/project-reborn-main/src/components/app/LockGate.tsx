import { useEffect, useRef, useState, type FormEvent, type ReactNode, type RefObject } from 'react';
import { Eye, EyeOff, Lock, ShieldCheck, Sparkles } from 'lucide-react';
import { isSupabaseConfigured } from '@/lib/app/supabase';
import { getPasscode, LOCK_EVENT, setPasscode, verifyPasscode } from '@/lib/app/publish';

type State = 'checking' | 'locked' | 'open';
type Fx = { energy: number; pulse: number; err: number; success: boolean };

const MESSAGES: Record<string, string> = {
  wrong: 'Maling password.',
  'locked-out': 'Sobrang daming maling subok. Maghintay ng 10 minuto bago ulit.',
  'not-set': 'Wala pang password sa server. Kailangan munang i-set ang APP_PASSCODE secret.',
  offline: 'Hindi maabot ang server. Check ang internet at subukan ulit.',
};

const FEATURES = ['Auto-Post', 'Auto-Reply', 'Auto-Invite', 'Shared Brain'];
const TEAM = ['Aria', 'Blaze', 'Nova', 'Echo', 'Cipher', 'Argus'];

const CSS = `
@keyframes lg-aurora{0%,100%{transform:translate3d(-6%,0,0) scale(1)}50%{transform:translate3d(6%,-4%,0) scale(1.12)}}
@keyframes lg-ping{0%{transform:scale(1);opacity:.7}100%{transform:scale(2.6);opacity:0}}
.lg-grid{background-image:linear-gradient(rgba(255,255,255,.035) 1px,transparent 1px),linear-gradient(90deg,rgba(255,255,255,.035) 1px,transparent 1px);background-size:44px 44px;-webkit-mask-image:radial-gradient(70% 60% at 50% 40%,#000,transparent 75%);mask-image:radial-gradient(70% 60% at 50% 40%,#000,transparent 75%)}
.lg-aurora{animation:lg-aurora 16s ease-in-out infinite}
.lg-dot::after{content:"";position:absolute;inset:0;border-radius:9999px;background:inherit;animation:lg-ping 2.2s ease-out infinite}
.lg-d1{animation-delay:.45s}.lg-d2{animation-delay:.65s}.lg-d3{animation-delay:.85s}
@keyframes lg-rise{from{opacity:0;transform:translateY(18px)}to{opacity:1;transform:none}}
@keyframes lg-shake{0%,100%{transform:translateX(0)}20%{transform:translateX(-9px)}40%{transform:translateX(8px)}60%{transform:translateX(-5px)}80%{transform:translateX(4px)}}
@keyframes lg-scan{0%{transform:translateX(-120%)}100%{transform:translateX(320%)}}
.lg-rise{animation:lg-rise .9s cubic-bezier(.22,1,.36,1) .25s both}
.lg-shake{animation:lg-shake .42s ease}
.lg-btn::after{content:"";position:absolute;inset:0;width:40%;background:linear-gradient(100deg,transparent,rgba(255,255,255,.35),transparent);animation:lg-scan 2.8s ease-in-out infinite}
@media (prefers-reduced-motion:reduce){.lg-rise,.lg-shake,.lg-btn::after,.lg-aurora,.lg-dot::after{animation:none}}
`;

/** Animated 3D neural orb: rotates, reacts to typing, flashes red on error, bursts open on success. */
function useOrb(canvas: RefObject<HTMLCanvasElement | null>, slot: RefObject<HTMLDivElement | null>, fx: RefObject<Fx>) {
  useEffect(() => {
    const c = canvas.current;
    const s = slot.current;
    const ctx = c?.getContext('2d');
    if (!c || !s || !ctx) return;
    const reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

    const N = 150;
    const pts = Array.from({ length: N }, (_, i) => {
      const y = 1 - (2 * (i + 0.5)) / N;
      const r = Math.sqrt(1 - y * y);
      const t = i * 2.399963;
      return { x: Math.cos(t) * r, y, z: Math.sin(t) * r };
    });
    const edges: [number, number][] = [];
    for (let i = 0; i < N; i++)
      for (let j = i + 1; j < N; j++) {
        const d = Math.hypot(pts[i].x - pts[j].x, pts[i].y - pts[j].y, pts[i].z - pts[j].z);
        if (d < 0.4) edges.push([i, j]);
      }

    let w = 0, h = 0, raf = 0, ang = 0, mx = 0, my = 0, tx = 0, ty = 0, burst = 0;
    const resize = () => {
      const dpr = Math.min(window.devicePixelRatio || 1, 2);
      w = window.innerWidth;
      h = window.innerHeight;
      c.width = w * dpr;
      c.height = h * dpr;
      c.style.width = w + 'px';
      c.style.height = h + 'px';
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    };
    const move = (e: PointerEvent) => {
      tx = e.clientX / w - 0.5;
      ty = e.clientY / h - 0.5;
    };
    const mix = (a: number, b: number, t: number) => Math.round(a + (b - a) * t);

    const frame = () => {
      const f = fx.current;
      const r = s.getBoundingClientRect();
      const cx = r.left + r.width / 2;
      const cy = r.top + r.height / 2;
      const R = Math.min(r.width, r.height) * 0.4;
      mx += (tx - mx) * 0.05;
      my += (ty - my) * 0.05;
      f.energy *= 0.96;
      f.err = Math.max(0, f.err - 0.015);
      if (f.pulse < 1.4) f.pulse += 0.025;
      if (f.success) burst = Math.min(1, burst + 0.022);
      if (!reduce) ang += 0.0035 + f.energy * 0.03 + burst * 0.05;

      // colour: emerald -> red on error -> white-green on success
      let cr = mix(52, 248, f.err), cg = mix(211, 113, f.err), cb2 = mix(153, 113, f.err);
      cr = mix(cr, 230, burst * 0.7); cg = mix(cg, 255, burst * 0.7); cb2 = mix(cb2, 240, burst * 0.7);
      const col = `${cr},${cg},${cb2}`;

      ctx.clearRect(0, 0, w, h);
      const glow = 0.14 + f.energy * 0.22 + burst * 0.35;
      const g = ctx.createRadialGradient(cx, cy, 0, cx, cy, R * 2.6);
      g.addColorStop(0, `rgba(${col},${glow})`);
      g.addColorStop(1, `rgba(${col},0)`);
      ctx.fillStyle = g;
      ctx.fillRect(cx - R * 3, cy - R * 3, R * 6, R * 6);

      const a2 = ang + mx * 0.9;
      const ca = Math.cos(a2), sa = Math.sin(a2);
      const tilt = 0.25 + my * 0.8, ct = Math.cos(tilt), st = Math.sin(tilt);
      const sc = R * (1 + burst * 3.2);
      const wave = -1.2 + f.pulse * 2.2;
      const P = pts.map((p) => {
        const x = p.x * ca + p.z * sa;
        const z0 = -p.x * sa + p.z * ca;
        const y = p.y * ct - z0 * st;
        const z = p.y * st + z0 * ct;
        const k = 3 / (3 - z);
        return { x: cx + x * sc * k, y: cy + y * sc * k, z, k, b: Math.exp(-Math.pow(p.y - wave, 2) * 14) };
      });

      const fade = 1 - burst;
      ctx.lineWidth = 1;
      for (const [i, j] of edges) {
        const a = P[i], b = P[j];
        const depth = (a.z + b.z) / 2;
        const al = (0.06 + 0.2 * ((depth + 1) / 2) + (a.b + b.b) * 0.5) * fade;
        if (al < 0.01) continue;
        ctx.strokeStyle = `rgba(${col},${al})`;
        ctx.beginPath();
        ctx.moveTo(a.x, a.y);
        ctx.lineTo(b.x, b.y);
        ctx.stroke();
      }
      for (const p of P) {
        ctx.fillStyle = `rgba(${col},${(0.3 + 0.5 * ((p.z + 1) / 2) + p.b) * fade})`;
        ctx.beginPath();
        ctx.arc(p.x, p.y, (1 + (p.z + 1) * 0.9 + p.b * 2.2) * p.k, 0, 6.2832);
        ctx.fill();
      }

      // orbit ring with a travelling dot
      const rx = R * 1.4 * (1 + burst * 3), ry = R * 0.4;
      ctx.save();
      ctx.translate(cx, cy);
      ctx.rotate(-0.4 + mx * 0.3);
      ctx.strokeStyle = `rgba(${col},${0.2 * fade})`;
      ctx.beginPath();
      ctx.ellipse(0, 0, rx, ry, 0, 0, 6.2832);
      ctx.stroke();
      ctx.fillStyle = `rgba(${col},${0.9 * fade})`;
      ctx.beginPath();
      ctx.arc(Math.cos(ang * 2.2) * rx, Math.sin(ang * 2.2) * ry, 2.6, 0, 6.2832);
      ctx.fill();
      ctx.restore();

      raf = requestAnimationFrame(frame);
    };

    resize();
    window.addEventListener('resize', resize);
    window.addEventListener('pointermove', move);
    raf = requestAnimationFrame(frame);
    return () => {
      cancelAnimationFrame(raf);
      window.removeEventListener('resize', resize);
      window.removeEventListener('pointermove', move);
    };
  }, [canvas, slot, fx]);
}

/** Password gate. The REAL protection is on the server (admin-db checks it for every change); this is the door. */
export default function LockGate({ children }: { children: ReactNode }) {
  const [state, setState] = useState<State>(() => (!isSupabaseConfigured ? 'open' : getPasscode() ? 'checking' : 'locked'));
  const [pass, setPass] = useState('');
  const [show, setShow] = useState(false);
  const [remember, setRemember] = useState(true);
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState('');
  const [leaving, setLeaving] = useState(false);
  const [shake, setShake] = useState(0);
  const [caps, setCaps] = useState(false);

  const canvas = useRef<HTMLCanvasElement>(null);
  const slot = useRef<HTMLDivElement>(null);
  const fx = useRef<Fx>({ energy: 0, pulse: 1.4, err: 0, success: false });
  useOrb(canvas, slot, fx);

  const unlock = () => {
    fx.current.success = true;
    setLeaving(true);
    window.setTimeout(() => setState('open'), 950);
  };

  // saved password: confirm it is still valid
  useEffect(() => {
    if (state !== 'checking') return;
    let alive = true;
    void verifyPasscode(getPasscode()).then((r) => {
      if (!alive) return;
      if (r === 'ok') unlock();
      else {
        if (r === 'wrong') setPasscode('');
        setMsg(r === 'wrong' ? '' : MESSAGES[r] ?? '');
        setState('locked');
      }
    });
    return () => { alive = false; };
  }, [state]);

  // the server rejected our password (changed?) -> back to the lock screen
  useEffect(() => {
    const onLock = () => {
      fx.current.success = false;
      setLeaving(false);
      setPass('');
      setState('locked');
    };
    window.addEventListener(LOCK_EVENT, onLock);
    return () => window.removeEventListener(LOCK_EVENT, onLock);
  }, []);

  if (state === 'open') return <>{children}</>;

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    if (!pass || busy) return;
    setBusy(true);
    setMsg('');
    const r = await verifyPasscode(pass);
    setBusy(false);
    if (r === 'ok') {
      setPasscode(pass, remember);
      setPass('');
      unlock();
    } else {
      fx.current.err = 1;
      fx.current.pulse = 0;
      setShake((n) => n + 1);
      setMsg(MESSAGES[r] ?? 'May error.');
    }
  };

  const status = leaving ? 'Bukas na' : state === 'checking' ? 'Chine-check…' : busy ? 'Sandali…' : msg ? 'Naka-lock' : pass ? 'Nagbabasa…' : 'Naka-lock';

  return (
    <div
      className="relative flex min-h-[100svh] flex-col items-center justify-center overflow-x-hidden px-4 py-6 text-slate-200"
      style={{
        background: 'radial-gradient(60% 45% at 50% 26%, rgba(16,185,129,.10), transparent 70%), #05070b',
        paddingTop: 'env(safe-area-inset-top)',
        paddingBottom: 'env(safe-area-inset-bottom)',
      }}
    >
      <style>{CSS}</style>
      <div className="lg-grid pointer-events-none fixed inset-0" aria-hidden="true" />
      <div
        className="lg-aurora pointer-events-none fixed left-1/2 top-[-12%] h-[55vh] w-[90vw] max-w-3xl -translate-x-1/2 rounded-full opacity-60 blur-3xl"
        style={{ background: 'radial-gradient(closest-side, rgba(52,211,153,.18), rgba(56,189,248,.08) 60%, transparent)' }}
        aria-hidden="true"
      />
      <canvas ref={canvas} className="pointer-events-none fixed inset-0" aria-hidden="true" />

      <div className={`relative z-10 flex w-full max-w-sm flex-col items-center transition-all duration-700 ${leaving ? 'scale-95 opacity-0 blur-sm' : ''}`}>
        <div ref={slot} className="h-[28svh] max-h-[260px] min-h-[150px] w-full" />

        <div className="lg-rise w-full text-center">
          <span className="inline-flex items-center gap-1.5 rounded-full border border-emerald-400/20 bg-emerald-400/10 px-3 py-1 text-[11px] font-medium uppercase tracking-[.14em] text-emerald-300">
            <Sparkles className="h-3 w-3" aria-hidden="true" /> AI Social Bot Office
          </span>
          <h1 className="mt-3 bg-gradient-to-b from-white to-slate-300 bg-clip-text text-3xl font-semibold tracking-tight text-transparent sm:text-4xl">Code Ai Office</h1>
          <p className="mx-auto mt-2 max-w-xs text-sm leading-relaxed text-slate-400">
            Mga AI bot na nagpo-post, sumasagot sa comments at nag-iimbita ng players — 24/7.
          </p>
          <ul className="mt-4 flex flex-wrap items-center justify-center gap-2" aria-label="Mga feature">
            {FEATURES.map((f) => (
              <li key={f} className="rounded-full border border-white/10 bg-white/[.04] px-2.5 py-1 text-[11px] text-slate-300">{f}</li>
            ))}
          </ul>
          <p aria-live="polite" className="mt-5 inline-flex items-center gap-1.5 text-xs text-slate-400">
            <Lock className="h-3 w-3" aria-hidden="true" /> {status}
          </p>

          {state === 'locked' && (
            <form
              key={shake}
              onSubmit={submit}
              className={`mt-3 space-y-3 rounded-2xl border border-white/10 bg-white/[.03] p-4 text-left shadow-[0_20px_60px_rgba(0,0,0,.45)] backdrop-blur-md ${shake ? 'lg-shake' : ''}`}
            >
              <div className="relative">
                <label htmlFor="lg-pass" className="sr-only">Password</label>
                <input
                  id="lg-pass"
                  type={show ? 'text' : 'password'}
                  autoComplete="current-password"
                  autoFocus
                  value={pass}
                  onChange={(e) => {
                    setPass(e.target.value);
                    fx.current.energy = 1;
                    fx.current.pulse = 0;
                  }}
                  onKeyUp={(e) => setCaps(e.getModifierState?.('CapsLock') ?? false)}
                  onBlur={() => setCaps(false)}
                  placeholder="Password"
                  className="min-h-[48px] w-full rounded-xl border border-white/10 bg-black/40 px-4 pr-12 text-base tracking-wide text-white outline-none backdrop-blur transition focus:border-emerald-400/70 focus:shadow-[0_0_0_4px_rgba(52,211,153,.14)]"
                />
                <button
                  type="button"
                  onClick={() => setShow((v) => !v)}
                  aria-label={show ? 'Itago ang password' : 'Ipakita ang password'}
                  className="absolute right-1.5 top-1/2 flex h-10 w-10 -translate-y-1/2 items-center justify-center rounded-lg text-slate-400 hover:text-white focus-visible:outline focus-visible:outline-2 focus-visible:outline-emerald-400"
                >
                  {show ? <EyeOff className="h-[18px] w-[18px]" /> : <Eye className="h-[18px] w-[18px]" />}
                </button>
              </div>

              <label className="flex items-center gap-2 px-1 text-xs text-slate-400">
                <input type="checkbox" checked={remember} onChange={(e) => setRemember(e.target.checked)} className="h-4 w-4 accent-emerald-500" />
                Tandaan sa device na ito
              </label>

              {caps && (
                <p className="rounded-lg bg-amber-400/10 px-3 py-2 text-xs text-amber-200">Naka-on ang Caps Lock.</p>
              )}

              {msg && (
                <p role="alert" className="rounded-lg bg-red-500/10 px-3 py-2 text-xs text-red-300">
                  {msg}
                </p>
              )}

              <button
                type="submit"
                disabled={busy || !pass}
                className="lg-btn relative min-h-[48px] w-full overflow-hidden rounded-xl bg-emerald-400 px-4 text-sm font-semibold text-emerald-950 shadow-[0_10px_30px_rgba(52,211,153,.28)] transition hover:brightness-110 active:translate-y-px disabled:opacity-50 disabled:shadow-none"
              >
                {busy ? 'Sandali…' : 'Pasok'}
              </button>
            </form>
          )}

          <div className="mt-6 flex flex-wrap items-center justify-center gap-x-3 gap-y-1.5" aria-label="Ang team ng mga bot">
            {TEAM.map((n, i) => (
              <span key={n} className="inline-flex items-center gap-1.5 text-[11px] text-slate-500">
                <span className={`lg-dot lg-d${(i % 3) + 1} relative inline-block h-1.5 w-1.5 rounded-full bg-emerald-400`} aria-hidden="true" />
                {n}
              </span>
            ))}
          </div>
          <p className="mt-3 inline-flex items-center gap-1.5 text-[11px] text-slate-600">
            <ShieldCheck className="h-3 w-3" aria-hidden="true" /> Protektado ng server password
          </p>
        </div>
      </div>
    </div>
  );
}
