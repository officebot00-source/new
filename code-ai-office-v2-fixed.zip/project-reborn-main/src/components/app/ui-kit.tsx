import { AlertTriangle, CheckCircle2, ChevronDown, Info, type LucideIcon } from 'lucide-react';
import type { ReactNode } from 'react';

interface CardProps {
  children: ReactNode;
  className?: string;
  /** subtle lift + brighter border on hover (for cards the owner can click or scan quickly) */
  interactive?: boolean;
}

export function Card({ children, className = '', interactive = false }: CardProps) {
  return (
    <div
      className={`surface fade-up rounded-2xl sm:rounded-xl ${interactive ? 'transition-[transform,border-color] duration-200 hover:-translate-y-0.5 hover:border-white/[0.14]' : ''} ${className}`}
    >
      {children}
    </div>
  );
}

export function CardHeader({ title, subtitle, action }: { title: string; subtitle?: string; action?: ReactNode }) {
  return (
    <div className="flex flex-wrap items-start justify-between gap-x-4 gap-y-2 border-b border-white/[0.06] px-4 py-4 sm:px-5">
      <div className="min-w-0 flex-1 basis-48">
        <h3 className="flex items-center gap-2 text-sm font-semibold text-white"><span className="h-3.5 w-1 rounded-full bg-gradient-to-b from-emerald-300 to-emerald-500/40" aria-hidden="true" />{title}</h3>
        {subtitle && <p className="mt-1 text-xs leading-relaxed text-slate-400">{subtitle}</p>}
      </div>
      {action && <div className="max-w-full shrink-0">{action}</div>}
    </div>
  );
}

interface ButtonProps {
  children: ReactNode;
  onClick?: () => void;
  variant?: 'primary' | 'secondary' | 'danger' | 'ghost';
  type?: 'button' | 'submit';
  disabled?: boolean;
  className?: string;
  'aria-label'?: string;
}

export function Button({
  children,
  onClick,
  variant = 'primary',
  type = 'button',
  disabled = false,
  className = '',
  'aria-label': ariaLabel,
}: ButtonProps) {
  const styles: Record<string, string> = {
    primary:
      'bg-gradient-to-b from-emerald-400 to-emerald-500 text-emerald-950 hover:from-emerald-300 hover:to-emerald-400 font-semibold shadow-lg shadow-emerald-500/25',
    secondary:
      'bg-white/[0.06] text-slate-200 hover:bg-white/[0.1] border border-white/[0.08]',
    danger: 'bg-red-500/10 text-red-400 hover:bg-red-500/20 border border-red-500/30',
    ghost: 'text-slate-400 hover:text-white hover:bg-white/[0.06]',
  };
  return (
    <button
      type={type}
      onClick={onClick}
      disabled={disabled}
      aria-label={ariaLabel}
      className={`inline-flex min-h-11 min-w-11 items-center justify-center gap-2 rounded-lg px-4 py-2 text-sm outline-none transition-[color,background-color,transform,box-shadow] duration-150 focus-visible:ring-2 focus-visible:ring-emerald-400/50 focus-visible:ring-offset-2 focus-visible:ring-offset-[#0d1018] active:scale-[0.98] disabled:cursor-not-allowed disabled:opacity-50 sm:min-h-0 sm:min-w-0 ${styles[variant]} ${className}`}
    >
      {children}
    </button>
  );
}

interface InputProps {
  value: string;
  onChange: (v: string) => void;
  placeholder?: string;
  type?: string;
  label?: string;
  className?: string;
  /** phone keyboard to show (e.g. 'numeric' for seconds, 'url' for links) */
  inputMode?: 'text' | 'numeric' | 'decimal' | 'url' | 'email' | 'search';
}

export function Input({ value, onChange, placeholder, type = 'text', label, className = '', inputMode }: InputProps) {
  return (
    <label className={`block ${className}`}>
      {label && <span className="mb-1.5 block text-xs font-medium text-slate-400">{label}</span>}
      <input
        type={type}
        inputMode={inputMode}
        autoCapitalize={type === 'url' || type === 'email' || type === 'password' ? 'none' : undefined}
        autoCorrect={type === 'url' || type === 'email' || type === 'password' ? 'off' : undefined}
        value={value}
        placeholder={placeholder}
        onChange={(e) => onChange(e.target.value)}
        className="min-h-11 w-full rounded-lg border border-white/[0.08] bg-white/[0.03] px-3 py-2 text-sm text-white placeholder-slate-500 outline-none sm:min-h-0 transition-[border-color,background-color,box-shadow] hover:border-white/[0.14] focus:border-emerald-500/60 focus:bg-white/[0.05] focus:ring-2 focus:ring-emerald-500/15"
      />
    </label>
  );
}

export function TextArea({
  value,
  onChange,
  placeholder,
  rows = 3,
  label,
  className = '',
}: {
  value: string;
  onChange: (v: string) => void;
  placeholder?: string;
  rows?: number;
  label?: string;
  className?: string;
}) {
  return (
    <label className={`block ${className}`}>
      {label && <span className="mb-1.5 block text-xs font-medium text-slate-400">{label}</span>}
      <textarea
        value={value}
        placeholder={placeholder}
        rows={rows}
        onChange={(e) => onChange(e.target.value)}
        className="w-full resize-y rounded-lg border border-white/[0.08] bg-white/[0.03] px-3 py-2 text-sm leading-relaxed text-white placeholder-slate-500 outline-none transition-[border-color,background-color,box-shadow] hover:border-white/[0.14] focus:border-emerald-500/60 focus:bg-white/[0.05] focus:ring-2 focus:ring-emerald-500/15"
      />
    </label>
  );
}

export function Select({
  value,
  onChange,
  options,
  label,
  className = '',
}: {
  value: string;
  onChange: (v: string) => void;
  options: { value: string; label: string }[];
  label?: string;
  className?: string;
}) {
  return (
    <label className={`block ${className}`}>
      {label && <span className="mb-1.5 block text-xs font-medium text-slate-400">{label}</span>}
      <span className="relative block">
        <select
          value={value}
          onChange={(e) => onChange(e.target.value)}
          className="min-h-11 w-full appearance-none rounded-lg border border-white/[0.08] bg-white/[0.03] py-2 pl-3 pr-9 text-sm text-white outline-none transition-[border-color,box-shadow] hover:border-white/[0.14] focus:border-emerald-500/60 focus:ring-2 focus:ring-emerald-500/15 sm:min-h-0 [&>option]:bg-[#141821]"
        >
          {options.map((o) => (
            <option key={o.value} value={o.value}>
              {o.label}
            </option>
          ))}
        </select>
        <ChevronDown className="pointer-events-none absolute right-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-500" aria-hidden="true" />
      </span>
    </label>
  );
}

export function Toggle({
  checked,
  onChange,
  label,
}: {
  checked: boolean;
  onChange: (v: boolean) => void;
  label?: string;
}) {
  return (
    <button
      type="button"
      role="switch"
      aria-checked={checked}
      onClick={() => onChange(!checked)}
      className="inline-flex min-h-11 items-center gap-3 rounded-md text-left outline-none focus-visible:ring-2 focus-visible:ring-emerald-400/50 sm:min-h-0"
    >
      <span
        className={`relative h-6 w-11 rounded-full transition-colors duration-200 ${
          checked ? 'bg-emerald-500' : 'bg-white/[0.12]'
        }`}
      >
        <span
          className={`absolute top-0.5 h-5 w-5 rounded-full bg-white shadow transition-transform duration-200 ${
            checked ? 'translate-x-[22px]' : 'translate-x-0.5'
          }`}
        />
      </span>
      {label && <span className="text-sm text-slate-300">{label}</span>}
    </button>
  );
}

export function Badge({ children, tone = 'slate' }: { children: ReactNode; tone?: 'slate' | 'green' | 'amber' | 'red' | 'blue' }) {
  const tones: Record<string, string> = {
    slate: 'bg-white/[0.06] text-slate-300 border-white/[0.08]',
    green: 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20',
    amber: 'bg-amber-500/10 text-amber-400 border-amber-500/20',
    red: 'bg-red-500/10 text-red-400 border-red-500/20',
    blue: 'bg-sky-500/10 text-sky-400 border-sky-500/20',
  };
  return (
    <span className={`inline-flex items-center rounded-full border px-2 py-0.5 text-[11px] font-medium ${tones[tone]}`}>
      {children}
    </span>
  );
}

export function EmptyState({ icon, title, subtitle }: { icon: ReactNode; title: string; subtitle?: string }) {
  return (
    <div className="flex flex-col items-center justify-center gap-2 px-6 py-12 text-center">
      <div className="flex h-14 w-14 items-center justify-center rounded-2xl border border-white/[0.06] bg-white/[0.03] text-slate-500">{icon}</div>
      <p className="mt-1 text-sm font-medium text-slate-300">{title}</p>
      {subtitle && <p className="max-w-sm text-xs text-slate-500">{subtitle}</p>}
    </div>
  );
}

/* ---------- page header, stats and notices shared by every screen ---------- */
export type Accent = 'emerald' | 'violet' | 'sky' | 'amber' | 'pink' | 'rose';
// literal class names on purpose: Tailwind only generates classes it can see in the source
const ACCENTS: Record<Accent, { border: string; icon: string; glow: string; bg: string; text: string }> = {
  emerald: { border: 'border-emerald-400/20', icon: 'from-emerald-400/30 to-sky-400/15 ring-emerald-300/30 shadow-[0_0_24px_-4px_rgba(52,211,153,0.6)]', glow: 'rgba(52,211,153,0.22)', bg: 'rgba(56,189,248,0.12)', text: 'text-emerald-200' },
  violet: { border: 'border-violet-400/20', icon: 'from-violet-400/30 to-emerald-400/20 ring-violet-300/30 shadow-[0_0_24px_-4px_rgba(167,139,250,0.7)]', glow: 'rgba(139,92,246,0.28)', bg: 'rgba(52,211,153,0.14)', text: 'text-violet-200' },
  sky: { border: 'border-sky-400/20', icon: 'from-sky-400/30 to-violet-400/15 ring-sky-300/30 shadow-[0_0_24px_-4px_rgba(56,189,248,0.6)]', glow: 'rgba(56,189,248,0.24)', bg: 'rgba(139,92,246,0.12)', text: 'text-sky-200' },
  amber: { border: 'border-amber-400/20', icon: 'from-amber-400/30 to-rose-400/15 ring-amber-300/30 shadow-[0_0_24px_-4px_rgba(251,191,36,0.55)]', glow: 'rgba(251,191,36,0.2)', bg: 'rgba(244,63,94,0.1)', text: 'text-amber-200' },
  pink: { border: 'border-pink-400/20', icon: 'from-pink-400/30 to-violet-400/15 ring-pink-300/30 shadow-[0_0_24px_-4px_rgba(244,114,182,0.6)]', glow: 'rgba(244,114,182,0.22)', bg: 'rgba(139,92,246,0.12)', text: 'text-pink-200' },
  rose: { border: 'border-rose-400/20', icon: 'from-rose-400/30 to-amber-400/15 ring-rose-300/30 shadow-[0_0_24px_-4px_rgba(251,113,133,0.6)]', glow: 'rgba(251,113,133,0.22)', bg: 'rgba(251,191,36,0.1)', text: 'text-rose-200' },
};

export interface HeroStat { label: string; value: ReactNode; hint?: string }
export interface HeroChip { label: string; tone: 'live' | 'warn' | 'off' }

const CHIP: Record<HeroChip['tone'], { wrap: string; dot: string }> = {
  live: { wrap: 'border-emerald-400/30 bg-emerald-500/10 text-emerald-300', dot: 'bg-emerald-400 shadow-[0_0_6px_rgba(52,211,153,0.9)]' },
  warn: { wrap: 'border-amber-400/30 bg-amber-500/10 text-amber-300', dot: 'bg-amber-400 shadow-[0_0_6px_rgba(251,191,36,0.8)]' },
  off: { wrap: 'border-white/10 bg-white/[0.04] text-slate-400', dot: 'bg-slate-500' },
};

/** The header every screen starts with: icon, title, what it does, a status chip, the main action and (optional) quick numbers. */
export function PageHero({ icon: Icon, title, subtitle, accent = 'emerald', chip, actions, stats }: {
  icon: LucideIcon; title: string; subtitle?: ReactNode; accent?: Accent; chip?: HeroChip; actions?: ReactNode; stats?: HeroStat[];
}) {
  const a = ACCENTS[accent];
  return (
    <div
      className={`fade-up relative overflow-hidden rounded-2xl border ${a.border} p-4 sm:p-6`}
      style={{ background: `radial-gradient(600px 220px at 85% -10%, ${a.glow}, transparent 70%), radial-gradient(420px 200px at 0% 110%, ${a.bg}, transparent 70%), linear-gradient(180deg,#171c2b,#121620)` }}
    >
      <div className="flex flex-wrap items-start justify-between gap-4">
        <div className="flex min-w-0 flex-1 basis-64 items-start gap-3">
          <span className={`flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-gradient-to-br ${a.icon} ring-1 ${a.text}`}><Icon className="h-6 w-6" aria-hidden="true" /></span>
          <div className="min-w-0">
            <h2 className="text-lg font-bold tracking-tight text-white sm:text-xl">{title}</h2>
            {subtitle && <p className="mt-0.5 max-w-2xl text-xs leading-relaxed text-slate-400 sm:text-sm">{subtitle}</p>}
            {chip && (
              <span className={`mt-3 inline-flex items-center gap-1.5 rounded-full border px-2.5 py-1 text-[11px] font-semibold ${CHIP[chip.tone].wrap}`}>
                <span className={`h-1.5 w-1.5 rounded-full ${CHIP[chip.tone].dot}`} />{chip.label}
              </span>
            )}
          </div>
        </div>
        {actions && <div className="flex max-w-full shrink-0 flex-wrap items-center gap-2">{actions}</div>}
      </div>
      {stats && stats.length > 0 && (
        <div className="mt-4 grid grid-cols-2 gap-2 border-t border-white/[0.06] pt-4 sm:grid-cols-4">
          {stats.map((st) => (
            <div key={st.label} className="rounded-xl border border-white/[0.06] bg-white/[0.03] px-3 py-2.5">
              <p className="text-[11px] font-medium uppercase tracking-wide text-slate-500">{st.label}</p>
              <p className="mt-0.5 text-xl font-bold tabular-nums text-white">{st.value}</p>
              {st.hint && <p className="text-[11px] text-slate-500">{st.hint}</p>}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

/** Success / warning / error / info message bar (one look for every screen). */
export function Notice({ tone = 'info', children }: { tone?: 'ok' | 'warn' | 'error' | 'info'; children: ReactNode }) {
  const t = {
    ok: { wrap: 'border-emerald-500/30 bg-emerald-500/10 text-emerald-200', Icon: CheckCircle2 },
    warn: { wrap: 'border-amber-500/30 bg-amber-500/10 text-amber-200', Icon: AlertTriangle },
    error: { wrap: 'border-red-500/30 bg-red-500/10 text-red-300', Icon: AlertTriangle },
    info: { wrap: 'border-sky-500/30 bg-sky-500/10 text-sky-200', Icon: Info },
  }[tone];
  return (
    <div role={tone === 'error' ? 'alert' : 'status'} className={`fade-up flex items-start gap-2.5 rounded-xl border px-4 py-2.5 text-sm ${t.wrap}`}>
      <t.Icon className="mt-0.5 h-4 w-4 shrink-0" aria-hidden="true" />
      <div className="min-w-0 flex-1 leading-relaxed">{children}</div>
    </div>
  );
}
