import { useState, type ReactNode } from 'react';
import { Battery, Gamepad2, MessageCircle, Moon, Share2, Signal, Sun, ThumbsUp, Wifi } from 'lucide-react';

export type PreviewPlatform = 'facebook' | 'discord' | 'telegram';

interface Props {
  title: string;
  content: string;
  hashtags: string;
  link: string;
  banner: string;
  initialPlatform?: PreviewPlatform;
}

const TABS: { id: PreviewPlatform; label: string }[] = [
  { id: 'facebook', label: 'Facebook' },
  { id: 'discord', label: 'Discord' },
  { id: 'telegram', label: 'Telegram' },
];

const domainOf = (u: string) => {
  try { return new URL(u).hostname.replace('www.', ''); } catch { return 'yourgame.com'; }
};

function tagged(text: string, cls: string): ReactNode[] {
  return text.split(/(#\w+)/g).map((part, i) =>
    part.startsWith('#') ? <span key={i} className={cls}>{part}</span> : <span key={i}>{part}</span>
  );
}

function Banner({ src, title, className = '' }: { src: string; title: string; className?: string }) {
  return src ? (
    <img src={src} alt={title} className={`w-full object-cover ${className}`} />
  ) : (
    <div className={`flex w-full items-center justify-center bg-gradient-to-br from-emerald-500 via-sky-600 to-indigo-700 ${className}`}>
      <span className="px-3 text-center text-lg font-extrabold uppercase tracking-wide text-white drop-shadow">{title || 'Your Game'}</span>
    </div>
  );
}

export default function PhonePreview({ title, content, hashtags, link, banner, initialPlatform = 'facebook' }: Props) {
  const [platform, setPlatform] = useState<PreviewPlatform>(initialPlatform);
  const [dark, setDark] = useState(true);
  const domain = domainOf(link);
  const time = new Date().toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' });
  const body = content.replace(link, '').trim();
  const discordDark = platform === 'discord' ? true : dark; // Discord mobile is dark-first
  const bg = platform === 'discord' ? (dark ? 'bg-[#313338]' : 'bg-white') : dark ? 'bg-[#18191a]' : 'bg-[#f0f2f5]';
  void discordDark;

  return (
    <div className="mx-auto w-full max-w-[300px]">
      <div className="mb-3 flex flex-wrap items-center justify-between gap-2">
        <div className="flex rounded-lg bg-white/[0.05] p-0.5">
          {TABS.map((t) => (
            <button
              key={t.id}
              type="button"
              onClick={() => setPlatform(t.id)}
              className={`rounded-md px-2.5 py-1 text-[11px] font-medium transition-colors ${platform === t.id ? 'bg-emerald-500 text-emerald-950' : 'text-slate-400 hover:text-white'}`}
            >
              {t.label}
            </button>
          ))}
        </div>
        <button
          type="button"
          onClick={() => setDark((d) => !d)}
          aria-label="Toggle light or dark phone theme"
          className="rounded-lg bg-white/[0.06] p-1.5 text-slate-300 hover:bg-white/[0.12]"
        >
          {dark ? <Sun className="h-3.5 w-3.5" /> : <Moon className="h-3.5 w-3.5" />}
        </button>
      </div>

      {/* bezel */}
      <div className="relative rounded-[44px] border border-white/10 bg-gradient-to-b from-[#2b2f3a] to-[#0b0d12] p-[9px] shadow-2xl shadow-black/60">
        <div className={`relative h-[560px] overflow-hidden rounded-[36px] ${bg}`}>
          {/* status bar */}
          <div className={`absolute inset-x-0 top-0 z-20 flex items-center justify-between px-6 pt-2.5 text-[11px] font-semibold ${dark ? 'text-white' : 'text-black'}`}>
            <span>{time}</span>
            <span className="flex items-center gap-1"><Signal className="h-3 w-3" /><Wifi className="h-3 w-3" /><Battery className="h-3.5 w-3.5" /></span>
          </div>
          <div className="absolute left-1/2 top-2 z-30 h-[22px] w-[84px] -translate-x-1/2 rounded-full bg-black" />

          <div className="h-full overflow-y-auto pt-10 pb-6 [scrollbar-width:none]">
            {platform === 'facebook' && (
              <div className={`${dark ? 'bg-[#242526] text-[#e4e6eb]' : 'bg-white text-[#050505]'} mt-2 shadow`}>
                <div className="flex items-center gap-2 p-3">
                  <span className="flex h-9 w-9 items-center justify-center rounded-full bg-emerald-500 text-emerald-950"><Gamepad2 className="h-5 w-5" /></span>
                  <div className="leading-tight">
                    <p className="text-[13px] font-semibold">{title || 'Gaming Page'}</p>
                    <p className={`text-[11px] ${dark ? 'text-[#b0b3b8]' : 'text-[#65676b]'}`}>Sponsored · Just now · 🌐</p>
                  </div>
                </div>
                <p className="whitespace-pre-wrap px-3 pb-2 text-[13px] leading-snug">{tagged(body, 'text-[#2d88ff]')} <span className="text-[#2d88ff]">{tagged(hashtags, '')}</span></p>
                <div className={dark ? 'bg-[#3a3b3c]' : 'bg-[#f0f2f5]'}>
                  <Banner src={banner} title={title} className="h-36" />
                  <div className="flex items-center justify-between gap-2 p-2.5">
                    <div className="min-w-0">
                      <p className={`truncate text-[10px] uppercase ${dark ? 'text-[#b0b3b8]' : 'text-[#65676b]'}`}>{domain}</p>
                      <p className="truncate text-[13px] font-semibold">{title || 'Play now'}</p>
                    </div>
                    <span className={`shrink-0 rounded-md px-3 py-1.5 text-[12px] font-semibold ${dark ? 'bg-[#4e4f50]' : 'bg-[#e4e6eb]'}`}>Play Now</span>
                  </div>
                </div>
                <div className={`flex justify-between px-3 py-2 text-[11px] ${dark ? 'text-[#b0b3b8]' : 'text-[#65676b]'}`}>
                  <span>👍❤️ 1.2K</span><span>84 comments · 31 shares</span>
                </div>
                <div className={`flex justify-around border-t py-2 text-[12px] font-medium ${dark ? 'border-white/10 text-[#b0b3b8]' : 'border-black/10 text-[#65676b]'}`}>
                  <span className="flex items-center gap-1"><ThumbsUp className="h-3.5 w-3.5" />Like</span>
                  <span className="flex items-center gap-1"><MessageCircle className="h-3.5 w-3.5" />Comment</span>
                  <span className="flex items-center gap-1"><Share2 className="h-3.5 w-3.5" />Share</span>
                </div>
              </div>
            )}

            {platform === 'discord' && (
              <div className={dark ? 'text-[#dbdee1]' : 'text-[#313338]'}>
                <div className={`mb-2 border-b px-4 py-2 text-[13px] font-semibold ${dark ? 'border-black/30' : 'border-black/10'}`}># announcements</div>
                <div className="flex gap-2.5 px-3">
                  <span className="mt-0.5 flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-[#5865f2] text-white"><Gamepad2 className="h-5 w-5" /></span>
                  <div className="min-w-0 flex-1">
                    <p className="flex items-center gap-1.5 text-[13px]">
                      <span className="font-semibold text-[#5865f2]">Blaze</span>
                      <span className="rounded bg-[#5865f2] px-1 text-[9px] font-bold text-white">BOT</span>
                      <span className={`text-[10px] ${dark ? 'text-[#949ba4]' : 'text-[#5c5e66]'}`}>Today at {time}</span>
                    </p>
                    <p className="mt-0.5 whitespace-pre-wrap text-[13px] leading-snug">{tagged(body.split('\n')[0] ?? '', 'text-[#00a8fc]')}</p>
                    <div className={`mt-2 overflow-hidden rounded border-l-4 border-[#34d399] p-2.5 ${dark ? 'bg-[#2b2d31]' : 'bg-[#f2f3f5]'}`}>
                      <p className="text-[13px] font-semibold text-[#00a8fc]">{title || 'Game Title'}</p>
                      <p className="mt-1 whitespace-pre-wrap text-[12px] leading-snug">{body.split('\n').slice(1).join('\n').trim()}</p>
                      <p className="mt-1 text-[12px] text-[#00a8fc]">{hashtags}</p>
                      <Banner src={banner} title={title} className="mt-2 h-32 rounded" />
                      <span className="mt-2 inline-block rounded bg-[#5865f2] px-3 py-1.5 text-[12px] font-medium text-white">Join / Play Game</span>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {platform === 'telegram' && (
              <div className="flex h-full flex-col">
                <div className={`flex items-center gap-2 px-3 py-2 ${dark ? 'bg-[#212d3b] text-white' : 'bg-[#517da2] text-white'}`}>
                  <span className="flex h-8 w-8 items-center justify-center rounded-full bg-emerald-500 text-emerald-950"><Gamepad2 className="h-4 w-4" /></span>
                  <div className="leading-tight"><p className="text-[13px] font-semibold">{title || 'Game Channel'}</p><p className="text-[10px] opacity-70">12,480 subscribers</p></div>
                </div>
                <div className={`flex-1 p-3 ${dark ? 'bg-[#0e1621]' : 'bg-[#dbe7d2]'}`}>
                  <div className={`max-w-[92%] overflow-hidden rounded-2xl rounded-bl-sm ${dark ? 'bg-[#182533] text-white' : 'bg-white text-black'}`}>
                    <Banner src={banner} title={title} className="h-36" />
                    <div className="px-3 pt-2 text-[13px] leading-snug">
                      <p className="whitespace-pre-wrap"><b>{body.split('\n')[0]}</b>{'\n'}<i>{body.split('\n').slice(1).join('\n').trim()}</i></p>
                      <p className="mt-1 text-[#6ab3f3]">{hashtags}</p>
                    </div>
                    <p className={`px-3 pb-2 pt-1 text-right text-[10px] ${dark ? 'text-[#6d7f8f]' : 'text-[#8a98a5]'}`}>👁 1.2K · {time}</p>
                  </div>
                  <div className={`mt-1 max-w-[92%] rounded-lg py-2 text-center text-[13px] font-medium ${dark ? 'bg-[#2b5278]/60 text-white' : 'bg-black/10 text-black'}`}>🎮 Play Now</div>
                </div>
              </div>
            )}
          </div>
          <div className={`absolute bottom-1.5 left-1/2 h-1 w-28 -translate-x-1/2 rounded-full ${dark ? 'bg-white/70' : 'bg-black/70'}`} />
        </div>
      </div>
    </div>
  );
}
