import { createFileRoute } from '@tanstack/react-router';
import GoRedirect from '@/components/app/GoRedirect';

export const Route = createFileRoute('/go/$campaignId/$variant')({
  ssr: false,
  head: () => ({
    meta: [
      { title: 'Redirecting… — Code Ai Office' },
      { name: 'description', content: 'Taking you to the game.' },
      { name: 'robots', content: 'noindex' },
      { property: 'og:title', content: 'Code Ai Office' },
      { property: 'og:description', content: 'Taking you to the game.' },
      { property: 'og:type', content: 'website' },
      { name: 'twitter:card', content: 'summary' },
    ],
  }),
  component: GoRedirect,
});
