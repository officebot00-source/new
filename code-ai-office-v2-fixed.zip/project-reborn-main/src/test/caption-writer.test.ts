import { describe, expect, it } from 'vitest';
import { fitToPlatform, isCaptionPlatform, normalizeHashtags } from '@/lib/app/caption';

describe('caption writer rules', () => {
  it('adds #, removes spaces/symbols and duplicates', () => {
    expect(normalizeHashtags(['VideoKarera', '#videokarera', '#Double Rewards', '##GG!'], 'facebook')).toEqual(['#VideoKarera', '#DoubleRewards', '#GG']);
  });
  it('keeps at most 2 hashtags on X and 15 on Instagram', () => {
    const many = Array.from({ length: 20 }, (_, i) => `tag${i}`);
    expect(normalizeHashtags(many, 'twitter')).toHaveLength(2);
    expect(normalizeHashtags(many, 'instagram')).toHaveLength(15);
  });
  it('fits caption + hashtags into 280 characters on X', () => {
    const r = fitToPlatform('a'.repeat(300), ['#One', '#Two'], 'twitter');
    expect(`${r.caption} ${r.hashtags.join(' ')}`.trim().length).toBeLessThanOrEqual(280);
  });
  it('cuts a TikTok caption to 150 characters', () => {
    expect(fitToPlatform('b'.repeat(400), [], 'tiktok').caption.length).toBe(150);
  });
  it('only accepts known platforms', () => {
    expect(isCaptionPlatform('instagram')).toBe(true);
    expect(isCaptionPlatform('myspace')).toBe(false);
  });
});
