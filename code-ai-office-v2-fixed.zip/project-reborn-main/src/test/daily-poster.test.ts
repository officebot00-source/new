import { describe, expect, it } from 'vitest';
import {
  DEFAULT_DAILY_SETTINGS, addDays, buildFallbackPost, dueSlots, localDateKey, nextRuns, pickGame, sanitizeDailySettings, zonedTimeToUtc,
  type DailySettings, type DailyStatus,
} from '@/lib/app/daily';
import { dailyTick, type DailyDeps, type DailyGame, type DailyPostRow } from '@/server/bot/_shared/daily-pipeline';
import { CRON_JOBS, REALTIME_JOBS } from '@/server/bot/registry';

const G1 = '11111111-1111-4111-8111-111111111111';
const G2 = '22222222-2222-4222-8222-222222222222';
const GAMES: DailyGame[] = [
  { id: G1, title: 'Gallop Racer', description: 'Karera ng kabayo', promo_link: 'https://play.example/gallop', active: true },
  { id: G2, title: 'Sky Tactics', active: true },
];
const settings = (over: Partial<DailySettings> = {}): DailySettings => ({
  ...DEFAULT_DAILY_SETTINGS, enabled: true, timezone: 'Asia/Manila', slots: [{ id: 's1', time: '19:00', platforms: [] }], ...over,
});
// 19:00 in Manila (UTC+8) = 11:00 UTC
const at = (iso: string) => new Date(iso);

type Over = Omit<Partial<DailyDeps>, 'now' | 'games' | 'connected'> & { s?: DailySettings; now?: string; games?: DailyGame[]; connected?: string[] };
function makeDeps(over: Over = {}) {
  const claims = new Set<string>();
  const posts: DailyPostRow[] = [];
  const logs: string[] = [];
  const statuses: Partial<DailyStatus>[] = [];
  const { s, now, games, connected, ...rest } = over;
  const deps: DailyDeps = {
    settings: async () => s ?? settings(),
    games: async () => games ?? GAMES,
    connected: async () => connected ?? ['facebook', 'telegram'],
    claim: async (k) => { if (claims.has(k)) return false; claims.add(k); return true; },
    release: async (k) => { claims.delete(k); },
    insertPost: async (r) => { posts.push(r); },
    generate: async () => null,
    saveStatus: async (p) => { statuses.push(p); },
    log: async (_l, _s, m) => { logs.push(m); },
    now: () => at(now ?? '2026-11-19T10:50:00Z'), // 18:50 Manila: 10 min before the slot
    generateTimeoutMs: 500,
    ...rest,
  };
  return { deps, claims, posts, logs, statuses };
}

describe('daily settings validation', () => {
  it('falls back to safe defaults for garbage input', () => {
    const s = sanitizeDailySettings({ enabled: 'yes', timezone: 'Mars/Base', slots: 'nope', tone: 'angry', game_ids: ['x'] });
    expect(s).toEqual(DEFAULT_DAILY_SETTINGS);
  });
  it('keeps valid slots sorted, drops bad / duplicate times, caps at 6', () => {
    const s = sanitizeDailySettings({
      slots: [
        { id: 'b', time: '21:00', platforms: ['facebook', 'myspace'] }, { id: 'a', time: '09:00' },
        { id: 'c', time: '09:00' }, { id: 'd', time: '25:61' }, { id: 'e', time: '7:00' },
        { time: '10:00' }, { time: '11:00' }, { time: '12:00' }, { time: '13:00' }, { time: '14:00' },
      ],
    });
    // 09:00 appears twice (dup dropped), 25:61 and 7:00 are invalid, and the 6-slot cap cuts off 14:00
    expect(s.slots.map((x) => x.time)).toEqual(['09:00', '10:00', '11:00', '12:00', '13:00', '21:00']);
    expect(new Set(s.slots.map((x) => x.id)).size).toBe(s.slots.length);
  });
  it('only keeps real platforms and uuid game ids', () => {
    const s = sanitizeDailySettings({ slots: [{ id: 'x', time: '08:00', platforms: ['facebook', 'myspace', 'facebook'] }], game_ids: [G1, 'bad', G1] });
    expect(s.slots[0].platforms).toEqual(['facebook']);
    expect(s.game_ids).toEqual([G1]);
  });
  it('a partial patch keeps the other saved values', () => {
    const base = settings({ timezone: 'Asia/Tokyo', tone: 'casual' });
    const s = sanitizeDailySettings({ enabled: false }, base);
    expect(s.enabled).toBe(false);
    expect(s.timezone).toBe('Asia/Tokyo');
    expect(s.tone).toBe('casual');
  });
});

describe('time zones', () => {
  it('Manila 19:00 is 11:00 UTC', () => {
    expect(zonedTimeToUtc('2026-11-19', '19:00', 'Asia/Manila').toISOString()).toBe('2026-11-19T11:00:00.000Z');
  });
  it('handles daylight saving (New York: EST in November, EDT in summer)', () => {
    expect(zonedTimeToUtc('2026-11-19', '19:00', 'America/New_York').toISOString()).toBe('2026-11-20T00:00:00.000Z');
    expect(zonedTimeToUtc('2026-07-01', '19:00', 'America/New_York').toISOString()).toBe('2026-07-01T23:00:00.000Z');
    expect(zonedTimeToUtc('2026-03-08', '09:00', 'America/New_York').toISOString()).toBe('2026-03-08T13:00:00.000Z'); // the day clocks jump forward
  });
  it('knows the local calendar date (UTC evening is already "tomorrow" in Manila)', () => {
    expect(localDateKey(at('2026-11-19T17:00:00Z'), 'Asia/Manila')).toBe('2026-11-20');
    expect(addDays('2026-12-31', 1)).toBe('2027-01-01');
  });
});

describe('which slots are due', () => {
  it('queues up to 15 minutes ahead, not earlier', () => {
    expect(dueSlots(settings(), at('2026-11-19T10:50:00Z'))).toHaveLength(1);
    expect(dueSlots(settings(), at('2026-11-19T10:40:00Z'))).toHaveLength(0);
  });
  it('still posts up to 30 minutes late (server was down), then skips', () => {
    expect(dueSlots(settings(), at('2026-11-19T11:29:00Z'))).toHaveLength(1);
    expect(dueSlots(settings(), at('2026-11-19T11:31:00Z'))).toHaveLength(0);
  });
  it('gives a different lock key every day so tomorrow posts again', () => {
    const a = dueSlots(settings(), at('2026-11-19T11:00:00Z'))[0].claimKey;
    const b = dueSlots(settings(), at('2026-11-20T11:00:00Z'))[0].claimKey;
    expect(a).not.toBe(b);
  });
  it('works across midnight (slot 00:05 seen just before midnight)', () => {
    const s = settings({ slots: [{ id: 's1', time: '00:05', platforms: [] }] });
    const d = dueSlots(s, at('2026-11-19T15:55:00Z')); // 23:55 Manila on the 19th
    expect(d).toHaveLength(1);
    expect(d[0].dateKey).toBe('2026-11-20');
  });
  it('nothing when switched off', () => {
    expect(dueSlots(settings({ enabled: false }), at('2026-11-19T11:00:00Z'))).toHaveLength(0);
  });
  it('previews the next runs in order', () => {
    const s = settings({ slots: [{ id: 'a', time: '09:00', platforms: [] }, { id: 'b', time: '21:00', platforms: [] }] });
    const runs = nextRuns(s, at('2026-11-19T11:00:00Z'), 3).map((r) => r.runAt.toISOString());
    expect(runs).toEqual(['2026-11-19T13:00:00.000Z', '2026-11-20T01:00:00.000Z', '2026-11-20T13:00:00.000Z']);
  });
});

describe('game rotation + template', () => {
  it('rotates games by day and ignores inactive / unselected ones', () => {
    const s = settings();
    const d1 = pickGame(GAMES, s, '2026-11-19', 0)!.id;
    const d2 = pickGame(GAMES, s, '2026-11-20', 0)!.id;
    expect(d1).not.toBe(d2);
    expect(pickGame(GAMES, settings({ game_ids: [G2] }), '2026-11-19', 0)!.id).toBe(G2);
    expect(pickGame([{ ...GAMES[0], active: false }], s, '2026-11-19', 0)).toBeNull();
  });
  it('template post always has the title, the link and hashtags', () => {
    const p = buildFallbackPost(GAMES[0], 'hype');
    expect(p.content).toContain('Gallop Racer');
    expect(p.content).toContain('https://play.example/gallop');
    expect(p.hashtags).toContain('#GallopRacer');
  });
});

describe('daily poster pipeline', () => {
  it('queues exactly one post per slot per day, even when ticks repeat every minute', async () => {
    const t = makeDeps();
    const a = await dailyTick(t.deps);
    const b = await dailyTick(t.deps);
    const c = await dailyTick(t.deps);
    expect(a.queued).toBe(1);
    expect(b.queued + c.queued).toBe(0);
    expect(t.posts).toHaveLength(1);
    expect(t.posts[0].status).toBe('queued');
    expect(t.posts[0].platforms).toEqual(['facebook', 'telegram']);
    expect(t.posts[0].scheduled_at).toBe('2026-11-19T11:00:00.000Z'); // exactly at the slot time
  });
  it('posts again the next day', async () => {
    const t = makeDeps();
    await dailyTick(t.deps);
    const t2 = makeDeps({ now: '2026-11-20T10:50:00Z', claim: async (k) => (t.claims.has(k) ? false : (t.claims.add(k), true)), insertPost: async (r) => { t.posts.push(r); } });
    const r = await dailyTick(t2.deps);
    expect(r.queued).toBe(1);
    expect(t.posts).toHaveLength(2);
    expect(t.posts[0].game_id).not.toBe(t.posts[1].game_id);
  });
  it('uses the AI copy and always appends the promo link', async () => {
    const t = makeDeps({ s: settings({ game_ids: [G1] }), generate: async () => ({ content: 'Ride today!', hashtags: '#race', brain_rule_ids: ['r1'] }) });
    await dailyTick(t.deps);
    expect(t.posts[0].content).toContain('Ride today!');
    expect(t.posts[0].content).toContain('https://play.example/gallop');
    expect(t.posts[0].brain_rule_ids).toEqual(['r1']);
  });
  it('falls back to the template when the AI fails or hangs, and still posts', async () => {
    const boom = makeDeps({ generate: async () => { throw new Error('quota'); } });
    expect((await dailyTick(boom.deps)).queued).toBe(1);
    expect(boom.logs.some((l) => l.includes('AI failed'))).toBe(true);
    const hang = makeDeps({ generate: () => new Promise(() => undefined), generateTimeoutMs: 20 });
    expect((await dailyTick(hang.deps)).queued).toBe(1);
  });
  it('skips the AI completely when "template only" is chosen', async () => {
    let called = 0;
    const t = makeDeps({ s: settings({ use_ai: false }), generate: async () => { called++; return null; } });
    await dailyTick(t.deps);
    expect(called).toBe(0);
    expect(t.posts).toHaveLength(1);
  });
  it('a slot with chosen platforms only posts to the connected ones among them', async () => {
    const t = makeDeps({ s: settings({ slots: [{ id: 's1', time: '19:00', platforms: ['twitter', 'telegram'] }] }), connected: ['telegram', 'discord'] });
    await dailyTick(t.deps);
    expect(t.posts[0].platforms).toEqual(['telegram']);
  });
  it('does nothing (and does not lock the slot) when no account is connected, so it can post once one is added', async () => {
    const t = makeDeps({ connected: [], now: '2026-11-19T11:00:00Z' });
    const r = await dailyTick(t.deps);
    expect(r.queued).toBe(0);
    expect(r.failed).toBe(1);
    expect(t.claims.size).toBe(0);
    expect(t.statuses[0].last_error).toContain('social account');
  });
  it('does not lock the slot when there is no active game', async () => {
    const t = makeDeps({ games: [] });
    const r = await dailyTick(t.deps);
    expect(r.queued).toBe(0);
    expect(t.claims.size).toBe(0);
  });
  it('a failed insert releases the lock and the next tick retries', async () => {
    let fail = true;
    const t = makeDeps({ insertPost: async () => { if (fail) throw new Error('db down'); } });
    const first = await dailyTick(t.deps);
    expect(first.queued).toBe(0);
    expect(first.ok).toBe(false);
    fail = false;
    expect((await dailyTick(t.deps)).queued).toBe(1);
  });
  it('never throws, even when loading the settings fails', async () => {
    const t = makeDeps({ settings: async () => { throw new Error('boom'); } });
    const r = await dailyTick(t.deps);
    expect(r.ok).toBe(false);
    expect(r.error).toContain('boom');
  });
  it('does nothing when switched off, but "test now" still works', async () => {
    const off = makeDeps({ s: settings({ enabled: false }) });
    expect((await dailyTick(off.deps)).skipped).toBe('off');
    const test = makeDeps({ s: settings({ enabled: false }), now: '2026-11-19T03:00:00Z' });
    const r = await dailyTick(test.deps, { force: { slotId: 's1' } });
    expect(r.queued).toBe(1);
    expect(new Date(test.posts[0].scheduled_at).getTime()).toBeGreaterThan(Date.parse('2026-11-19T03:00:00Z')); // a moment from now, not in the past
  });
  it('two slots in one day queue two posts (different games)', async () => {
    const s = settings({ slots: [{ id: 'a', time: '19:00', platforms: [] }, { id: 'b', time: '19:05', platforms: [] }] });
    const t = makeDeps({ s });
    const r = await dailyTick(t.deps);
    expect(r.queued).toBe(2);
    expect(t.posts[0].game_id).not.toBe(t.posts[1].game_id);
  });
});

describe('scheduler wiring', () => {
  it('runs every tick via REALTIME_JOBS and leaves the original cron cadence alone', () => {
    expect(REALTIME_JOBS.map((j) => j.name)).toContain('daily-poster');
    expect(CRON_JOBS.map((j) => j.name)).not.toContain('daily-poster');
  });
});
