import { afterEach, describe, expect, it } from 'vitest';
import { spawnSync } from 'node:child_process';
import { existsSync, mkdtempSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import {
  buildCaption, buildFfmpegArgs, canTransition, classifyError, classifyMediaInput, transition, validateEditSpec, validatePostSpec,
  type VideoJob, type VideoSettings,
} from '@/lib/app/video';
import { enqueueJob, memoryStore, pauseJob, resumeJob, retryJob, runJob, tick, type PipelineDeps, type PostOutcome } from '@/server/bot/_shared/video-pipeline';
import { ffmpegAdapter, pickAdapter, resetFfmpegProbe } from '@/server/bot/_shared/video-editor';
import { CRON_JOBS, REALTIME_JOBS } from '@/server/bot/registry';

const URL_OK = 'https://cdn.example.com/clip.mp4';
const body = (extra: Record<string, unknown> = {}) => ({ input: URL_OK, edit: { aspect: '9:16' }, post: { title: 'Gallop Racer', caption: 'Bagong race!', tags: ['karera'], platforms: ['telegram', 'discord'] }, ...extra });

function makeDeps(opts: Partial<Omit<PipelineDeps, 'settings'>> & { settings?: VideoSettings } = {}) {
  const { settings: given, ...over } = opts;
  const store = memoryStore();
  const logs: string[] = [];
  let clock = Date.parse('2026-11-19T00:00:00Z');
  let n = 0;
  const settings: VideoSettings = given ?? { realtime_enabled: true, dry_run: false, editor: 'auto', default_platforms: [] };
  const calls = { edit: 0, post: 0, posted: [] as string[][] };
  const deps: PipelineDeps = {
    store,
    settings: async () => settings,
    edit: async () => { calls.edit++; return { adapter: 'ffmpeg', outputPath: '/tmp/x.mp4', warnings: [], edited: true }; },
    post: async (_j, platforms): Promise<PostOutcome> => { calls.post++; calls.posted.push(platforms); return { results: platforms.map((platform) => ({ platform, id: '1' })), errors: [] }; },
    fileExists: async () => false,
    cleanup: async () => undefined,
    log: async (_l, _s, m) => { logs.push(m); },
    mediaDir: '', editTimeoutMs: 1000, postTimeoutMs: 1000,
    now: () => new Date(clock), newId: () => `00000000-0000-4000-8000-${String(++n).padStart(12, '0')}`,
    ...over,
  };
  return { deps, store, logs, calls, advance: (ms: number) => { clock += ms; }, settings };
}
const statusOf = async (t: ReturnType<typeof makeDeps>, id: string) => (await t.store.get(id))?.job.status;

describe('input validation', () => {
  it('only accepts public http(s) URLs, never private hosts or odd schemes', () => {
    expect(classifyMediaInput(URL_OK).ok).toBe(true);
    for (const bad of ['http://127.0.0.1/a.mp4', 'https://192.168.1.5/a.mp4', 'http://localhost/a', 'file:///etc/passwd', 'ftp://x/a.mp4', 'https://user:pw@x.com/a.mp4', '/etc/passwd', '']) {
      expect(classifyMediaInput(bad).ok).toBe(false);
    }
  });
  it('allows local files only inside the configured media folder', () => {
    expect(classifyMediaInput('/media/a.mp4', '/media').ok).toBe(true);
    expect(classifyMediaInput('/media/../etc/passwd', '/media').ok).toBe(false);
    expect(classifyMediaInput('/other/a.mp4', '/media').ok).toBe(false);
  });
  it('checks trim, aspect, volume and platforms', () => {
    expect(validateEditSpec({ start_sec: 5, end_sec: 2 }).ok).toBe(false);
    expect(validateEditSpec({ aspect: '4:3' }).ok).toBe(false);
    expect(validateEditSpec({ volume: 9 }).ok).toBe(false);
    expect(validateEditSpec({ start_sec: 1, end_sec: 9, aspect: '16:9' }).ok).toBe(true);
    expect(validatePostSpec({ title: 'x', platforms: [] }).ok).toBe(false);
    expect(validatePostSpec({ title: 'x', platforms: ['myspace'] }).ok).toBe(false);
    const ok = validatePostSpec({ title: 'x', tags: 'a, #b', platforms: ['twitter'] });
    expect(ok.ok && ok.post.tags).toEqual(['#a', '#b']);
  });
  it('keeps captions inside each platform limit', () => {
    const post = { title: 'T', caption: 'x'.repeat(2000), tags: ['#a'], platforms: ['twitter'] };
    expect(buildCaption(post, 'twitter').length).toBeLessThanOrEqual(270);
    expect(buildCaption(post, 'twitter')).toContain('#a');
  });
});

describe('ffmpeg command', () => {
  it('builds trim + vertical crop + loudnorm + text without shell tricks', () => {
    const { args } = buildFfmpegArgs({ input: 'in.mp4', output: 'out.mp4', isUrl: true, spec: { aspect: '9:16', normalize_audio: true, start_sec: 2, end_sec: 12, overlay_text: "50%: it's on" } });
    const line = args.join(' ');
    expect(line).toContain('-ss 2');
    expect(line).toContain('-t 10');
    expect(line).toContain('crop=1080:1920');
    expect(line).toContain('loudnorm');
    expect(line).toContain('expansion=none');
    expect(line).toContain('-protocol_whitelist');
    expect(args[args.length - 1]).toBe('out.mp4');
  });
});

describe('job states', () => {
  it('allows only the documented moves', () => {
    expect(canTransition('queued', 'editing')).toBe(true);
    expect(canTransition('posted', 'queued')).toBe(false);
    expect(canTransition('queued', 'posted')).toBe(false);
    expect(canTransition('posting', 'queued')).toBe(false);
  });
  it('throws on an illegal move and never mutates the job', () => {
    const t = makeDeps();
    return enqueueJob(t.deps, body(), 'ui').then((r) => {
      if (!r.ok) throw new Error(r.error);
      const before = JSON.stringify(r.job);
      expect(() => transition(r.job, 'posted', 'nope')).toThrow();
      expect(JSON.stringify(r.job)).toBe(before);
    });
  });
  it('treats network blips as retryable and bad setup as permanent', () => {
    expect(classifyError('Editing timed out after 120s').transient).toBe(true);
    expect(classifyError('Telegram 502: bad gateway').transient).toBe(true);
    expect(classifyError('Telegram: missing bot_token — add it in API Settings').transient).toBe(false);
    expect(classifyError('ffmpeg is not installed on this server').transient).toBe(false);
  });
});

describe('real-time flow', () => {
  it('goes queued → editing → edited → posting → posted in one run', async () => {
    const t = makeDeps();
    const r = await enqueueJob(t.deps, body(), 'ui');
    if (!r.ok) throw new Error(r.error);
    const out = await runJob(t.deps, r.job.id);
    expect(out?.status).toBe('posted');
    expect(out?.stages.map((s) => s.status)).toEqual(['queued', 'editing', 'edited', 'posting', 'posted']);
    expect(t.calls).toMatchObject({ edit: 1, post: 1 });
    expect(out?.results?.map((x) => x.platform)).toEqual(['telegram', 'discord']);
  });
  it('stops at "edited" when the real-time switch is off, and posts on demand', async () => {
    const t = makeDeps({ settings: { realtime_enabled: false, dry_run: false, editor: 'auto', default_platforms: [] } });
    const r = await enqueueJob(t.deps, body(), 'ui');
    if (!r.ok) throw new Error(r.error);
    expect((await runJob(t.deps, r.job.id))?.status).toBe('edited');
    expect(t.calls.post).toBe(0);
    expect((await tick(t.deps)).posted).toBe(0);
    expect((await runJob(t.deps, r.job.id, { forcePost: true }))?.status).toBe('posted');
  });
  it('dry run never calls a social API', async () => {
    const t = makeDeps();
    const r = await enqueueJob(t.deps, body({ dry_run: true }), 'webhook');
    if (!r.ok) throw new Error(r.error);
    const out = await runJob(t.deps, r.job.id);
    expect(out?.status).toBe('posted');
    expect(t.calls.post).toBe(0);
    expect(out?.results?.[0]?.note).toMatch(/dry run/i);
  });
  it('two runs at once cannot post the same job twice', async () => {
    const t = makeDeps();
    const r = await enqueueJob(t.deps, body(), 'ui');
    if (!r.ok) throw new Error(r.error);
    await Promise.all([runJob(t.deps, r.job.id), runJob(t.deps, r.job.id)]);
    expect(t.calls.post).toBe(1);
    expect(t.calls.edit).toBe(1);
  });
  it('pause and resume put the job back where it was', async () => {
    const t = makeDeps();
    const r = await enqueueJob(t.deps, body(), 'ui');
    if (!r.ok) throw new Error(r.error);
    expect((await pauseJob(t.deps, r.job.id)).ok).toBe(true);
    expect((await tick(t.deps)).edited + (await tick(t.deps)).posted).toBe(0); // paused jobs are left alone
    expect((await resumeJob(t.deps, r.job.id)).ok).toBe(true);
    expect(await statusOf(t, r.job.id)).toBe('queued');
  });
});

describe('errors and missing dependencies', () => {
  afterEach(() => { delete process.env['FFMPEG_PATH']; delete process.env['VIDEO_EDITOR_API_URL']; resetFfmpegProbe(); });

  it('rejects bad requests without creating a job', async () => {
    const t = makeDeps();
    expect((await enqueueJob(t.deps, body({ input: 'http://10.0.0.1/a.mp4' }), 'ui')).ok).toBe(false);
    expect((await enqueueJob(t.deps, body({ post: { title: 'x', platforms: [] } }), 'ui')).ok).toBe(false);
    expect(t.store.rows.size).toBe(0);
  });
  it('a missing ffmpeg fails the job with a clear message and does not crash', async () => {
    process.env['FFMPEG_PATH'] = '/nonexistent/ffmpeg';
    resetFfmpegProbe();
    const t = makeDeps({ edit: async (j, s) => (await pickAdapter(s.editor, j.dry_run)).edit({ jobId: j.id, input: j.input, spec: j.spec, timeoutMs: 1000 }) });
    const r = await enqueueJob(t.deps, body(), 'ui');
    if (!r.ok) throw new Error(r.error);
    const out = await runJob(t.deps, r.job.id);
    expect(out?.status).toBe('failed');
    expect(out?.error).toMatch(/ffmpeg is not installed/);
    expect(out?.auto_retry).toBe(false);
    expect(t.calls.post).toBe(0);
  });
  it('falls back to the mock editor only in dry-run mode', async () => {
    process.env['FFMPEG_PATH'] = '/nonexistent/ffmpeg';
    resetFfmpegProbe();
    await expect(pickAdapter('auto', false)).rejects.toThrow(/No video editor available/);
    expect((await pickAdapter('auto', true)).name).toBe('mock');
    await expect(pickAdapter('mock', false)).rejects.toThrow(/dry-run/);
  });
  it('a temporary posting failure is retried by the worker later, not immediately', async () => {
    let fail = true;
    const t = makeDeps({ post: async (_j, platforms) => { if (fail) throw new Error('Telegram 502: bad gateway'); return { results: platforms.map((platform) => ({ platform })), errors: [] }; } });
    const r = await enqueueJob(t.deps, body(), 'ui');
    if (!r.ok) throw new Error(r.error);
    expect((await runJob(t.deps, r.job.id))?.status).toBe('failed');
    expect((await t.store.get(r.job.id))?.job.auto_retry).toBe(true);
    expect((await tick(t.deps)).autoRetried).toBe(0); // backoff not over yet
    fail = false;
    t.advance(3 * 60_000);
    const sum = await tick(t.deps);
    expect(sum.autoRetried).toBe(1);
    expect(await statusOf(t, r.job.id)).toBe('posted');
  });
  it('a post that hangs is cut off by the timeout', async () => {
    const t = makeDeps({ postTimeoutMs: 30, post: () => new Promise(() => undefined) });
    const r = await enqueueJob(t.deps, body(), 'ui');
    if (!r.ok) throw new Error(r.error);
    const out = await runJob(t.deps, r.job.id);
    expect(out?.status).toBe('failed');
    expect(out?.error).toMatch(/timed out/);
  });
  it('manual retry never re-sends platforms that already got the post', async () => {
    let first = true;
    const t = makeDeps({ post: async (_j, platforms) => {
      if (first) { first = false; return { results: [{ platform: 'telegram', id: '1' }, { platform: 'discord', note: 'failed: Discord 500' }], errors: ['discord: Discord 500'] }; }
      return { results: platforms.map((platform) => ({ platform, id: '2' })), errors: [] };
    } });
    const r = await enqueueJob(t.deps, body(), 'ui');
    if (!r.ok) throw new Error(r.error);
    const done = await runJob(t.deps, r.job.id);
    expect(done?.status).toBe('posted'); // one platform got it
    expect(done?.error).toMatch(/discord/);
    expect((await retryJob(t.deps, r.job.id)).ok).toBe(false); // not failed → nothing to retry
  });
  it('a post stuck in "posting" is failed, not re-sent', async () => {
    const t = makeDeps();
    const r = await enqueueJob(t.deps, body(), 'ui');
    if (!r.ok) throw new Error(r.error);
    const cur = (await t.store.get(r.job.id))!;
    const t0 = new Date('2026-11-19T00:00:00Z');
    const stuck: VideoJob = transition(transition(transition(cur.job, 'editing', 'x', t0), 'edited', 'x', t0), 'posting', 'x', t0);
    t.store.rows.set(stuck.id, { job: stuck, rev: 'z' });
    t.advance(11 * 60_000);
    await tick(t.deps);
    const after = (await t.store.get(r.job.id))!.job;
    expect(after.status).toBe('failed');
    expect(after.auto_retry).toBe(false);
    expect(t.calls.post).toBe(0);
  });
});

describe('scheduler wiring', () => {
  it('keeps the original cron cadence and adds the video bot as a real-time job', () => {
    expect(CRON_JOBS.map((j) => j.name)).not.toContain('video-editor-bot');
    expect(REALTIME_JOBS.map((j) => j.name)).toContain('video-editor-bot');
  });
});

const hasFfmpeg = spawnSync('ffmpeg', ['-version']).status === 0;
describe.skipIf(!hasFfmpeg)('real ffmpeg', () => {
  it('trims, crops to 9:16 and writes a playable mp4', async () => {
    const dir = mkdtempSync(join(tmpdir(), 'vtest-'));
    const src = join(dir, 'in.mp4');
    const gen = spawnSync('ffmpeg', ['-loglevel', 'error', '-f', 'lavfi', '-i', 'testsrc=duration=4:size=640x360:rate=25', '-f', 'lavfi', '-i', 'sine=duration=4', '-shortest', '-c:v', 'libx264', '-c:a', 'aac', src]);
    expect(gen.status).toBe(0);
    process.env['VIDEO_MEDIA_DIR'] = dir.replace(/\\/g, '/');
    expect((await ffmpegAdapter.available()).ok).toBe(true);
    const out = await ffmpegAdapter.edit({ jobId: `t${Date.now()}`, input: src.replace(/\\/g, '/'), spec: { aspect: '9:16', normalize_audio: true, start_sec: 1, end_sec: 3, overlay_text: '50% off' }, timeoutMs: 60_000 });
    delete process.env['VIDEO_MEDIA_DIR'];
    expect(out.adapter).toBe('ffmpeg');
    expect(out.outputPath && existsSync(out.outputPath)).toBe(true);
    const probe = spawnSync('ffprobe', ['-v', 'error', '-show_entries', 'stream=width,height', '-of', 'csv=p=0', out.outputPath!], { encoding: 'utf8' });
    expect(probe.stdout).toContain('1080,1920');
  });
});
