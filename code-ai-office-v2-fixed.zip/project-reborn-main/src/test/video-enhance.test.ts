import { describe, expect, it } from 'vitest';
import { spawnSync } from 'node:child_process';
import { existsSync, mkdtempSync, statSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import {
  buildFfmpegArgs, canTransition, ENHANCE_PRESETS, enhanceFilters, isTerminal, validateEditSpec, validatePostSpec, type VideoJob, type VideoSettings,
} from '@/lib/app/video';
import { reelStatus } from '@/lib/app/videoStaff';
import { approveJob, enqueueJob, memoryStore, rejectJob, runJob, tick, type PipelineDeps, type PostOutcome } from '@/server/bot/_shared/video-pipeline';

const SETTINGS: VideoSettings = { realtime_enabled: true, dry_run: false, editor: 'auto', default_platforms: ['telegram'], auto_generate: false, auto_per_day: 1 };

function makeDeps() {
  const store = memoryStore();
  const logs: string[] = [];
  let n = 0;
  const calls = { edit: 0, post: 0, posted: [] as string[][] };
  const deps: PipelineDeps = {
    store,
    settings: async () => SETTINGS,
    edit: async () => { calls.edit++; return { adapter: 'ffmpeg', outputPath: '/tmp/enhanced.mp4', warnings: [], edited: true }; },
    post: async (_j, platforms): Promise<PostOutcome> => { calls.post++; calls.posted.push(platforms); return { results: platforms.map((platform) => ({ platform, id: '1' })), errors: [] }; },
    fileExists: async () => true,
    cleanup: async () => undefined,
    log: async (_l, _s, m) => { logs.push(m); },
    mediaDir: '', editTimeoutMs: 1000, postTimeoutMs: 1000,
    now: () => new Date('2026-11-19T01:00:00Z'), newId: () => `00000000-0000-4000-8000-${String(++n).padStart(12, '0')}`,
  };
  return { deps, store, logs, calls };
}
const URL_IN = 'https://cdn.example.com/my-video.mp4';

describe('enhance presets', () => {
  it('every preset has filters, and the audio presets turn on loudness normalising', () => {
    for (const p of ENHANCE_PRESETS) {
      const f = enhanceFilters(p.value);
      expect(f.vf.length + f.af.length).toBeGreaterThan(0);
    }
    expect(enhanceFilters('clean_audio').vf).toEqual([]);
    expect(enhanceFilters('clean_audio').normalize).toBe(true);
    expect(enhanceFilters('vivid').af).toEqual([]);
  });

  it('validateEditSpec accepts a known preset and refuses an unknown one', () => {
    const ok = validateEditSpec({ aspect: 'original', enhance: 'sharper' });
    expect(ok.ok && ok.spec.enhance).toBe('sharper');
    expect(validateEditSpec({ enhance: 'magic' }).ok).toBe(false);
    const none = validateEditSpec({ aspect: 'original' });
    expect(none.ok && none.spec.enhance).toBeUndefined();
  });

  it('ffmpeg plan: enhance filters go after resize and before the text; plain edits are unchanged', () => {
    const { args } = buildFfmpegArgs({ input: 'in.mp4', output: 'out.mp4', spec: { aspect: '9:16', normalize_audio: false, enhance: 'auto', overlay_text: 'HI' }, withText: true });
    const vf = args[args.indexOf('-vf') + 1]!;
    expect(vf.indexOf('crop=1080:1920')).toBeLessThan(vf.indexOf('unsharp'));
    expect(vf.indexOf('unsharp')).toBeLessThan(vf.indexOf('drawtext'));
    const af = args[args.indexOf('-af') + 1]!;
    expect(af).toContain('highpass');
    expect(af).toContain('loudnorm'); // forced on by "auto" even though normalize_audio was off
    expect(args[args.indexOf('-crf') + 1]).toBe('20');
    const plain = buildFfmpegArgs({ input: 'in.mp4', output: 'out.mp4', spec: { aspect: 'original', normalize_audio: false } }).args;
    expect(plain).not.toContain('-vf');
    expect(plain).not.toContain('-af');
    expect(plain[plain.indexOf('-crf') + 1]).toBe('23');
  });

  it('post spec: no platform is allowed only for download-only enhance', () => {
    expect(validatePostSpec({ title: '', platforms: [] }).ok).toBe(false);
    expect(validatePostSpec({ title: '', platforms: [] }, [], { allowNoPlatforms: true }).ok).toBe(true);
  });
});

describe('enhance my own video (assigned to Reel)', () => {
  it('queues for Reel, edits, then WAITS for you — never posts by itself', async () => {
    const t = makeDeps();
    const made = await enqueueJob(t.deps, { task: 'enhance', input: URL_IN, edit: { enhance: 'vivid' }, post: { platforms: [] } }, 'ui');
    expect(made.ok).toBe(true);
    if (!made.ok) return;
    expect(made.job.task).toBe('enhance');
    expect(made.job.assignee).toBe('reel');
    expect(made.job.realtime).toBe(false);
    expect(made.job.needs_approval).toBe(true);
    expect(made.job.spec.enhance).toBe('vivid');
    expect(made.job.post.platforms).toEqual([]);
    expect(t.logs.some((l) => l.includes('Reel'))).toBe(true);
    expect((await runJob(t.deps, made.job.id))?.status).toBe('awaiting_approval');
    for (let i = 0; i < 3; i++) await tick(t.deps);
    expect((await runJob(t.deps, made.job.id, { forcePost: true }))?.status).toBe('awaiting_approval');
    expect(t.calls.post).toBe(0);
  });

  it('defaults to Auto Enhance and to a plain title', async () => {
    const t = makeDeps();
    const made = await enqueueJob(t.deps, { task: 'enhance', input: URL_IN, post: {} }, 'ui');
    if (!made.ok) throw new Error(made.error);
    expect(made.job.spec.enhance).toBe('auto');
    expect(made.job.spec.aspect).toBe('original');
    expect(made.job.post.title).toBe('Enhanced video');
  });

  it('download only: accepting closes the job as "done" and nothing is posted', async () => {
    const t = makeDeps();
    const made = await enqueueJob(t.deps, { task: 'enhance', input: URL_IN, post: { platforms: [] } }, 'ui');
    if (!made.ok) throw new Error(made.error);
    await runJob(t.deps, made.job.id);
    const r = await approveJob(t.deps, made.job.id);
    expect(r.ok).toBe(true);
    const job = (await t.store.get(made.job.id))!.job;
    expect(job.status).toBe('done');
    expect(isTerminal(job.status)).toBe(true);
    for (let i = 0; i < 3; i++) await tick(t.deps);
    expect(t.calls.post).toBe(0);
    expect((await t.store.get(made.job.id))!.job.status).toBe('done');
  });

  it('with platforms chosen: posts only after you approve', async () => {
    const t = makeDeps();
    const made = await enqueueJob(t.deps, { task: 'enhance', input: URL_IN, post: { title: 'Promo', platforms: ['telegram', 'discord'] } }, 'ui');
    if (!made.ok) throw new Error(made.error);
    await runJob(t.deps, made.job.id);
    expect(t.calls.post).toBe(0);
    expect((await approveJob(t.deps, made.job.id)).ok).toBe(true);
    expect((await runJob(t.deps, made.job.id, { forcePost: true }))?.status).toBe('posted');
    expect(t.calls.posted[0]).toEqual(['telegram', 'discord']);
  });

  it('rejecting never posts', async () => {
    const t = makeDeps();
    const made = await enqueueJob(t.deps, { task: 'enhance', input: URL_IN, post: { platforms: ['telegram'] } }, 'ui');
    if (!made.ok) throw new Error(made.error);
    await runJob(t.deps, made.job.id);
    expect((await rejectJob(t.deps, made.job.id, 'panget')).ok).toBe(true);
    for (let i = 0; i < 2; i++) await tick(t.deps);
    expect(t.calls.post).toBe(0);
  });

  it('refuses private links, and a normal edit still needs a platform', async () => {
    const t = makeDeps();
    expect((await enqueueJob(t.deps, { task: 'enhance', input: 'http://192.168.1.5/a.mp4', post: {} }, 'ui')).ok).toBe(false);
    expect((await enqueueJob(t.deps, { input: URL_IN, post: { title: 'x', platforms: [] } }, 'ui')).ok).toBe(false);
  });

  it('state machine: "done" is reachable only from the approval step and leads nowhere', () => {
    expect(canTransition('awaiting_approval', 'done')).toBe(true);
    expect(canTransition('awaiting_approval', 'posting')).toBe(false);
    expect(canTransition('edited', 'done')).toBe(false);
    expect(canTransition('done', 'posting')).toBe(false);
    expect(canTransition('done', 'queued')).toBe(false);
  });
});

describe('Reel status (from real jobs)', () => {
  const NOW = new Date('2026-11-19T10:00:00Z');
  const job = (status: VideoJob['status'], task: VideoJob['task'] = 'enhance', updated_at = '2026-11-19T09:00:00Z') => ({ status, task, updated_at, post: { title: '', caption: '', tags: [], platforms: [] } });
  it('idle, working, waiting, problem', () => {
    expect(reelStatus([], NOW).state).toBe('idle');
    expect(reelStatus([job('editing')], NOW).state).toBe('working');
    expect(reelStatus([job('editing')], NOW).bubble).toContain('enhance');
    expect(reelStatus([job('awaiting_approval')], NOW).state).toBe('waiting');
    expect(reelStatus([job('failed')], NOW).state).toBe('problem');
    expect(reelStatus([job('failed', 'edit', '2026-11-10T09:00:00Z')], NOW).state).toBe('idle'); // an old failure is not today's problem
    expect(reelStatus([job('editing'), job('awaiting_approval')], NOW).waiting).toBe(1);
  });
});

// Real ffmpeg: every preset must produce a playable file from a generated test clip (skipped when ffmpeg is not installed).
const hasFfmpeg = spawnSync('ffmpeg', ['-version']).status === 0;
describe.skipIf(!hasFfmpeg)('ffmpeg really runs every enhance preset', () => {
  const dir = mkdtempSync(join(tmpdir(), 'enh-'));
  const input = join(dir, 'in.mp4');
  it('makes the test clip', () => {
    const r = spawnSync('ffmpeg', ['-hide_banner', '-loglevel', 'error', '-y', '-f', 'lavfi', '-i', 'testsrc=size=640x360:rate=25', '-f', 'lavfi', '-i', 'sine=frequency=440:sample_rate=44100', '-t', '2', '-c:v', 'libx264', '-pix_fmt', 'yuv420p', '-c:a', 'aac', input]);
    expect(r.status).toBe(0);
    expect(existsSync(input)).toBe(true);
  });
  for (const p of ENHANCE_PRESETS) {
    it(`preset "${p.value}"`, () => {
      const output = join(dir, `${p.value}.mp4`);
      const { args } = buildFfmpegArgs({ input, output, spec: { aspect: p.value === 'auto' ? '9:16' : 'original', normalize_audio: true, enhance: p.value }, withText: false });
      const r = spawnSync('ffmpeg', args, { encoding: 'utf8' });
      expect(r.stderr).toBe('');
      expect(r.status).toBe(0);
      expect(statSync(output).size).toBeGreaterThan(1024);
    });
  }
});
