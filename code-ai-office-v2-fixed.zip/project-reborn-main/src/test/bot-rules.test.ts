import { afterEach, describe, expect, it } from 'vitest';
import { authorized, isServiceCall } from '@/server/bot/_shared/publish';
import { CRON_JOBS } from '@/server/bot/registry';

const req = (headers: Record<string, string>) => new Request('https://app.test/api/public/bot/admin-db', { method: 'POST', headers });

describe('office password gate', () => {
  afterEach(() => { delete process.env['APP_PASSCODE']; });

  it('refuses every change when no password is set on the server', () => {
    expect(authorized(req({ 'x-app-passcode': '' }))).toBe(false);
    expect(authorized(req({ 'x-app-passcode': 'anything' }))).toBe(false);
  });

  it('accepts only the exact server password', () => {
    process.env['APP_PASSCODE'] = 'correct-horse';
    expect(authorized(req({ 'x-app-passcode': 'correct-horse' }))).toBe(true);
    expect(authorized(req({ 'x-app-passcode': 'correct-hors' }))).toBe(false);
    expect(authorized(req({}))).toBe(false);
  });
});

describe('scheduled bot calls', () => {
  it('only trusts the server key as a scheduled caller', () => {
    process.env['SUPABASE_SERVICE_ROLE_KEY'] = 'svc-key';
    expect(isServiceCall(req({ authorization: 'Bearer svc-key' }))).toBe(true);
    expect(isServiceCall(req({ authorization: 'Bearer other' }))).toBe(false);
  });

  it('keeps the original cadence: worker 1 min, X replies 2, Watchdog 5, reflector 30', () => {
    const every = Object.fromEntries(CRON_JOBS.map((j) => [j.name, j.everyMinutes]));
    expect(every).toEqual({ 'auto-bot-worker': 1, 'x-mentions-bot': 2, 'watchdog-bot': 5, 'idea-lab-reflector': 30 });
  });
});
