-- Office records are private: the browser reads them only through the password-checked server.
DROP POLICY IF EXISTS public_read_bot_settings ON public.bot_settings;
DROP POLICY IF EXISTS public_read_idea_lab_brain ON public.idea_lab_brain;
DROP POLICY IF EXISTS public_read_employee_bots ON public.employee_bots;
DROP POLICY IF EXISTS public_read_posts ON public.posts;
DROP POLICY IF EXISTS public_read_invite_queue ON public.invite_queue;
DROP POLICY IF EXISTS public_read_invite_rules ON public.invite_rules;
DROP POLICY IF EXISTS public_read_ab_results ON public.ab_results;
DROP POLICY IF EXISTS public_read_integrations ON public.integrations;
DROP POLICY IF EXISTS public_read_brain_sync_events ON public.brain_sync_events;
DROP POLICY IF EXISTS public_read_bot_action_logs ON public.bot_action_logs;
DROP POLICY IF EXISTS public_read_bot_logs ON public.bot_logs;
DROP POLICY IF EXISTS public_read_scheduled_posts ON public.scheduled_posts;

REVOKE ALL ON public.bot_settings, public.idea_lab_brain, public.employee_bots, public.posts,
  public.invite_queue, public.invite_rules, public.ab_results, public.integrations,
  public.brain_sync_events, public.bot_action_logs, public.bot_logs, public.scheduled_posts
  FROM anon, authenticated;

GRANT ALL ON public.bot_settings, public.idea_lab_brain, public.employee_bots, public.posts,
  public.invite_queue, public.invite_rules, public.ab_results, public.integrations,
  public.brain_sync_events, public.bot_action_logs, public.bot_logs, public.scheduled_posts
  TO service_role;