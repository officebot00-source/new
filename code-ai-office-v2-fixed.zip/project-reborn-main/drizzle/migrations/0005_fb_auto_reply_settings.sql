-- Facebook auto-reply switch + extra instructions, controlled from the Watchdog settings.
alter table public.bot_settings add column if not exists fb_auto_reply_enabled boolean not null default true;
alter table public.bot_settings add column if not exists fb_reply_instructions text not null default '';
