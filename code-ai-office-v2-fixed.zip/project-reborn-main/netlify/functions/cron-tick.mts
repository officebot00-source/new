// Netlify SCHEDULED function: calls the app's own /api/public/cron/tick once a minute.
// This is the Netlify replacement for Lovable's "bot-office-tick" schedule (see NETLIFY-DEPLOY.md).
//
// It does NOTHING unless you opt in with NETLIFY_CRON_ENABLED=true, so a fresh/duplicate Netlify site can never
// start the bots by accident. The tick route re-checks everything (secret, ACTIVE_DEPLOYMENT_URL, one tick per minute).
// Scheduled functions only run on the PUBLISHED production deploy (never deploy previews).
//
// Env (Netlify -> Site configuration -> Environment variables):
//   NETLIFY_CRON_ENABLED = true
//   ACTIVE_DEPLOYMENT_URL = https://<your-site>.netlify.app      (first entry is the tick target)
//   CRON_SECRET           = long random string (same value is checked by the tick route)

export const config = { schedule: "* * * * *" };

export default async (): Promise<Response> => {
  const log = (msg: string) => console.log(`[cron-tick] ${msg}`);

  if (String(process.env["NETLIFY_CRON_ENABLED"] ?? "").trim().toLowerCase() !== "true") {
    log("disabled (NETLIFY_CRON_ENABLED is not 'true')");
    return new Response("disabled", { status: 200 });
  }
  const context = process.env["CONTEXT"];
  if (context && context !== "production") {
    log(`skipped: context is ${context}`);
    return new Response("not production", { status: 200 });
  }

  const target = String(process.env["ACTIVE_DEPLOYMENT_URL"] ?? "").split(",")[0]?.trim().replace(/\/+$/, "") ?? "";
  const secret = process.env["CRON_SECRET"] ?? "";
  if (!/^https:\/\//i.test(target) || !secret) {
    log("misconfigured: ACTIVE_DEPLOYMENT_URL (https://...) and CRON_SECRET must both be set");
    return new Response("misconfigured", { status: 200 });
  }

  // Scheduled functions are cut off after ~30s; give up a little earlier and let the next minute run.
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), 25_000);
  try {
    const res = await fetch(`${target}/api/public/cron/tick`, {
      method: "POST",
      headers: { "Content-Type": "application/json", Authorization: `Bearer ${secret}` },
      body: "{}",
      signal: ctrl.signal,
    });
    log(`tick -> ${res.status} ${(await res.text()).slice(0, 300)}`);
  } catch (e) {
    log(`tick failed: ${String(e)}`);
  } finally {
    clearTimeout(timer);
  }
  return new Response("done", { status: 200 });
};
